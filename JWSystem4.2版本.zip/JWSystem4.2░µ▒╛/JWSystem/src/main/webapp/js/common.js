


//日期转现
function date2string(d) {
	if (!d) {
		console.error("参数写错了，请传入日期对象");
		return;
	}
	if (typeof d == "object" && d instanceof Date) {
		var ymd = d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
		var hms = d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
		return ymd + " " + hms;
	} else {
		console.error("参数写错了，请传入日期对象");
		return;
	}
}

//计算两个日期的差值
function between(d1, d2) {
	if (typeof d1 == "object" && d1 instanceof Date) {
		var time1 = d1.getTime();
	} else if (typeof d1 == "string") {
		var time1 = Date.parse(d1);
	}

	if (typeof d2 == "object" && d2 instanceof Date) {
		var time2 = d2.getTime();
	} else if (typeof d2 == "string") {
		var time2 = Date.parse(d2);
	}
	var days = (time1 - time2) / 1000 / 60 / 60 / 24;
	return days;

}
function $(selector) {
	if (typeof selector != "string") return;
	if (selector.length == 0) return;

	var first = selector[0];
	if (first == "#") {
		return document.getElementById(selector.substring(1))
	} else if (first == ".") {
		return Array.from(document.getElementsByClassName(selector.substring(1)))
	} else {
		return Array.from(document.getElementsByTagName(selector));
	}
}


