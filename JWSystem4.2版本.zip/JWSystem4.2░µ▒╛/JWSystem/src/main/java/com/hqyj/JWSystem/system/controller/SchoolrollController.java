package com.hqyj.JWSystem.system.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hqyj.JWSystem.system.model.ActiveUser;
import com.hqyj.JWSystem.system.model.Class;
import com.hqyj.JWSystem.system.model.Dep;
import com.hqyj.JWSystem.system.model.Major;
import com.hqyj.JWSystem.system.model.Schoolroll;
import com.hqyj.JWSystem.system.model.Student;
import com.hqyj.JWSystem.system.service.DepService;
import com.hqyj.JWSystem.system.service.MajorService;
import com.hqyj.JWSystem.system.service.SchoolRollService;
import com.hqyj.JWSystem.system.service.StudentService;

@Controller
// @RequestMapping()
public class SchoolrollController {
	@Autowired
	public SchoolRollService schoolRollService;
	@Autowired
	public DepService depService;
	@Autowired
	public MajorService majorService;
	@Autowired
	public StudentService studentService;

	@RequestMapping(value = "/schoolrollList.do")
	public String schoolrollList(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		System.err.println("------------------schoolrollList-------------------------");
		/** 查询学籍表 */
		List<Schoolroll> schoolrollList = schoolRollService.querySchoolrollBYAll();
		for (Schoolroll schoolroll : schoolrollList) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String format = sdf.format(schoolroll.getStu_intime());
			System.err.println(format);
			request.setAttribute("format", format);
		}
		request.setAttribute("schoolRollList", schoolrollList);
		/** 查询院系表：sys_dep */
		List<Dep> deplist = depService.queryAllByStudent();
		request.setAttribute("deplist", deplist);
		/** 查询专业表 */
		List<Major> majorlist = majorService.queryAllByMajor();
		request.setAttribute("majorlist", majorlist);

		return "view/schoolroll/schoolRollList";

	}

	
	/**按学号删除学生学籍*/
	@RequestMapping(value = "/deleteSchoolrollStudent_id.do")
	public String deleteSchoolrollStudent_id(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			String student_id) {

		int student_idInt = Integer.parseInt(student_id);
		int i = schoolRollService.deleteByPrimaryKey(student_idInt);

		/** 查询学籍表 */
		List<Schoolroll> schoolrollList = schoolRollService.querySchoolrollBYAll();
		for (Schoolroll schoolroll : schoolrollList) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String format = sdf.format(schoolroll.getStu_intime());
			System.err.println(format);
			request.setAttribute("format", format);
		}
		request.setAttribute("schoolRollList", schoolrollList);
		/** 查询院系表：sys_dep */
		List<Dep> deplist = depService.queryAllByStudent();
		request.setAttribute("deplist", deplist);
		/** 查询专业表 */
		List<Major> majorlist = majorService.queryAllByMajor();
		request.setAttribute("majorlist", majorlist);
		return "view/schoolroll/schoolRollList";

	}

	@RequestMapping(value = "/addschoolRoll.do")
	public String addschoolRoll(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Schoolroll schoolroll, String intime) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date stu_intime = sdf.parse(intime);
			schoolroll.setStu_intime(stu_intime);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Student stu = studentService.queryStudentNumberByStudent_id(schoolroll.getId());

		if (stu != null) {
			schoolroll.setStudent_name(stu.getStudent_name());
			schoolroll.setStudent_id(stu.getStudent_id());

			Dep dep = depService.selectByPrimaryKey(stu.getDep_id());
			schoolroll.setDep_id(dep.getDep_id());

			Major major = majorService.selectByPrimaryKey(stu.getMajor_id());
			schoolroll.setMajor_id(major.getMajor_id());
			
			int i = schoolRollService.insertSelective(schoolroll);

			/** 查询学籍表 */
			List<Schoolroll> schoolrollList = schoolRollService.querySchoolrollBYAll();
			for (Schoolroll schoolroll2 : schoolrollList) {
				String format = sdf.format(schoolroll2.getStu_intime());
				System.err.println(format);
				request.setAttribute("format", format);
			}

			request.setAttribute("schoolRollList", schoolrollList);
			/** 查询院系表：sys_dep */
			List<Dep> deplist = depService.queryAllByStudent();
			request.setAttribute("deplist", deplist);
			/** 查询专业表 */
			List<Major> majorlist = majorService.queryAllByMajor();
			request.setAttribute("majorlist", majorlist);

			return "view/schoolroll/schoolRollList";

		}else {
			
			/** 查询学籍表 */
			List<Schoolroll> schoolrollList = schoolRollService.querySchoolrollBYAll();
			for (Schoolroll schoolroll2 : schoolrollList) {
				String format = sdf.format(schoolroll2.getStu_intime());
				System.err.println(format);
				request.setAttribute("format", format);
			}

			request.setAttribute("schoolRollList", schoolrollList);
			/** 查询院系表：sys_dep */
			List<Dep> deplist = depService.queryAllByStudent();
			request.setAttribute("deplist", deplist);
			/** 查询专业表 */
			List<Major> majorlist = majorService.queryAllByMajor();
			request.setAttribute("majorlist", majorlist);
			request.setAttribute("message","添加的学生不是本校的学生请添加本校的学生！");
			return "view/schoolroll/schoolRollList";
		}

	}
	
	
	
	
	
	@RequestMapping(value="/updateSchoolrollStudent_idUI.do")
	public String updateSchoolrollStudent_idUI(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			String student_id) {

		int student_idInt = Integer.parseInt(student_id);
		Schoolroll sr=schoolRollService.querySchoolrollByStudent_id(student_idInt);
		request.setAttribute("sr", sr);

		
		return "view/schoolroll/updateSchoolroll";
		
	}
	
	@RequestMapping(value="/updateSchoolrollStudent_id.do")
	public String updateSchoolrollStudent_id(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Schoolroll schoolroll) {
		
		int i = schoolRollService.updateByPrimaryKeySelective2(schoolroll);
		
		
		/** 查询学籍表 */
		List<Schoolroll> schoolrollList = schoolRollService.querySchoolrollBYAll();
		for (Schoolroll schoolroll2 : schoolrollList) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String format = sdf.format(schoolroll2.getStu_intime());
			request.setAttribute("format", format);
		}
		request.setAttribute("schoolRollList", schoolrollList);
		/** 查询院系表：sys_dep */
		List<Dep> deplist = depService.queryAllByStudent();
		request.setAttribute("deplist", deplist);
		/** 查询专业表 */
		List<Major> majorlist = majorService.queryAllByMajor();
		request.setAttribute("majorlist", majorlist);

		return "view/schoolroll/schoolRollList";
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping(value="/schoolRollByPIM.do")
	public String schoolRollByPIM(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		
		ActiveUser attribute = (ActiveUser) session.getAttribute("activeUser");
		int student_id = Integer.parseInt(attribute.getUsercode());
		
		Schoolroll  schoolroll=schoolRollService.querySchoolrollByStudent_id(student_id);
		request.setAttribute("schoolroll", schoolroll);
		
		Dep dep = depService.selectByPrimaryKey(schoolroll.getDep_id());
		request.setAttribute("dep", dep);

		Major major = majorService.selectByPrimaryKey(schoolroll.getMajor_id());
		request.setAttribute("major", major);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String format = sdf.format(schoolroll.getStu_intime());
		request.setAttribute("format", format);
		
		
		return "view/schoolroll/schoolRollByPIM";
		
		
		
		
		
		
		
		
		
		
		


		
		
		
		
		
		
	}
	
	

}
