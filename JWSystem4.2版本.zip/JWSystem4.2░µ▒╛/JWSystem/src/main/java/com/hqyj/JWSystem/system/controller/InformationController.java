package com.hqyj.JWSystem.system.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hqyj.JWSystem.system.model.Information;
import com.hqyj.JWSystem.system.service.InformationService;

@Controller
public class InformationController {

	Date date = new Date();
	@Autowired
	private InformationService informationService;
	
	@RequestMapping(value = "/queryinformation.do")
	public String queryInformation(HttpServletRequest request, HttpServletResponse response,
			HttpSession session, Model model, Information information ) {
		System.out.println("--------queryinformation----------");
		List<Information> informationList = informationService.queryInformation(information);
		model.addAttribute("informationList", informationList);
		return "view/information/inform";
	}
	
	@RequestMapping(value = "/addformation.do")
	public String addInformation(HttpServletRequest request, HttpServletResponse response,
			HttpSession session, Model model ) {
		System.out.println("--------addinformation----------");
		String info = request.getParameter("content");
		System.out.println(info);
		Information information = new Information();
		information.setInfo(info);
		information.setFulltime(date);
		int n =  informationService.addinformation(information);
		List<Information> informationList = informationService.queryInformation(information);
		model.addAttribute("informationList", informationList);
		return "view/information/addinform";
	}
	
	@RequestMapping(value = "/deleteinformation.do")
	public String deleteInformation(HttpServletRequest request, HttpServletResponse response,
			HttpSession session, Model model, Information information ) {
		System.out.println("--------queryinformation----------");
		
		int information_id = Integer.parseInt(request.getParameter("infor_id"));
		int n = informationService.deleteinformationByid(information_id);
		List<Information> informationList = informationService.queryInformation(information);
		model.addAttribute("informationList", informationList);
		return "view/information/addinform";
	}
	
	@RequestMapping(value = "/queryinformationlist.do")
	public String queryInformationlist(HttpServletRequest request, HttpServletResponse response,
			HttpSession session, Model model, Information information ) {
		System.out.println("--------queryinformation----------");
		List<Information> informationList = informationService.queryInformation(information);
		model.addAttribute("informationList", informationList);
		return "view/information/addinform";
	}
	
}
