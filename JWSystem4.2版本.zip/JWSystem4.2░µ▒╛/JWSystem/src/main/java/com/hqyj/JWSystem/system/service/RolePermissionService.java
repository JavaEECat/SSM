package com.hqyj.JWSystem.system.service;

import com.hqyj.JWSystem.system.model.RolePermission;

public interface RolePermissionService {

	int deleteByRoleId(int role_id);

	int addRoleMenuByRM(RolePermission rolePermission);

}
