package com.hqyj.JWSystem.system.model;

public class PageBean {

	/** 当前页码（page code） */
	private long pc;
	
	//数据总数
	private long total;
	
	//数据总页数
	private long pages;


	public long getPc() {
		return pc;
	}


	public void setPc(long pc) {
		this.pc = pc;
	}


	public long getTotal() {
		return total;
	}


	public void setTotal(long total) {
		this.total = total;
	}


	public long getPages() {
		return pages;
	}


	public void setPages(long pages) {
		this.pages = pages;
	}


	@Override
	public String toString() {
		return "PageBean [pc=" + pc + ", total=" + total + ", pages=" + pages + "]";
	}
	
	
}
