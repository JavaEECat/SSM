package com.hqyj.JWSystem.system.model;

import java.util.List;

/**
 * <p>
 * 用户身份信息:<br>
 * 存入session 由于tomcat将session会序列化在本地硬盘上，所以使用Serializable接口
 * </p>
 * 
 * @Copyright (C),华清远见
 * @author zlf
 * @Date:2019年8月24日
 */
public class ActiveUser implements java.io.Serializable {
	/**  */
	private static final long serialVersionUID = -4500748422849176791L;
	/** 用户id（主键） */
	private int userid;
	/** 用户账号 */
	private String usercode;
	/** 用户名称 */
	private String username;
	private List<Permission> menu;
	private List<Permission> permission;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUsercode() {
		return usercode;
	}

	public void setUsercode(String usercode) {
		this.usercode = usercode;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public List<Permission> getMenu() {
		return menu;
	}

	public void setMenu(List<Permission> menu) {
		this.menu = menu;
	}

	public List<Permission> getPermission() {
		return permission;
	}

	public void setPermission(List<Permission> permission) {
		this.permission = permission;
	}

	@Override
	public String toString() {
		return "ActiveUser [userid=" + userid + ", usercode=" + usercode + ", username=" + username + ", menu=" + menu
				+ ", permission=" + permission + "]";
	}

	

}
