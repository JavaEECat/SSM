package com.hqyj.JWSystem.system.model;

import java.util.Date;

public class Schoolroll {
    private Integer id;

    private String student_name;

    private Integer student_id;

    private String stu_card;

    private String stu_address;

    private Date stu_intime;

    private String stu_education;

    private Integer major_id;

    private Integer dep_id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStudent_name() {
        return student_name;
    }

    public void setStudent_name(String student_name) {
        this.student_name = student_name;
    }

    public Integer getStudent_id() {
        return student_id;
    }

    public void setStudent_id(Integer student_id) {
        this.student_id = student_id;
    }

    public String getStu_card() {
        return stu_card;
    }

    public void setStu_card(String stu_card) {
        this.stu_card = stu_card;
    }

    public String getStu_address() {
        return stu_address;
    }

    public void setStu_address(String stu_address) {
        this.stu_address = stu_address;
    }

    public Date getStu_intime() {
        return stu_intime;
    }

    public void setStu_intime(Date stu_intime) {
        this.stu_intime = stu_intime;
    }

    public String getStu_education() {
        return stu_education;
    }

    public void setStu_education(String stu_education) {
        this.stu_education = stu_education;
    }

    public Integer getMajor_id() {
        return major_id;
    }

    public void setMajor_id(Integer major_id) {
        this.major_id = major_id;
    }

    public Integer getDep_id() {
        return dep_id;
    }

    public void setDep_id(Integer dep_id) {
        this.dep_id = dep_id;
    }

	@Override
	public String toString() {
		return "Schoolroll [id=" + id + ", student_name=" + student_name + ", student_id=" + student_id + ", stu_card="
				+ stu_card + ", stu_address=" + stu_address + ", stu_intime=" + stu_intime + ", stu_education="
				+ stu_education + ", major_id=" + major_id + ", dep_id=" + dep_id + "]";
	}
    
    
}