package com.hqyj.JWSystem.system.model;

public class Course {
    private Integer course_id;

    private String course_name;

    private Double credit;

    private Integer hour;

    private String course_type;

    public Integer getCourse_id() {
        return course_id;
    }

    public void setCourse_id(Integer course_id) {
        this.course_id = course_id;
    }

    public String getCourse_name() {
        return course_name;
    }

    public void setCourse_name(String course_name) {
        this.course_name = course_name;
    }

    public Double getCredit() {
        return credit;
    }

    public void setCredit(Double credit) {
        this.credit = credit;
    }

    public Integer getHour() {
        return hour;
    }

    public void setHour(Integer hour) {
        this.hour = hour;
    }

    public String getCourse_type() {
        return course_type;
    }

    public void setCourse_type(String course_type) {
        this.course_type = course_type;
    }

	@Override
	public String toString() {
		return "Course [course_id=" + course_id + ", course_name=" + course_name + ", credit=" + credit + ", hour="
				+ hour + ", course_type=" + course_type + "]";
	}
    
    
}