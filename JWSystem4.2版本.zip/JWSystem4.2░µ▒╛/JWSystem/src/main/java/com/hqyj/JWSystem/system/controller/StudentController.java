package com.hqyj.JWSystem.system.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hqyj.JWSystem.system.model.ActiveUser;
import com.hqyj.JWSystem.system.model.Class;
import com.hqyj.JWSystem.system.model.Dep;
import com.hqyj.JWSystem.system.model.Major;
import com.hqyj.JWSystem.system.model.Room;
import com.hqyj.JWSystem.system.model.Student;
import com.hqyj.JWSystem.system.service.ClassService;
import com.hqyj.JWSystem.system.service.DepService;
import com.hqyj.JWSystem.system.service.MajorService;
import com.hqyj.JWSystem.system.service.RoomService;
import com.hqyj.JWSystem.system.service.StudentService;

@Controller
@RequestMapping(value = "studentController")
public class StudentController {
	@Autowired
	public StudentService studentService;
	@Autowired
	public DepService depService;
	@Autowired
	public MajorService majorService;
	@Autowired
	public RoomService roomService;
	@Autowired
	public ClassService classService;

	/** 用学号查询信息 */
	@RequestMapping(value = "/queryStudentNumber.do")
	public String queryStudentNumber(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			String student_id) {
		int student_idInt = Integer.parseInt(student_id);
		Student stu = studentService.queryStudentNumberByStudent_id(student_idInt);
		if (stu != null) {
			request.setAttribute("stu", stu);

			Dep dep = depService.selectByPrimaryKey(stu.getDep_id());
			request.setAttribute("dep", dep);

			Major major = majorService.selectByPrimaryKey(stu.getMajor_id());
			request.setAttribute("major", major);

			Class class1 = new Class();
			class1.setClass_id(stu.getClass_id());
			List<Class> queryClassListByClass = classService.queryClassListByClass(class1);
			Class class2 = queryClassListByClass.get(0);
			request.setAttribute("class2", class2);

			return "view/student/queryStudentNumber";
		} else {

			request.setAttribute("message", "你查询的学号不存在！");

			/** 查询学生表：sys_student */
			List<Student> studentlist = studentService.queryAllByStudent();
			request.setAttribute("studentlist", studentlist);

			/** 查询院系表：sys_dep */
			List<Dep> deplist = depService.queryAllByStudent();
			request.setAttribute("deplist", deplist);
			/** 查询专业表 */
			List<Major> majorlist = majorService.queryAllByMajor();
			request.setAttribute("majorlist", majorlist);
			/** 查询教室表 */
			List<Room> roomlist = roomService.queryAllByRoom();
			request.setAttribute("roomlist", roomlist);
			/** 查询班级表 */
			List<Class> classlist = classService.queryClassListByClass(new Class());
			request.setAttribute("classlist", classlist);

			return "view/student/queryallstudent";
		}

	}

	/** 添加学生信息 */
	@RequestMapping(value = "/addstudent.do")
	public String addstudent(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model,Student student, Major major, Dep dep, Class class3) {
		
		System.err.println("----------------------major----------------------------"+major);
		System.err.println("----------------------dep----------------------------"+dep);
		System.err.println("----------------------class3----------------------------"+class3);
		
		
		

		/** 查询院系表：sys_dep */
		List<Dep> deplist2 = depService.queryAllByStudent();
		request.setAttribute("deplist", deplist2);
		/** 查询班级表 */
		List<Class> classlist2 = classService.queryClassListByClass(new Class());
		request.setAttribute("classlist", classlist2);
		/** 查询专业表 */
		List<Major> majorlist2 = majorService.queryAllByMajor();
		request.setAttribute("majorlist", majorlist2);
		
		
		
		
		
		
		
		
		
		Student stu = studentService.selectByPrimaryKey(student.getStudent_id());
		if (stu == null) {
			Dep dep2 = depService.queryDepByDep_id(dep.getDep_name());
			student.setDep_id(dep.getDep_id());
			Major major2 = majorService.queryDepByMajor_id(major.getMajor_name());

			student.setMajor_id(major.getMajor_id());
			Class class1 = new Class();
			class1.setClass_name(class3.getMajor_name());
			List<Class> queryClassListByClass = classService.queryClassListByClass(class1);
			Class class2 = queryClassListByClass.get(0);
			student.setClass_id(class2.getClass_id());
			int i = studentService.insertSelective(student);

			/** 查询学生表：sys_student */
			List<Student> studentlist = studentService.queryAllByStudent();
			request.setAttribute("studentlist", studentlist);

			/** 查询院系表：sys_dep */
			List<Dep> deplist = depService.queryAllByStudent();
			request.setAttribute("deplist", deplist);
			/** 查询专业表 */
			List<Major> majorlist = majorService.queryAllByMajor();
			request.setAttribute("majorlist", majorlist);
			/** 查询教室表 */
			List<Room> roomlist = roomService.queryAllByRoom();
			request.setAttribute("roomlist", roomlist);
			/** 查询班级表 */
			List<Class> classlist = classService.queryClassListByClass(new Class());
			request.setAttribute("classlist", classlist);

			request.setAttribute("message", "添加成功！请添加下一个");

			return "view/student/addstudent";
		} else {

			request.setAttribute("message", "本学生已经存在,可以直接查询！");
			return "view/student/addstudent";

		}

	}
	
	
	@RequestMapping(value="/addstudentUI.do")
	public String  addstudentUI(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model,Student student) {
		System.out.println("-------addstudentUI--------------");
		System.out.println(student);
		System.out.println(student.getClass_id());
		model.addAttribute("student_id", student.getStudent_id());
		model.addAttribute("student_name", student.getStudent_name());
		model.addAttribute("sex", student.getSex());
		model.addAttribute("age", student.getAge());
		
		model.addAttribute("select_dep", student.getDep_id());
		model.addAttribute("select_major", student.getMajor_id());
		model.addAttribute("select_class", student.getClass_id());
		
		
		
		/** 查询院系表：sys_dep */
		List<Dep> deplist2 = depService.queryAllByStudent();
		request.setAttribute("deplist", deplist2);
		/** 查询班级表 */
		List<Class> classlist2 = classService.queryClassListByClass(new Class());
		for (Class class1 : classlist2) {
			System.out.println(class1);
		}
		request.setAttribute("classlist", classlist2);
		/** 查询专业表 */
		List<Major> majorlist2 = majorService.queryAllByMajor();
		request.setAttribute("majorlist", majorlist2);
		
		
		
		System.err.println("ooooo");
		
		return "view/student/addstudent";
		
	}
	
	
	
	
	
	
	
	
	

	/** 查询所有学生 */
	@RequestMapping("/studentQueryAll.do")
	public String studentQueryAll(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		System.err.println("-----------studentQueryAll--------------------------");

		/** 查询学生表：sys_student */
		List<Student> studentlist = studentService.queryAllByStudent();
		request.setAttribute("studentlist", studentlist);

		/** 查询院系表：sys_dep */
		List<Dep> deplist = depService.queryAllByStudent();
		request.setAttribute("deplist", deplist);
		/** 查询专业表 */
		List<Major> majorlist = majorService.queryAllByMajor();
		request.setAttribute("majorlist", majorlist);
		/** 查询教室表 */
		List<Room> roomlist = roomService.queryAllByRoom();
		request.setAttribute("roomlist", roomlist);
		/** 查询班级表 */
		List<Class> classlist = classService.queryClassListByClass(new Class());
		request.setAttribute("classlist", classlist);

		return "view/student/queryallstudent";

	}

	/** 添加删除学生记录 */
	@RequestMapping("/studentDeleteAndupdate.do")
	public String studentDeleteAndupdate(HttpServletRequest request, HttpServletResponse response,
			HttpSession session) {

		/** 查询学生表：sys_student */
		List<Student> studentlist = studentService.queryAllByStudent();
		request.setAttribute("studentlist", studentlist);

		/** 查询院系表：sys_dep */
		List<Dep> deplist = depService.queryAllByStudent();
		request.setAttribute("deplist", deplist);
		/** 查询专业表 */
		List<Major> majorlist = majorService.queryAllByMajor();
		request.setAttribute("majorlist", majorlist);
		/** 查询教室表 */
		List<Room> roomlist = roomService.queryAllByRoom();
		request.setAttribute("roomlist", roomlist);
		/** 查询班级表 */
		List<Class> classlist = classService.queryClassListByClass(new Class());
		request.setAttribute("classlist", classlist);

		return "view/student/deleteAndupdateStudent";

	}

	@RequestMapping("/deleteStudent.do")
	public String deleteStudent(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			String student_id) {

		int student_idInt = Integer.parseInt(student_id);

		int i = studentService.deleteByPrimaryKey(student_idInt);

		List<Student> studentlist = studentService.queryAllByStudent();
		request.setAttribute("studentlist", studentlist);

		/** 查询院系表：sys_dep */
		List<Dep> deplist = depService.queryAllByStudent();
		request.setAttribute("deplist", deplist);
		/** 查询专业表 */
		List<Major> majorlist = majorService.queryAllByMajor();
		request.setAttribute("majorlist", majorlist);
		/** 查询教室表 */
		List<Room> roomlist = roomService.queryAllByRoom();
		request.setAttribute("roomlist", roomlist);
		/** 查询班级表 */
		List<Class> classlist = classService.queryClassListByClass(new Class());
		request.setAttribute("classlist", classlist);

		return "view/student/deleteAndupdateStudent";

	}

	@RequestMapping("/updateStudentUI.do")
	public String updateStudentUI(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			String student_id) {

		int student_idInt = Integer.parseInt(student_id);
		Student student = studentService.selectByPrimaryKey(student_idInt);
		Dep dep = depService.selectByPrimaryKey(student.getDep_id());
		Major major = majorService.selectByPrimaryKey(student.getMajor_id());


		Class class1 = new Class();
		class1.setClass_id(student.getClass_id());
		List<Class> queryClassListByClass = classService.queryClassListByClass(class1);
		Class class2 = queryClassListByClass.get(0);

		request.setAttribute("student", student);
		request.setAttribute("dep", dep);
		request.setAttribute("major", major);
		request.setAttribute("class2", class2);

		return "view/student/updateStudent";

	}

	@RequestMapping("/updateStudent.do")
	public String updateStudent(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Student student) {
			System.err.println("-------------------------------------------"+student);
		// 接收数据
		String dep_name = request.getParameter("dep_name");
		String major_name = request.getParameter("major_name");
		String class_name = request.getParameter("class_name");

		// 把数据放入student
		Dep dep = depService.queryDepByDep_id(dep_name);
		System.err.println("---------------------dep----------------------"+dep);
		Major major = majorService.queryDepByMajor_id(major_name);
		System.err.println("----------------major--------------------------"+major);
		Class class1 = new Class();
		class1.setClass_name(class_name);
		List<Class> queryClassListByClass = classService.queryClassListByClass(class1);
		Class class2 = queryClassListByClass.get(0);
		
		
		student.setDep_id(dep.getDep_id());

		student.setMajor_id(major.getMajor_id());

		student.setClass_id(class2.getClass_id());


		int i = studentService.updateByPrimaryKeySelective(student);

		/** 查询学生表：sys_student */
		List<Student> studentlist = studentService.queryAllByStudent();
		request.setAttribute("studentlist", studentlist);
		/** 查询院系表：sys_dep */
		List<Dep> deplist = depService.queryAllByStudent();
		request.setAttribute("deplist", deplist);
		/** 查询班级表 */
		List<Class> classlist = classService.queryClassListByClass(new Class());
		request.setAttribute("classlist", classlist);
		/** 查询专业表 */
		List<Major> majorlist = majorService.queryAllByMajor();
		request.setAttribute("majorlist", majorlist);
		/** 查询教室表 */
		List<Room> roomlist = roomService.queryAllByRoom();
		request.setAttribute("roomlist", roomlist);

		return "view/student/deleteAndupdateStudent";

	}

	@RequestMapping(value = "/onclickquery.do")
	public String onclickquery(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, String dep_id, String major_id, String class_id, Student student) {
		System.out.println("-----------onclickquery----------------dep" + dep_id + "-" + major_id + "-" + class_id);
		System.err.println("***************************" + student);

		model.addAttribute("select_dep", student.getDep_id());
		model.addAttribute("select_major", student.getMajor_id());
		model.addAttribute("select_class", student.getClass_id());

		/** 查询院系表：sys_dep */
		List<Dep> deplist2 = depService.queryAllByStudent();
		request.setAttribute("deplist", deplist2);
		/** 查询班级表 */
		List<Class> classlist2 = classService.queryClassListByClass(new Class());
		request.setAttribute("classlist", classlist2);
		/** 查询专业表 */
		List<Major> majorlist2 = majorService.queryAllByMajor();
		request.setAttribute("majorlist", majorlist2);

		List<Student> studentlist = studentService.queryStudentByStudent(student);

		/** 查询学生表：sys_student */
		// List<Student> studentlist= studentService.queryAllByStudent();
		request.setAttribute("studentlist", studentlist);
		/** 查询院系表：sys_dep */
		List<Dep> deplist = depService.queryAllByStudent();
		request.setAttribute("deplist", deplist);
		/** 查询班级表 */
		List<Class> classlist = classService.queryClassListByClass(new Class());
		request.setAttribute("classlist", classlist);
		/** 查询专业表 */
		List<Major> majorlist = majorService.queryAllByMajor();
		request.setAttribute("majorlist", majorlist);
		/** 查询教室表 */
		List<Room> roomlist = roomService.queryAllByRoom();
		request.setAttribute("roomlist", roomlist);

		return "view/student/queryallstudent";

	}
	
	
	@RequestMapping(value="/studentByPIM.do")
	public String studentByPIM(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		
		ActiveUser attribute = (ActiveUser) session.getAttribute("activeUser");
		int student_id = Integer.parseInt(attribute.getUsercode());
		Student student=studentService.selectByPrimaryKey(student_id);
		

			request.setAttribute("student", student);
			
			
			Dep dep = depService.selectByPrimaryKey(student.getDep_id());
			request.setAttribute("dep", dep);

			Major major = majorService.selectByPrimaryKey(student.getMajor_id());
			request.setAttribute("major", major);

			Class class1 = new Class();
			class1.setClass_id(student.getClass_id());
			List<Class> queryClassListByClass = classService.queryClassListByClass(class1);
			Class class2 = queryClassListByClass.get(0);
			request.setAttribute("class2", class2);			
			return "view/student/StudentByPIM";
		
		
		
		
		
		
	}

}
