package com.hqyj.JWSystem.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.ExamMapper;
import com.hqyj.JWSystem.system.dao.GEMapper;
import com.hqyj.JWSystem.system.model.GradeExamination;
import com.hqyj.JWSystem.system.service.GEService;

@Service
public class GEServiceImpl implements GEService {

	@Autowired
	private GEMapper geMapper;
	@Override
	public List<GradeExamination> queryAll(GradeExamination ge) {
		// TODO Auto-generated method stub
		return geMapper.queryAll(ge);
	}
	@Override
	public int updatencreByStudent_id(GradeExamination ge) {
		// TODO Auto-generated method stub
		return geMapper.updatencreByStudent_id( ge);
	}
	@Override
	public int updatecetByStudent_id(GradeExamination ge) {
		// TODO Auto-generated method stub
		return geMapper.updatecetByStudent_id(ge);
	}
	@Override
	public GradeExamination queryByStudent_id(int id) {
		// TODO Auto-generated method stub
		return geMapper.queryByStudent_id(id);
	}
	@Override
	public int insertSelective(GradeExamination ges) {
		// TODO Auto-generated method stub
		return geMapper.insertSelective(ges);
	}

}
