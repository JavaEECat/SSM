package com.hqyj.JWSystem.system.model;

public class Major {
    private Integer major_id;

    private String major_name;

    private Integer dep_id;

    public Integer getMajor_id() {
        return major_id;
    }

    public void setMajor_id(Integer major_id) {
        this.major_id = major_id;
    }

    public String getMajor_name() {
        return major_name;
    }

    public void setMajor_name(String major_name) {
        this.major_name = major_name;
    }

    public Integer getDep_id() {
        return dep_id;
    }

    public void setDep_id(Integer dep_id) {
        this.dep_id = dep_id;
    }

	@Override
	public String toString() {
		return "Major [major_id=" + major_id + ", major_name=" + major_name + ", dep_id=" + dep_id + "]";
	}
    
}