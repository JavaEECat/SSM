package com.hqyj.JWSystem.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.InformationMapper;
import com.hqyj.JWSystem.system.model.Information;
import com.hqyj.JWSystem.system.service.InformationService;
@Service
public class InformationServiceimpl implements InformationService {

	@Autowired
	InformationMapper informationMapper;
	@Override
	public List<Information> queryInformation(Information information) {
		return informationMapper.queryInformation(information);
	}
	@Override
	public int addinformation(Information information) {
		return informationMapper.addinformation(information);
	}
	@Override
	public int deleteinformationByid(int information_id) {
		return informationMapper.deleteinformationByid(information_id);
	}

}
