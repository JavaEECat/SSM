package com.hqyj.JWSystem.system.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hqyj.JWSystem.system.model.Major;

public interface MajorMapper {
    int deleteByPrimaryKey(Integer major_id);

    int insert(Major record);

    int insertSelective(Major record);

    Major selectByPrimaryKey(Integer major_id);

    int updateByPrimaryKeySelective(Major record);

    int updateByPrimaryKey(Major record);

	List<Major> queryAll();

	List<Major> querybydep_id(@Param("dep_id") int dep_id);


	int updatemajor(Major major);

	int deleteby_major_id(@Param("major_id")int major_id);

	List<Major> query_distinct_major(Major major);


	//------------------------tf-----------------------------------------
	List<Major> queryAllByMajor();

	Major queryDepByMajor_id(String major_name);

	int deleteby_dep_id(@Param("dep_id")Integer dep_id);
	
	//------------------------tf-----------------------------------------

}