package com.hqyj.JWSystem.system.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.model.ActiveExam;
import com.hqyj.JWSystem.system.model.Exam;
import com.hqyj.JWSystem.system.model.Student;

@Service
public interface ExamService {

	int addExamByExam(Exam exam);

	List<Exam> queryAll();

	int deleteExamByExam_id(int exam_id);

	Exam queryexamByExam_id(int exam_id);

	int updateExamByExam(Exam exam);

	List<ActiveExam> queryAllexamList();
	//分页查询所有的考试安排
	List<ActiveExam> queryAllexamListPage();
	//查询学生自己的考试安排
	List<ActiveExam> queryStudentExamList(int parseInt);
	//查询老师自己的考试安排
	List<ActiveExam> queryTeacherExamList(int parseInt);



}
