package com.hqyj.JWSystem.system.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hqyj.JWSystem.system.model.Class;

public interface ClassMapper {
    int deleteByPrimaryKey(Integer class_id);

    int insert(Class record);

    int insertSelective(Class record);

    Class selectByPrimaryKey(Integer class_id);

    int updateByPrimaryKeySelective(Class record);

    int updateByPrimaryKey(Class record);
  //##########################################################

  	List<Class> queryClassListByClass(Class clazz);

  	int insertWithIdIntSelective(Class record);//id为int类型

	List<Class> query_distinct_class_name(Class clazz);

}