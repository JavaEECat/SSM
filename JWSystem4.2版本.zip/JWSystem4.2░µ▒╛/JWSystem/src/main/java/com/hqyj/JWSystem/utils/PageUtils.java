package com.hqyj.JWSystem.utils;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PageUtils {

	/**
	 * <p>
	 * 得到当前页码（page code）<br>
	 * 如果pc参数不存在，说明pc=1<br>
	 * 如果pc参数存在，需要转化int类型<br>
	 * </p>

	 */
	public static int getPC(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String value = req.getParameter("pc");
		if (value == null || value.trim().isEmpty()) {
			return 1;
		}
		return Integer.parseInt(value);

	}
}
