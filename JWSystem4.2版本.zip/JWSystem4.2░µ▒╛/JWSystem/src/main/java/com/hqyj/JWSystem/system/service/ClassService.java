package com.hqyj.JWSystem.system.service;

import java.util.List;

import com.hqyj.JWSystem.system.model.Class;

public interface ClassService {

	List<Class> queryClassListByClass(Class clazz);

	int updateClassByClass(Class clazz);

	int deleteClassByPrimaryKey(Integer classId);

	int insertClassByClass(Class clazz);

	List<Class> query_distinct_class_name(Class clazz);
}
