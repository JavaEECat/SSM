package com.hqyj.JWSystem.system.model;

public class ChooseCourse {
	private int course_id;
	private String course_name;
	private int teacher_id;
	private String teacher_name;
	private int student_id;
	private int hour;
	private String class_room;



	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public ChooseCourse(int course_id, String course_name, int teacher_id, String teacher_name, int student_id,
			int hour, String class_room) {
		super();
		this.course_id = course_id;
		this.course_name = course_name;
		this.teacher_id = teacher_id;
		this.teacher_name = teacher_name;
		this.student_id = student_id;
		this.hour = hour;
		this.class_room = class_room;
	}

	public ChooseCourse() {
		super();
	}

	public int getCourse_id() {
		return course_id;
	}

	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public int getTeacher_id() {
		return teacher_id;
	}

	public void setTeacher_id(int teacher_id) {
		this.teacher_id = teacher_id;
	}

	public String getTeacher_name() {
		return teacher_name;
	}

	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}

	public int getHour() {
		return hour;
	}

	public void setHour(int hour) {
		this.hour = hour;
	}

	public String getClass_room() {
		return class_room;
	}

	public void setClass_room(String class_room) {
		this.class_room = class_room;
	}

	@Override
	public String toString() {
		return "ChooseCourse [course_id=" + course_id + ", course_name=" + course_name + ", teacher_id=" + teacher_id
				+ ", teacher_name=" + teacher_name + ", student_id=" + student_id + ", hour=" + hour + ", class_room="
				+ class_room + "]";
	}



}
