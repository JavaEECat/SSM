package com.hqyj.JWSystem.system.dao;

import java.util.List;

import com.hqyj.JWSystem.system.model.Teacher;

public interface TeacherMapper {
    int deleteByPrimaryKey(Integer teacher_id);

    int insert(Teacher record);

    int insertSelective(Teacher record);

    Teacher selectByPrimaryKey(Integer teacher_id);

    int updateByPrimaryKeySelective(Teacher record);

    int updateByPrimaryKey(Teacher record);
    //###################################################################################
   	List<Teacher> queryTeacherListByTeacher(Teacher teacher);

   	int insertTeacherByTeacher(Teacher teacher);
}