package com.hqyj.JWSystem.system.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hqyj.JWSystem.system.model.Role;
import com.hqyj.JWSystem.system.model.User;
import com.hqyj.JWSystem.system.model.UserRole;
import com.hqyj.JWSystem.system.service.RoleService;
import com.hqyj.JWSystem.system.service.UserRoleService;
import com.hqyj.JWSystem.system.service.UserService;


@Controller
public class RoleController {
	@Autowired
	private RoleService roleService;
	@Autowired
	private UserService userService;
	@Autowired
	private UserRoleService userRoleService;
	@RequestMapping(value = "/updaterolelist.do")
	public String updaterolelist(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model) {
		String strid = request.getParameter("user_id");
		int user_id = Integer.parseInt(strid);
		User user = userService.queryByUserid(user_id);
		List<Role> rolelist = roleService.queryall();
		session.setAttribute("user", user);
		session.setAttribute("rolelist", rolelist);
		return "view/user/getrole";
		
	}
	@RequestMapping(value = "/getrole.do")
	public String getrole(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model) {
		String user_idstr = request.getParameter("user_id");
		int user_id = Integer.parseInt(user_idstr);
		String role_idstr = request.getParameter("roleId");
		int role_id = Integer.parseInt(role_idstr);
		UserRole userRole  = new UserRole();
		userRole.setUser_id(user_id);
		userRole.setRole_id(role_id);
		userRoleService.deleteByUserId(user_id);
		userRoleService.addUserRole(userRole);
		session.setAttribute("name", "分配角色成功！是否继续分配？");
		List<Role> rolelist = roleService.queryall();
		User user = userService.queryByUserid(user_id);
		session.setAttribute("user", user);
		session.setAttribute("rolelist", rolelist);
		Role role2 = userRoleService.queryroleXZByUserId(user_id);
		session.setAttribute("roleXZ", role2);
		return "view/user/getrole";
	}
	@RequestMapping(value = "/role.do")
	public String queryall(HttpServletRequest req, HttpServletResponse resp,HttpSession session,Model model) throws ServletException, IOException {
		List<Role> rolelist = roleService.queryall();
		session.setAttribute("rolelist", rolelist);
		return "view/roel/rolelist";

	}
	@RequestMapping(value = "/roleadd.do")
	public String roleadd(HttpServletRequest req, HttpServletResponse resp,HttpSession session,
			Role role) throws ServletException, IOException {
		//添加角色
		 roleService.addByRole(role);
		//回显数据
		List<Role> rolelist = roleService.queryall();
		session.setAttribute("rolelist", rolelist);
		return "view/roel/rolelist";
	}
	@RequestMapping(value = "/roledelete.do")
	public String roledelete(HttpServletRequest req, HttpServletResponse resp,HttpSession session) throws ServletException, IOException {
		String role_idstr = req.getParameter("role_id");
		int role_id = Integer.parseInt(role_idstr);
		int i = roleService.delete(role_id);
		List<Role> rolelist = roleService.queryall();
		req.setAttribute("rolelist", rolelist);
		return "view/roel/rolelist";
	}
	@RequestMapping(value = "/roleupdateUI.do")
	public String roleupdateUI(HttpServletRequest req, HttpServletResponse resp,Model model) throws ServletException, IOException {
		String role_idstr = req.getParameter("role_id");
		int role_id = Integer.parseInt(role_idstr);
		Role role = roleService.updateUI(role_id);
		model.addAttribute("role1", role);
		return "view/roel/update";
	}
	@RequestMapping(value = "/roleupdate.do")
	public String roleupdate(HttpServletRequest req, HttpServletResponse resp,Model model,Role role,HttpSession session) throws ServletException, IOException {
		int n = roleService.updateByRole(role);
		List<Role> rolelist = roleService.queryall();
		session.setAttribute("rolelist", rolelist);
         return "view/roel/rolelist";
	}
	
}
