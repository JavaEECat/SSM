package com.hqyj.JWSystem.system.model;

import java.util.Date;

public class Information {
    private Integer id;

    private String info;

    private Date fulltime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Date getFulltime() {
        return fulltime;
    }

    public void setFulltime(Date fulltime) {
        this.fulltime = fulltime;
    }

	@Override
	public String toString() {
		return "Information [id=" + id + ", info=" + info + ", fulltime=" + fulltime + "]";
	}
}