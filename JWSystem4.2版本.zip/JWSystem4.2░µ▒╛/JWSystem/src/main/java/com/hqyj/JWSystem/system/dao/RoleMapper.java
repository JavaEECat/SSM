package com.hqyj.JWSystem.system.dao;


import java.util.List;

import com.hqyj.JWSystem.system.model.Role;

public interface RoleMapper {
    int deleteByPrimaryKey(Integer role_id);

    int insert(Role record);

    int insertSelective(Role record);

    Role selectByPrimaryKey(Integer role_id);

    int updateByPrimaryKeySelective(Role record);

    int updateByPrimaryKey(Role record);

	List<Role> queryall();

}