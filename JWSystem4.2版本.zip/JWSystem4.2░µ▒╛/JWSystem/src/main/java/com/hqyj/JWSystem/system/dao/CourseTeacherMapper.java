package com.hqyj.JWSystem.system.dao;

import com.hqyj.JWSystem.system.model.CourseTeacher;

public interface CourseTeacherMapper {
    int insert(CourseTeacher record);

    int insertSelective(CourseTeacher record);

	int insertCourseTeacherByCourseTeacher(int course_id, int teacher_id);

	int deleteCourseTeacherByCourseTeacher(CourseTeacher courseTeacher);

	int updateCourseTeacherByCourseTeacher(CourseTeacher courseTeacher);
}