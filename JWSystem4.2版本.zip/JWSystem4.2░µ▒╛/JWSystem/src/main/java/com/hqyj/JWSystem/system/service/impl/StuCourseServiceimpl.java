package com.hqyj.JWSystem.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.StuCourseMapper;
import com.hqyj.JWSystem.system.model.Course;
import com.hqyj.JWSystem.system.model.StuCourse;
import com.hqyj.JWSystem.system.model.Student;
import com.hqyj.JWSystem.system.service.StuCourseService;
@Service
public class StuCourseServiceimpl implements StuCourseService {
	@Autowired
	private StuCourseMapper stuCourseMapper;

	@Override
	public List<StuCourse> queryAllBytea_id(Integer teacherId) {
		// TODO Auto-generated method stub
		return stuCourseMapper.queryAllBytea_id(teacherId);
	}
	@Override
	public List<StuCourse> queryScoreByStu_id(Integer student_id) {
		// TODO Auto-generated method stub
		System.out.println("--------queryScoreByStu_id---------------");
		return stuCourseMapper.queryScoreByStu_id(student_id);
	}
	@Override
	public List<Course> queryCourse() {
		// TODO Auto-generated method stub
		return stuCourseMapper.queryCourse();
	}

	@Override
	public int commitScore(StuCourse stuCourse) {
		// TODO Auto-generated method stub
		return stuCourseMapper.commitScore(stuCourse);
	}
	@Override
	public List<Student> queryAllStu() {
		// TODO Auto-generated method stub
		return stuCourseMapper.queryAllStu();
	}
	@Override
	public int update(StuCourse stuCourse) {
		// TODO Auto-generated method stub
		return stuCourseMapper.update(stuCourse);
	}
	@Override
	public List<StuCourse> queryAll() {
		// TODO Auto-generated method stub
		return stuCourseMapper.queryAll();
	}

}
