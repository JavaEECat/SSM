package com.hqyj.JWSystem.system.service;

import com.hqyj.JWSystem.system.model.CourseTeacher;

public interface CourseTeacherService {

	int insertCourseTeacherByCourseTeacher(int course_id, int teacher_id);

	int insert(CourseTeacher courseTeacher);

	int deleteCourseTeacherByCourseTeacher(CourseTeacher courseTeacher);

	int updateCourseTeacherByCourseTeacher(CourseTeacher courseTeacher);

}
