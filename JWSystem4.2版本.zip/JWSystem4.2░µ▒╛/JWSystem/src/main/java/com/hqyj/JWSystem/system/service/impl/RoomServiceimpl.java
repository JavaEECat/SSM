package com.hqyj.JWSystem.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.RoomMapper;
import com.hqyj.JWSystem.system.model.Room;
import com.hqyj.JWSystem.system.service.RoomService;

@Service
public class RoomServiceimpl implements RoomService {

	@Autowired
	private RoomMapper roomMapper;

	@Override
	public List<Room> queryAll() {
		return roomMapper.queryAll();
	}
	
	//----------------------tf--------------------------------------------------
	@Override
	public List<Room> queryAllByRoom() {
		// TODO Auto-generated method stub
		return roomMapper.queryAllByRoom();
	}
	@Override
	public Room selectByPrimaryKey(Integer class_id) {
		// TODO Auto-generated method stub
		return roomMapper.selectByPrimaryKey(class_id);
	}
	@Override
	public Room queryDepByRood_id(String class_room) {
		// TODO Auto-generated method stub
		return roomMapper.queryDepByRood_id(class_room);
	}
	//----------------------tf--------------------------------------------------

	//---.mine
	@Override
	public int addRoomByRoom(Room room) {
		return roomMapper.insertSelective(room);
	}

	@Override
	public int deleteRoomById(int id) {
		return roomMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int updateRoomByRoom(Room room) {
		return roomMapper.updateByPrimaryKeySelective(room);
	}

	@Override
	public Room queryRoomById(int id) {
		return roomMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<Room> queryAllScreen(Room room) {
		// TODO Auto-generated method stub
		return roomMapper.queryAllScreen(room);
	}

	//---
}
