package com.hqyj.JWSystem.system.dao;

import java.util.List;

import com.hqyj.JWSystem.system.model.Classbegin;

public interface ClassbeginMapper {
    int deleteByPrimaryKey(Integer classbegin_id);

    int insert(Classbegin record);

    int insertSelective(Classbegin record);

    Classbegin selectByPrimaryKey(Integer classbegin_id);

    int updateByPrimaryKeySelective(Classbegin record);

    int updateByPrimaryKey(Classbegin record);

	List<Classbegin> queryClassbeginListByClassbegin(Classbegin classbegin);

	int updateClassbeginByClassbegin(Classbegin classbegin);

	int deleteClassbeginByPrimaryKey(Integer classbegin_id);

	int insertClassbeginByClassbegin(Classbegin classbegin);

	List<Classbegin> querybeginListBybegin(Classbegin classbegin);
}