package com.hqyj.JWSystem.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.ChooseCourseMapper;
import com.hqyj.JWSystem.system.model.AfterChoose;
import com.hqyj.JWSystem.system.model.StuCourse;
import com.hqyj.JWSystem.system.service.ChooseCourse;
@Service
public class ChooseCourseImpl implements ChooseCourse {

	@Autowired
	private ChooseCourseMapper chooseCourseMapper;
	@Override
	public List<ChooseCourse> findAllCourse(int student_id) {
		// TODO Auto-generated method stub
		return chooseCourseMapper.findAllCourse(student_id);
	}
	@Override
	public int addcourse(com.hqyj.JWSystem.system.model.ChooseCourse choose) {
		// TODO Auto-generated method stub
		return chooseCourseMapper.addcourse(choose);
	}
	@Override
	public List<ChooseCourse> findCourse(com.hqyj.JWSystem.system.model.ChooseCourse choose) {
		// TODO Auto-generated method stub
		return chooseCourseMapper.findCourse(choose);
	}
	@Override
	public List<AfterChoose> findChoose(int student_id) {
		// TODO Auto-generated method stub
		return chooseCourseMapper.findChoose(student_id);
	}
	@Override
	public int delchooseCourse(StuCourse stuCourse) {
		// TODO Auto-generated method stub
		return chooseCourseMapper.delchooseCourse(stuCourse);
	}

}
