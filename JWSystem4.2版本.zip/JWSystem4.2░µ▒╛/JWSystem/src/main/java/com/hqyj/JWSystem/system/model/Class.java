package com.hqyj.JWSystem.system.model;

public class Class {
    private Integer class_id;

    private String class_name;

    private Integer major_id;

    private String major_name;

    private Integer dep_id;

    public Integer getClass_id() {
        return class_id;
    }

    public void setClass_id(Integer class_id) {
        this.class_id = class_id;
    }

    public String getClass_name() {
        return class_name;
    }

    public void setClass_name(String class_name) {
        this.class_name = class_name;
    }

    public Integer getMajor_id() {
        return major_id;
    }

    public void setMajor_id(Integer major_id) {
        this.major_id = major_id;
    }

    public String getMajor_name() {
        return major_name;
    }

    public void setMajor_name(String major_name) {
        this.major_name = major_name;
    }

    public Integer getDep_id() {
        return dep_id;
    }

    public void setDep_id(Integer dep_id) {
        this.dep_id = dep_id;
    }

	@Override
	public String toString() {
		return "Class [class_id=" + class_id + ", class_name=" + class_name + ", major_id=" + major_id + ", major_name="
				+ major_name + ", dep_id=" + dep_id + "]";
	}
    
}