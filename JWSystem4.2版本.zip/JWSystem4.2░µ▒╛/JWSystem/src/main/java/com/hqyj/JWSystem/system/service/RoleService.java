package com.hqyj.JWSystem.system.service;

import java.util.List;

import com.hqyj.JWSystem.system.model.Role;

public interface RoleService {

	List<Role> queryall();

	int addByRole(Role role);

	int delete(int role_id);

	Role updateUI(int role_id);

	int updateByRole(Role role);

	Role queryRoleById(int role_id);

	

}
