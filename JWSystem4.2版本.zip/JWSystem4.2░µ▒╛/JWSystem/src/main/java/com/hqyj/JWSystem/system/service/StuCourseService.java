package com.hqyj.JWSystem.system.service;

import java.util.List;

import com.hqyj.JWSystem.system.model.Course;
import com.hqyj.JWSystem.system.model.StuCourse;
import com.hqyj.JWSystem.system.model.Student;

public interface StuCourseService {

	List<StuCourse> queryScoreByStu_id(Integer student_id);

	List<StuCourse> queryAllBytea_id(Integer teacherId);

	List<Course> queryCourse();

	int commitScore(StuCourse stuCourse);

	List<Student> queryAllStu();

	int update(StuCourse stuCourse);

	List<StuCourse> queryAll();

}
