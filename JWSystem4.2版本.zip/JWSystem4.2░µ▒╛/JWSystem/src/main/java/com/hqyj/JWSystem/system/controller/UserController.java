package com.hqyj.JWSystem.system.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hqyj.JWSystem.system.model.User;
import com.hqyj.JWSystem.system.service.UserService;
import com.hqyj.JWSystem.utils.PageBean;
import com.hqyj.JWSystem.utils.PageUtils;


@Controller
public class UserController {
	@Autowired
	private UserService userService;
	@RequestMapping(value = "/user.do")
	
	public String list(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model) {
		//List<User> userlist = userService.queryall();
		//session.setAttribute("userlist", userlist);
		try {
			int	pc = PageUtils.getPC(request, response);
			// 3、调用业务
			int ps = 6;
			PageBean<User> pb = userService.queryAllPage(pc, ps);
			request.setAttribute("pb", pb);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// b、给定ps的值:每页记录数（page size）
		
		
		return "view/user/user";
	}
	
	@RequestMapping(value = "/add.do")
	@RequiresPermissions("user:add")
	public String add(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model) {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String salt = "123";
		int hashIterations = 2;
		Md5Hash md5Hash = new Md5Hash(password,salt,hashIterations);
		String md5password = md5Hash.toString();
		System.out.println(md5password);
		User user = new User();
		user.setUsername(username);
		user.setPassword(md5password);
		int i = userService.insert(user);
		if(i>0){
			System.out.println("插入成功！");
		}else{
			System.out.println("插入失败！");
		}
		try {
			int	pc = PageUtils.getPC(request, response);
			// 3、调用业务
			int ps = 6;
			PageBean<User> pb = userService.queryAllPage(pc, ps);
			request.setAttribute("pb", pb);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "view/user/user";
	}

	@RequestMapping(value = "/delete.do")
	public String delete(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model) {
		String strid = request.getParameter("user_id");
		int user_id = Integer.parseInt(strid);
		int i = userService.delete(user_id);
		if(i>0){
			System.out.println("删除成功！");
		}else{
			System.out.println("删除失败！");
		}
		try {
			int	pc = PageUtils.getPC(request, response);
			// 3、调用业务
			int ps = 6;
			PageBean<User> pb = userService.queryAllPage(pc, ps);
			request.setAttribute("pb", pb);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				return "view/user/user";
	}
	@RequestMapping(value = "/deletemany.do")
	public String deletemany(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String[] userselect = req.getParameterValues("UId");
		for (String string : userselect) {
			int useridselect = Integer.parseInt(string);
			System.out.println(useridselect);
			userService.delete(useridselect);
		}
		try {
			int	pc = PageUtils.getPC(req, resp);
			// 3、调用业务
			int ps = 6;
			PageBean<User> pb = userService.queryAllPage(pc, ps);
			req.setAttribute("pb", pb);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "view/user/user";
	}

	
	@RequestMapping(value = "/updateUI.do")
	public String updateUI(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model) {
		String strid = request.getParameter("user_id");
		int user_id = Integer.parseInt(strid);
		User user = userService.queryByUserid(user_id);
		session.setAttribute("user", user);
		return "view/user/update";
		
	}
	@RequestMapping(value = "/update.do")
	public String update(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model) {
		String strid = request.getParameter("user_id");
		int user_id = Integer.parseInt(strid);
		String username = request.getParameter("name");
		String password = request.getParameter("password");
		User user = new User();
		user.setUser_id(user_id);
		user.setUsername(username);
		user.setPassword(password);
		int i  = userService.update(user);
		if(i>0){
			System.out.println("更新成功！");
		}else{
			System.out.println("更新失败！");
		}
		try {
			int	pc = PageUtils.getPC(request, response);
			// 3、调用业务
			int ps = 6;
			PageBean<User> pb = userService.queryAllPage(pc, ps);
			request.setAttribute("pb", pb);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "view/user/user";
		
	}
}
