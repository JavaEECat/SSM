package com.hqyj.JWSystem.system.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.CourseTeacherMapper;
import com.hqyj.JWSystem.system.model.CourseTeacher;
import com.hqyj.JWSystem.system.service.CourseTeacherService;
@Service
public class CourseTeacherServiceimpl implements CourseTeacherService {
	@Autowired
	CourseTeacherMapper CourseTeacherMapper;
	@Override
	public int insertCourseTeacherByCourseTeacher(int course_id, int teacher_id) {
		return CourseTeacherMapper.insertCourseTeacherByCourseTeacher(course_id,teacher_id);
	}
	@Override
	public int insert(CourseTeacher courseTeacher) {
		return CourseTeacherMapper.insert(courseTeacher);
	}
	@Override
	public int deleteCourseTeacherByCourseTeacher(CourseTeacher courseTeacher) {
		return CourseTeacherMapper.deleteCourseTeacherByCourseTeacher(courseTeacher);
	}
	@Override
	public int updateCourseTeacherByCourseTeacher(CourseTeacher courseTeacher) {
		return CourseTeacherMapper.updateCourseTeacherByCourseTeacher(courseTeacher);
	}

}
