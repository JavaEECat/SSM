package com.hqyj.JWSystem.system.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.UserRoleMapper;
import com.hqyj.JWSystem.system.model.Role;
import com.hqyj.JWSystem.system.model.UserRole;
import com.hqyj.JWSystem.system.service.UserRoleService;
@Service
public class UserRoleServiceimpl implements UserRoleService {
	@Autowired
	private UserRoleMapper userRoleMapper;

	@Override
	public int deleteByUserId(int user_id) {
		// TODO Auto-generated method stub
		return userRoleMapper.deleteByUserId(user_id);
	}

	@Override
	public int addUserRole(UserRole userRole) {
		// TODO Auto-generated method stub
		return userRoleMapper.insertSelective(userRole);
	}

	@Override
	public Role queryroleXZByUserId(int user_id) {
		// TODO Auto-generated method stub
		return userRoleMapper.queryroleXZByUserId(user_id);
	}

}
