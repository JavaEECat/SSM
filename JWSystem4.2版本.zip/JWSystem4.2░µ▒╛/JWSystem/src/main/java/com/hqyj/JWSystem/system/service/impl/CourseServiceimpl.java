package com.hqyj.JWSystem.system.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hqyj.JWSystem.system.dao.CourseMapper;
import com.hqyj.JWSystem.system.model.ActiveCourse;
import com.hqyj.JWSystem.system.model.Course;
import com.hqyj.JWSystem.system.service.CourseService;

@Service
public class CourseServiceimpl implements CourseService {

	@Autowired
	private CourseMapper courseMapper;

	// //分页
	// @Override
	// public List<Course> queryAll() {
	// PageHelper.startPage(1, 5);
	// ArrayList<Course> list = courseMapper.getCourseList();
	// PageInfo<Course> page = new PageInfo<Course>(list);
	// System.out.println("总数量：" + page.getTotal());
	// System.out.println("当前页查询记录：" + page.getList().size());
	// System.out.println("当前页码：" + page.getPageNum());
	// System.out.println("每页显示数量：" + page.getPageSize());
	// System.out.println("总页：" + page.getPages());
	// return page.getList();
	// }

	@Override
	public int addCourseByCourse(Course course) {
		return courseMapper.insertSelective(course);
	}

	@Override
	public int deleteCourseByCourse_id(Integer course_id) {
		return courseMapper.deleteByPrimaryKey(course_id);
	}

	@Override
	public Course queryCourseByCourse_id(int course_id) {
		return courseMapper.selectByPrimaryKey(course_id);
	}

	@Override
	public int updateCourseByCourse(Course course) {
		return courseMapper.updateByPrimaryKeySelective(course);
	}

	@Override
	public List<Course> queryAll(List<Course> courseList) {
		return courseMapper.queryAll(courseList);
	}

	@Override
	public List<ActiveCourse> queryCourseDetailsByCourse_id(int course_id) {
		return courseMapper.queryCourseDetailsByCourse_id(course_id);
	}

	@Override
	public List<Course> queryAllCourseByCourse_name_screen(String course_name_screen) {
		return courseMapper.queryAllCourseByCourse_name_screen(course_name_screen);
	}

	@Override
	public List<Course> queryAllById(int course_id) {
		// TODO Auto-generated method stub
		return courseMapper.queryAllById(course_id);
	}

}
