package com.hqyj.JWSystem.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.TeacherMapper;
import com.hqyj.JWSystem.system.model.Teacher;
import com.hqyj.JWSystem.system.service.TeacherService;
@Service
public class TeacherServiceimpl implements TeacherService {
	@Autowired
	TeacherMapper teacherMapper;
	@Override
	public List<Teacher> queryTeacherListByTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		return teacherMapper.queryTeacherListByTeacher( teacher);
	}
	@Override
	public int updateTeacherByTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		return teacherMapper.updateByPrimaryKey(teacher);
	}
	@Override
	public int deleteTeacherByPrimaryKey(Integer teacherId) {
		// TODO Auto-generated method stub
		return teacherMapper.deleteByPrimaryKey(teacherId);
	}
	@Override
	public int insertTeacherByTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		return teacherMapper.insertTeacherByTeacher( teacher);
	}
	@Override
	public Teacher selectByPrimaryKey(int userid) {
		// TODO Auto-generated method stub
		return teacherMapper.selectByPrimaryKey(userid);
	}

}

