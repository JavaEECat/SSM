package com.hqyj.JWSystem.system.service;

import java.util.List;

import com.hqyj.JWSystem.system.model.Major;

public interface MajorService {

	List<Major> queryAll();

	List<Major> querybydep_id(int dep_id);
	
//---------------------------tf----------------------------------------
	List<Major> queryAllByMajor();


	int updatemajor(Major major);

	int deleteby_major_id(int major_id);

	List<Major> query_distinct_major(Major major);


	Major selectByPrimaryKey(Integer major_id);

	Major queryDepByMajor_id(String major_name);

	int deleteby_dep_id(Integer dep_id);
	
	
	//---------------------------tf----------------------------------------


}
