package com.hqyj.JWSystem.system.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.model.ActiveCourse;
import com.hqyj.JWSystem.system.model.Course;

@Service
public interface CourseService {
	// 查询所有课程
	List<Course> queryAll(List<Course> courseList);

	int addCourseByCourse(Course course);

	// 删除课程
	int deleteCourseByCourse_id(Integer course_id);

	// 查询课程
	Course queryCourseByCourse_id(int course_id);

	// 修改课程
	int updateCourseByCourse(Course course);

	// 查询课程详情
	List<ActiveCourse> queryCourseDetailsByCourse_id(int course_id);
	
	//模糊查询
	List<Course> queryAllCourseByCourse_name_screen(String course_name_screen);

	List<Course> queryAllById(int course_id);

}
