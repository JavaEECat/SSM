package com.hqyj.JWSystem.system.dao;

import java.util.List;

import com.hqyj.JWSystem.system.model.Schoolroll;

public interface SchoolrollMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Schoolroll record);

    int insertSelective(Schoolroll record);

    Schoolroll selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Schoolroll record);

    int updateByPrimaryKey(Schoolroll record);

	List<Schoolroll> querySchoolrollBYAll();

	Schoolroll querySchoolrollByStudent_id(int student_id);
	
	 int updateByPrimaryKeySelective2(Schoolroll record);
}