package com.hqyj.JWSystem.system.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hqyj.JWSystem.system.model.ActiveUser;
import com.hqyj.JWSystem.system.model.AfterChoose;
import com.hqyj.JWSystem.system.model.Class;
import com.hqyj.JWSystem.system.model.Classbegin;
import com.hqyj.JWSystem.system.model.Course;
import com.hqyj.JWSystem.system.model.CourseTeacher;
import com.hqyj.JWSystem.system.model.Room;
import com.hqyj.JWSystem.system.model.Teacher;
import com.hqyj.JWSystem.system.service.ChooseCourse;
import com.hqyj.JWSystem.system.service.ClassBeginService;
import com.hqyj.JWSystem.system.service.ClassService;
import com.hqyj.JWSystem.system.service.CourseService;
import com.hqyj.JWSystem.system.service.CourseTeacherService;
import com.hqyj.JWSystem.system.service.RoomService;
import com.hqyj.JWSystem.system.service.TeacherService;

	@Controller
	public class ClassbeginController {
		@Autowired
		private ClassBeginService ClassbeginService;
		@Autowired
		private RoomService roomService;
		@Autowired
		private CourseService courseService;
		@Autowired
		private CourseTeacherService courseTeacherService;
		@Autowired
		private TeacherService teacherService;
		@Autowired
		private ClassService classService;
		@Autowired
		private ChooseCourse chooseCourse;
		/**
		 * 动态SQL查询（没有条件则是查询所有）
		 * 
		 */
		@RequestMapping(value = "/queryClassbeginListByClassbegin.do")
		public String queryClassbeginListByClassbegin(HttpServletRequest request, HttpServletResponse response,
				HttpSession session, Model model, Classbegin Classbegin ) {
			System.out.println("--------queryClassbeginListByClassbegin----------");
			List<Classbegin> ClassbeginList = ClassbeginService.queryClassbeginListByClassbegin(Classbegin);
			model.addAttribute("ClassbeginList", ClassbeginList);
			
			/**查询教室表*/
			List<Room> roomlist=roomService.queryAllByRoom();
			request.setAttribute("roomlist", roomlist);
			
			
			Class clazz = new Class();
			List<Class> clazzlist=classService.queryClassListByClass(clazz);
			request.setAttribute("classlist", clazzlist);
			
			List<Course> cl=null;
			List<Course> courselist=courseService.queryAll(cl);
			request.setAttribute("courselist", courselist);
			
			Teacher teacher = new Teacher();
			List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
			request.setAttribute("teacherlist", teacherList);
			return "view/classbegin/classbeginlist";
		}
		
		
		
		@RequestMapping(value = "/addclassbegin.do")
		public String add(HttpServletRequest request, HttpServletResponse response,
				HttpSession session, Model model, Classbegin Classbegin ) {
			System.out.println("--------add----------");
			List<Classbegin> ClassbeginList = ClassbeginService.queryClassbeginListByClassbegin(Classbegin);
			model.addAttribute("ClassbeginList", ClassbeginList);
			/**查询教室表*/
			List<Room> roomlist=roomService.queryAllByRoom();
			request.setAttribute("roomlist", roomlist);
			
			Class clazz = new Class();
			List<Class> clazzlist=classService.queryClassListByClass(clazz);
			request.setAttribute("classlist", clazzlist);
			
			List<Course> cl=null;
			List<Course> courselist=courseService.queryAll(cl);
			request.setAttribute("courselist", courselist);
			
			Teacher teacher = new Teacher();
			List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
			request.setAttribute("teacherlist", teacherList);
			return "view/classbegin/addclassbegin";
		}
		
		
		
		@RequestMapping(value = "/querybeginListBybegin.do")
		public String querybeginListBybegin(HttpServletRequest request, HttpServletResponse response,
				HttpSession session, Model model, Classbegin Classbegin) {
			System.out.println(Classbegin);
			if("".equals(Classbegin.getClass_time())){
				Classbegin.setClass_time(null);
			}
			if("".equals(Classbegin.getClass_room())){
				Classbegin.setClass_room(null);
			}
			List<Classbegin> ClassbeginList = ClassbeginService.querybeginListBybegin(Classbegin);
			model.addAttribute("ClassbeginList", ClassbeginList);

			/**查询教室表*/
			List<Room> roomlist=roomService.queryAllByRoom();
			request.setAttribute("roomlist", roomlist);
			
			Class clazz = new Class();
			List<Class> clazzlist=classService.queryClassListByClass(clazz);
			request.setAttribute("classlist", clazzlist);
			
			List<Course> cl=null;
			List<Course> courselist=courseService.queryAll(cl);
			request.setAttribute("courselist", courselist);
			
			Teacher teacher = new Teacher();
			List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
			request.setAttribute("teacherlist", teacherList);
			return "view/classbegin/classbeginlist";
		}

		/**
		 * 根据id进行更新前，将数据进行回填
		 * 
		 */
		@RequestMapping(value = "/updateClassbeginUI.do")
		public String updateClassbeginUI(HttpServletRequest request, HttpServletResponse response, HttpSession session,
				Model model, Classbegin Classbegin) {
			System.out.println("-------updateClassbeginUI-----------");
			// 根据id查询只有一个结果
			List<Classbegin> ClassbeginList = ClassbeginService.queryClassbeginListByClassbegin(Classbegin);
			model.addAttribute("update_Classbegin", ClassbeginList.get(0));
			
			/**查询教室表*/
			List<Room> roomlist=roomService.queryAllByRoom();
			request.setAttribute("roomlist", roomlist);
			
			Class clazz = new Class();
			List<Class> clazzlist=classService.queryClassListByClass(clazz);
			request.setAttribute("classlist", clazzlist);
			
			List<Course> cl=null;
			List<Course> courselist=courseService.queryAll(cl);
			request.setAttribute("courselist", courselist);
			
			Teacher teacher = new Teacher();
			List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
			request.setAttribute("teacherlist", teacherList);
			return "view/classbegin/updateclassbegin";
		}

		/**
		 * 根据id进行更新，没有输入值则为null
		 * 
		 */
		@RequestMapping(value = "/updateClassbeginByClassbegin.do")
		public String updateClassbeginByClassbegin(HttpServletRequest request, HttpServletResponse response, HttpSession session,
				Model model, Classbegin Classbegin) {
			int success = ClassbeginService.updateClassbeginByClassbegin(Classbegin);
			CourseTeacher courseTeacher = new CourseTeacher();
			int course_id = Classbegin.getCourse_id();
			int teacher_id = Classbegin.getTeacher_id();
			courseTeacher.setCourse_id(course_id);
			courseTeacher.setTeacher_id(teacher_id);
			System.out.println("-------updateClassbeginByClassbegin-----------"+course_id+teacher_id);
			int n = courseTeacherService.updateCourseTeacherByCourseTeacher(courseTeacher);
			System.out.println("" + n);

			Classbegin = new Classbegin();
			List<Classbegin> ClassbeginList = ClassbeginService.queryClassbeginListByClassbegin(Classbegin);
			for (Classbegin Classbegin2 : ClassbeginList) {
				System.out.println(Classbegin2);
			}
			model.addAttribute("ClassbeginList", ClassbeginList);

			/**查询教室表*/
			List<Room> roomlist=roomService.queryAllByRoom();
			request.setAttribute("roomlist", roomlist);
			
			Class clazz = new Class();
			List<Class> clazzlist=classService.queryClassListByClass(clazz);
			request.setAttribute("classlist", clazzlist);
			
			List<Course> cl=null;
			List<Course> courselist=courseService.queryAll(cl);
			request.setAttribute("courselist", courselist);
			
			Teacher teacher = new Teacher();
			List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
			request.setAttribute("teacherlist", teacherList);
			return "view/classbegin/classbeginlist";
		}

		/**
		 * 通过id进行删除
		 *
		 */
		@RequestMapping(value = "/deleteClassbeginByPrimaryKey.do")
		public String deleteClassbeginByPrimaryKey(HttpServletRequest request, HttpServletResponse response,
				HttpSession session, Model model, Classbegin Classbegin) {
			System.out.println("------deleteClassbeginByPrimaryKey------------");
			int success = ClassbeginService.deleteClassbeginByPrimaryKey(Classbegin.getClassbegin_id());
			int course_id = Classbegin.getCourse_id();
			int teacher_id = Classbegin.getTeacher_id();
			CourseTeacher courseTeacher = new CourseTeacher();
			courseTeacher.setCourse_id(course_id);
			courseTeacher.setTeacher_id(teacher_id);
			int n = courseTeacherService.deleteCourseTeacherByCourseTeacher(courseTeacher);
			System.out.println("" + success+n);

			Classbegin = new Classbegin();
			List<Classbegin> ClassbeginList = ClassbeginService.queryClassbeginListByClassbegin(Classbegin);
			model.addAttribute("ClassbeginList", ClassbeginList);
			
			/**查询教室表*/
			List<Room> roomlist=roomService.queryAllByRoom();
			request.setAttribute("roomlist", roomlist);
			
			Class clazz = new Class();
			List<Class> clazzlist=classService.queryClassListByClass(clazz);
			request.setAttribute("classlist", clazzlist);
			
			List<Course> cl=null;
			List<Course> courselist=courseService.queryAll(cl);
			request.setAttribute("courselist", courselist);
			
			Teacher teacher = new Teacher();
			List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
			request.setAttribute("teacherlist", teacherList);

			return "view/classbegin/classbeginlist";
		}

		/**
		 * 
		 * 
		 */
		@RequestMapping(value = "/insertClassbeginByClassbegin.do")
		public String insertClassbeginByClassbegin(HttpServletRequest request, HttpServletResponse response, HttpSession session,
				Model model, Classbegin Classbegin) {
			System.out.println("------------------");
			int success = ClassbeginService.insertClassbeginByClassbegin(Classbegin);
			int course_id = Classbegin.getCourse_id();
			int teacher_id = Classbegin.getTeacher_id();
			CourseTeacher courseTeacher = new CourseTeacher();
			courseTeacher.setCourse_id(course_id);
			courseTeacher.setTeacher_id(teacher_id);
			int n = courseTeacherService.insert(courseTeacher);
			System.out.println("" + n);

			Classbegin = new Classbegin();
			List<Classbegin> ClassbeginList = ClassbeginService.queryClassbeginListByClassbegin(Classbegin);
			
			for (Classbegin Classbegin2 : ClassbeginList) {
				System.out.println(Classbegin2);
			}
			model.addAttribute("ClassbeginList", ClassbeginList);

			/**查询教室表*/
			List<Room> roomlist=roomService.queryAllByRoom();
			request.setAttribute("roomlist", roomlist);
			
			Class clazz = new Class();
			List<Class> clazzlist=classService.queryClassListByClass(clazz);
			request.setAttribute("classlist", clazzlist);
			
			List<Course> cl=null;
			List<Course> courselist=courseService.queryAll(cl);
			request.setAttribute("courselist", courselist);
			
			Teacher teacher = new Teacher();
			List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
			request.setAttribute("teacherlist", teacherList);
			return "view/classbegin/classbeginlist";
		}

		@RequestMapping(value = "/queryClassTable.do")
		public String queryClassTable(HttpServletRequest request, HttpServletResponse response,
				HttpSession session, Model model, Classbegin Classbegin ) {
			System.out.println("--------queryClassbeginListByClassbegin----------");
			List<Classbegin> ClassbeginList = ClassbeginService.queryClassbeginListByClassbegin(Classbegin);
			model.addAttribute("ClassbeginList", ClassbeginList);
			
			
			ActiveUser user=(ActiveUser) session.getAttribute("activeUser");
			int student_id=Integer.parseInt(user.getUsercode());
			List<AfterChoose> list = chooseCourse.findChoose(student_id);
			request.setAttribute("findafterlist", list);
			/**查询教室表*/
			List<Room> roomlist=roomService.queryAllByRoom();
			request.setAttribute("roomlist", roomlist);
			
			
			List<Course> cl=null;
			List<Course> courselist=courseService.queryAll(cl);
			request.setAttribute("courselist", courselist);
			
			Teacher teacher = new Teacher();
			List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
			request.setAttribute("teacherlist", teacherList);
			return "view/classbegin/classtable";
		}
	
}
