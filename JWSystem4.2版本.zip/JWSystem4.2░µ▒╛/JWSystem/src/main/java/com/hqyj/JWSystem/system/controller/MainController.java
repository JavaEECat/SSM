package com.hqyj.JWSystem.system.controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hqyj.JWSystem.system.model.ActiveUser;
import com.hqyj.JWSystem.system.model.Permission;
import com.hqyj.JWSystem.system.model.Student;
import com.hqyj.JWSystem.system.model.Teacher;
import com.hqyj.JWSystem.system.service.PermissionService;
import com.hqyj.JWSystem.system.service.StudentService;
import com.hqyj.JWSystem.system.service.TeacherService;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.ui.Model;
@Controller
public class MainController  {
	
	@Autowired
	private PermissionService permissionService;
	@Autowired
	private StudentService studengService;
	@Autowired
	private TeacherService teacherService;
	
	@RequestMapping(value = "/main.do")
	public String mai(HttpServletRequest request, HttpServletResponse response, Model model,HttpSession session) {
		System.err.println("----MainController--- main()--------");
		Subject subject = SecurityUtils.getSubject();
		 ActiveUser activeUser = (ActiveUser)subject.getPrincipal();
		 System.err.println(activeUser.getUsercode());
		 int userId = activeUser.getUserid();
		// 1、查询登录用户的菜单
		 List<Permission> menuList = permissionService.queryMenuByUserId(userId);
		// 2、实例化HashMap
			HashMap<Integer, List<Permission>> permissionList = new HashMap<>();
			for (Permission menu : menuList) {
				// 3、菜单下权限列表
				//通过传入当前用户确定自己的菜单
				List<Permission> menuDownPermissionList = permissionService
						.querypermissionByPId_Son(menu.getPermission_id(),userId);
				// 4、 维护父节点和子节点关系
				int pId = menu.getPermission_id();
				permissionList.put(pId, menuDownPermissionList);
				session.setAttribute("menuList", menuList);
				session.setAttribute("permissionList", permissionList);
			}
			/**
			 * 通过用户输入得到账户也就是usecode的长度对用户类型进行筛选
			 **/
			String usercode = activeUser.getUsercode();//
			int userid=0;
			
			try{
				//捕获将string类型转化为int的异常
				 userid= Integer.parseInt(usercode);
				
			}catch(NumberFormatException e){
				e.printStackTrace();
				activeUser.setUsername("admin");
			}
			if(usercode.length() == 10)
			{
				Student stu = studengService.selectByPrimaryKey(userid);
				String student_name = stu.getStudent_name()+" 同学!";
				activeUser.setUsername(student_name);
			}else if(usercode.length() == 8){
				Teacher tea = teacherService.selectByPrimaryKey(userid);
				String teacher_name = tea.getTeacher_name()+" 老师!";
				activeUser.setUsername(teacher_name);
			}else{
				activeUser.setUsername("admin");
			}
		session.setAttribute("activeUser", activeUser);
		return "view/main";

	}
}
