package com.hqyj.JWSystem.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.ClassbeginMapper;
import com.hqyj.JWSystem.system.model.Classbegin;
import com.hqyj.JWSystem.system.service.ClassBeginService;
@Service
public class ClassBeginServiceImpl implements ClassBeginService {
	@Autowired
	ClassbeginMapper classbeginMapper;
	@Override
	public List<Classbegin> queryClassbeginListByClassbegin(Classbegin classbegin) {
		return classbeginMapper.queryClassbeginListByClassbegin(classbegin);
	}

	@Override
	public int updateClassbeginByClassbegin(Classbegin classbegin) {
		return classbeginMapper.updateClassbeginByClassbegin(classbegin);
	}

	@Override
	public int deleteClassbeginByPrimaryKey(Integer classbegin_id) {
		return classbeginMapper.deleteClassbeginByPrimaryKey(classbegin_id);
	}

	@Override
	public int insertClassbeginByClassbegin(Classbegin classbegin) {
		return classbeginMapper.insertClassbeginByClassbegin(classbegin);
	}

	@Override
	public List<Classbegin> querybeginListBybegin(Classbegin classbegin) {
		return classbeginMapper.querybeginListBybegin(classbegin);
	}

}
