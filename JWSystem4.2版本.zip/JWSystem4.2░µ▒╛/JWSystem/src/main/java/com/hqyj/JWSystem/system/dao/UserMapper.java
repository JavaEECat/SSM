package com.hqyj.JWSystem.system.dao;

import java.util.List;
import java.util.Set;

import org.apache.ibatis.annotations.Param;

import com.hqyj.JWSystem.system.model.Role;
import com.hqyj.JWSystem.system.model.User;

public interface UserMapper {
    int deleteByPrimaryKey(Integer user_id);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(Integer user_id);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);

	User queryUserByUserName(String loginName);

	List<User> queryall();

	User queryByUserid(int user_id);

	Role queryRoleNameByUserid(int userId);

	int queryUserTotalRecord();

	List<User> queryCurrentPageDataList(@Param("i")Integer i, @Param("ps")Integer ps);

}