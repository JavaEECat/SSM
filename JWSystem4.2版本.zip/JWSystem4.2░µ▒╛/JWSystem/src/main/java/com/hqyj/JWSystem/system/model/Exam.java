package com.hqyj.JWSystem.system.model;

import java.util.Date;

public class Exam {
    private Integer exam_id;

    private Integer course_id;

    private Date exam_time;

    private Integer exam_longtime;

    private Integer room_id;

    private Integer people;

    private Integer teacher_id;

    public Integer getExam_id() {
        return exam_id;
    }

    public void setExam_id(Integer exam_id) {
        this.exam_id = exam_id;
    }

    public Integer getCourse_id() {
        return course_id;
    }

    public void setCourse_id(Integer course_id) {
        this.course_id = course_id;
    }

    public Date getExam_time() {
        return exam_time;
    }

    public void setExam_time(Date exam_time) {
        this.exam_time = exam_time;
    }

    public Integer getExam_longtime() {
        return exam_longtime;
    }

    public void setExam_longtime(Integer exam_longtime) {
        this.exam_longtime = exam_longtime;
    }

    public Integer getRoom_id() {
        return room_id;
    }

    public void setRoom_id(Integer room_id) {
        this.room_id = room_id;
    }

    public Integer getPeople() {
        return people;
    }

    public void setPeople(Integer people) {
        this.people = people;
    }

    public Integer getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }

	@Override
	public String toString() {
		return "Exam [exam_id=" + exam_id + ", course_id=" + course_id + ", exam_time=" + exam_time + ", exam_longtime="
				+ exam_longtime + ", room_id=" + room_id + ", people=" + people + ", teacher_id=" + teacher_id + "]";
	}
    
    
}