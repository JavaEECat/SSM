package com.hqyj.JWSystem.system.model;

public class ActiveCourse {

	private Integer course_id;

	private String course_name;

	private Double credit;

	private Integer hour;

	private String course_type;
	
	private String major_name;
	
	private String dep_name;

	public Integer getCourse_id() {
		return course_id;
	}

	public void setCourse_id(Integer course_id) {
		this.course_id = course_id;
	}

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public Double getCredit() {
		return credit;
	}

	public void setCredit(Double credit) {
		this.credit = credit;
	}

	public Integer getHour() {
		return hour;
	}

	public void setHour(Integer hour) {
		this.hour = hour;
	}

	public String getCourse_type() {
		return course_type;
	}

	public void setCourse_type(String course_type) {
		this.course_type = course_type;
	}


	public String getDep_name() {
		return dep_name;
	}

	public String getMajor_name() {
		return major_name;
	}

	public void setMajor_name(String major_name) {
		this.major_name = major_name;
	}

	public void setDep_name(String dep_name) {
		this.dep_name = dep_name;
	}

	@Override
	public String toString() {
		return "ActiveCourse [course_id=" + course_id + ", course_name=" + course_name + ", credit=" + credit
				+ ", hour=" + hour + ", course_type=" + course_type + ", major_name=" + major_name + ", dep_name="
				+ dep_name + "]";
	}

	
	
}
