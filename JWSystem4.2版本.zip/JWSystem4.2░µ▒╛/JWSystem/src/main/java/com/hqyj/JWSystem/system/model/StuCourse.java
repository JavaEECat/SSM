package com.hqyj.JWSystem.system.model;

public class StuCourse {
    private Integer student_id;

    private Integer course_id;

    private Integer teacher_id;

    private String course_state;

    private Integer grades;

    public Integer getStudent_id() {
        return student_id;
    }

    public void setStudent_id(Integer student_id) {
        this.student_id = student_id;
    }

    public Integer getCourse_id() {
        return course_id;
    }

    public void setCourse_id(Integer course_id) {
        this.course_id = course_id;
    }

    public Integer getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }

    public String getCourse_state() {
        return course_state;
    }

    public void setCourse_state(String course_state) {
        this.course_state = course_state;
    }

    public Integer getGrades() {
        return grades;
    }

    public void setGrades(Integer grades) {
        this.grades = grades;
    }
}