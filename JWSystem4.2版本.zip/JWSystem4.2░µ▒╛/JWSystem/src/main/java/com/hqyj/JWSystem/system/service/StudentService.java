package com.hqyj.JWSystem.system.service;

import java.util.List;


import com.hqyj.JWSystem.system.model.Student;

public interface StudentService {

	Student queryStudentNumberByStudent_id(int student_idInt);

	int insertSelective(Student student);

	List<Student> queryAllByStudent();

	int deleteByPrimaryKey(int student_id);

	Student selectByPrimaryKey(int student_id);

	int updateByPrimaryKeySelective(Student student);

	List<Student> queryStudentByStudent(Student student);

	Student queryByName(String username);






}
