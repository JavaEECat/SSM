package com.hqyj.JWSystem.system.service;

import java.util.HashMap;
import java.util.List;

import com.hqyj.JWSystem.system.model.Dep;

public interface DepService {

	// --------------------------tfboy-------------------------------

	List<Dep> queryAllByStudent();

	Dep selectByPrimaryKey(Integer dep_id);

	Dep queryDepByDep_id(String dep_name);
	// --------------------------tf-------------------------------

	List<Dep> queryAll();

	int adddep(String dep_name);

	int updateby_dep_id(Dep dep);

	int deleteby_dep_id(int dep_id);

	int addmajor(String major_name, int dep_id);

	List<Dep> querydistinct(String dep_name);

	int deleteby_dep_id_pl(List<Integer> dep_id_check_list);

}
