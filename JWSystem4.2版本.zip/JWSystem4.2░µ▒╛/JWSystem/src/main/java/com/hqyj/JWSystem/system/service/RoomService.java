package com.hqyj.JWSystem.system.service;

import java.util.List;

import com.hqyj.JWSystem.system.model.Room;

public interface RoomService {

	List<Room> queryAll();
	
	//-------------------------tf------------------------------

	int addRoomByRoom(Room room);

	int deleteRoomById(int id);

	int updateRoomByRoom(Room room);

	Room queryRoomById(int id);

	List<Room> queryAllScreen(Room room);

	List<Room> queryAllByRoom();

	Room selectByPrimaryKey(Integer class_id);

	Room queryDepByRood_id(String class_room);

	//-------------------------tf------------------------------
}
