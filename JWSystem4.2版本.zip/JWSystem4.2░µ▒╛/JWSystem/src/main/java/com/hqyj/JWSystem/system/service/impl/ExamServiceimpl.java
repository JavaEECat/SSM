package com.hqyj.JWSystem.system.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.ExamMapper;
import com.hqyj.JWSystem.system.model.ActiveExam;
import com.hqyj.JWSystem.system.model.Exam;
import com.hqyj.JWSystem.system.service.ExamService;

@Service
public class ExamServiceimpl implements ExamService {

	@Autowired
	private ExamMapper examMapper;
	
	@Override
	public int addExamByExam(Exam exam) {
		return examMapper.insert(exam);
	}

	@Override
	public List<Exam> queryAll() {
		return examMapper.queryAll();
	}

	@Override
	public int deleteExamByExam_id(int exam_id) {
		return examMapper.deleteByPrimaryKey(exam_id);
	}

	@Override
	public Exam queryexamByExam_id(int exam_id) {
		// TODO Auto-generated method stub
		return examMapper.selectByPrimaryKey(exam_id);
	}

	@Override
	public int updateExamByExam(Exam exam) {
		// TODO Auto-generated method stub
		return examMapper.updateByPrimaryKeySelective(exam);
	}

	@Override
	public List<ActiveExam> queryAllexamList() {
		// TODO Auto-generated method stub
		return examMapper.queryAllexamList();
	}
	//管理员查询所有考试
	@Override
	public List<ActiveExam> queryAllexamListPage(){
		// TODO Auto-generated method stub
		return examMapper.queryAllexamListPage();
	}

	@Override
	public List<ActiveExam> queryStudentExamList( int Student_id) {
		// TODO Auto-generated method stub
		return examMapper.queryStudentExamList(Student_id);
	}

	@Override
	public List<ActiveExam> queryTeacherExamList(int teacher_id) {
		// TODO Auto-generated method stub
		return examMapper.queryTeacherExamList(teacher_id);
	}


}
