package com.hqyj.JWSystem.system.service.impl;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.UserMapper;
import com.hqyj.JWSystem.system.model.Role;
import com.hqyj.JWSystem.system.model.User;
import com.hqyj.JWSystem.system.service.UserService;
import com.hqyj.JWSystem.utils.PageBean;
@Service
public class UserServiceimpl implements UserService {
	@Autowired
	private UserMapper userMapper;

	@Override
	public User queryUserByUserName(String username) {
		// TODO Auto-generated method stub
		return userMapper.queryUserByUserName(username);
	}

	@Override
	public List<User> queryall() {
		// TODO Auto-generated method stub
		return userMapper.queryall();
	}

	@Override
	public int insert(User user) {
		return userMapper.insert(user);
	}

	@Override
	public int delete(int user_id) {
		// TODO Auto-generated method stub
		return userMapper.deleteByPrimaryKey(user_id);
	}

	@Override
	public User queryByUserid(int user_id) {
		// TODO Auto-generated method stub
		return userMapper.queryByUserid(user_id);
	}

	@Override
	public int update(User user) {
		// TODO Auto-generated method stub
		return userMapper.updateByPrimaryKey(user);
	}

	@Override
	public Role queryRoleNameByUserid(int userId) {
		// TODO Auto-generated method stub
		return userMapper.queryRoleNameByUserid(userId);
	}

	@Override
	public PageBean<User> queryAllPage(int pc, int ps) {
		// 实例化PageBean
		PageBean<User> pb = new PageBean<User>();
		pb.setPc(pc);
		pb.setPs(ps);

		// 查询总记录数:总记录数（total record）
		int tr = userMapper.queryUserTotalRecord();
		pb.setTr(tr);

		// 查询当前页的记录
		List<User> beanList =userMapper.queryCurrentPageDataList((pc - 1) * ps, ps);
		pb.setBeanList(beanList);
		return pb;
	}

	

	

	

	

}
