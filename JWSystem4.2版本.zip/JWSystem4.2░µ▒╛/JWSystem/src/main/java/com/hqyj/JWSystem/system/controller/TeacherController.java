package com.hqyj.JWSystem.system.controller;

import java.text.Collator;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hqyj.JWSystem.system.model.ActiveUser;
import com.hqyj.JWSystem.system.model.Course;
import com.hqyj.JWSystem.system.model.Teacher;
import com.hqyj.JWSystem.system.service.CourseService;
import com.hqyj.JWSystem.system.service.TeacherService;

/**
 * 
 * @author czy
 * 班级控制器（班级: 1班  软件工程  计算机科学与工程学院。。。）
 *
 */
@Controller
public class TeacherController {
	String sort="";
	@Autowired
	private TeacherService teacherService;

	
	

	/**
	 * 动态SQL查询（没有条件则是查询所有）
	 * 
	 */
	@RequestMapping(value = "/queryTeacherListByTeacher.do")
	public String queryTeacherListByTeacher(HttpServletRequest request, HttpServletResponse response,
			HttpSession session, Model model, Teacher teacher,String sort) {//sort 排序
		System.out.println("------------------teacher："+teacher);
		List<String> sexList = Arrays.asList("男","女");
		List<String> titleList = Arrays.asList("高级","中级","低级");
		model.addAttribute("sexList",sexList);
		model.addAttribute("titleList",titleList);
		model.addAttribute("select_sex", teacher.getSex());
		model.addAttribute("select_title", teacher.getTitle());
		
		this.sort=sort;
		System.out.println("sort:"+sort);
		System.out.println("this.sort:"+this.sort);
		if("".equals(teacher.getSex())){
			teacher.setSex(null);
		}
		if("".equals(teacher.getTitle())){
			teacher.setTitle(null);
		}
		// teacher.setTeacher_id(1);
		List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
		
		for (Teacher teacher2 : teacherList) {
			System.out.println(teacher2);
		}

		Collections.sort(teacherList, new TeacherCompartor(sort));//进行排序
		model.addAttribute("teacherList", teacherList);//教师集合
		return "view/teacher/teacherlist";
	}

	/**
	 * 根据id进行更新前，将数据进行回填
	 * 
	 */
	@RequestMapping(value = "/updateTeacherUI.do")
	public String updateTeacherUI(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Teacher teacher) {
		System.out.println("-------updateTeacherUI-----------");
		// 根据id查询只有一个结果
		List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
		for (Teacher teacher2 : teacherList) {
			System.out.println(teacher2);
		}
		model.addAttribute("update_teacher", teacherList.get(0));
		return "view/teacher/updateteacher";
	}

	/**
	 * 根据id进行更新，没有输入值则为null
	 * 
	 */
	@RequestMapping(value = "/updateTeacherByTeacher.do")
	public String updateTeacherByTeacher(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Teacher teacher) {
		System.out.println("-------updateTeacherByTeacher-----------");

		List<String> sexList = Arrays.asList("男","女");
		List<String> titleList = Arrays.asList("高级","中级","低级");
		model.addAttribute("sexList",sexList);
		model.addAttribute("titleList",titleList);
		
		int success = teacherService.updateTeacherByTeacher(teacher);
		System.out.println("" + success);


		List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(new Teacher());
		for (Teacher teacher2 : teacherList) {
			System.out.println(teacher2);
		}
		model.addAttribute("teacherList", teacherList);

		return "view/teacher/teacherlist";
	}

	/**
	 * 通过id进行删除
	 *
	 */
	@RequestMapping(value = "/deleteTeacherByPrimaryKey.do")
	public String deleteTeacherByPrimaryKey(HttpServletRequest request, HttpServletResponse response,
			HttpSession session, Model model, Teacher teacher) {
		System.out.println("------deleteTeacherByPrimaryKey------------");

		List<String> sexList = Arrays.asList("男","女");
		List<String> titleList = Arrays.asList("高级","中级","低级");
		model.addAttribute("sexList",sexList);
		model.addAttribute("titleList",titleList);
		
		int success = teacherService.deleteTeacherByPrimaryKey(teacher.getTeacher_id());
		System.out.println("" + success);

		teacher = new Teacher();
		List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
		for (Teacher teacher2 : teacherList) {
			System.out.println(teacher2);
		}
		model.addAttribute("teacherList", teacherList);

		return "view/teacher/teacherlist";
	}

	/**
	 * 
	 * 
	 */
	@RequestMapping(value = "/insertTeacherByTeacher.do")
	public String insertTeacherByTeacher(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Teacher teacher) {
		System.out.println("-------insertTeacherByTeacher-----------");
		System.out.println(""+teacher);
		
		List<String> sexList = Arrays.asList("男","女");
		List<String> titleList = Arrays.asList("高级","中级","低级");
		model.addAttribute("sexList",sexList);
		model.addAttribute("titleList",titleList);
		
		List<Teacher> allTeacher = teacherService.queryTeacherListByTeacher(new Teacher());
		//设置老师id为8位自增
		if(allTeacher.size()==0){
			teacher.setTeacher_id(20190901);
		}else{
			Collections.sort(allTeacher, new TeacherCompartor("teacher_id"));//进行排序
			Teacher teacher3 = allTeacher.get(allTeacher.size()-1);
			System.out.println("最大id的teacher："+teacher3);
			if(teacher3.getTeacher_id()<20190901){
				teacher.setTeacher_id(20190901);
			}else if(20190901<=teacher3.getTeacher_id()&&teacher3.getTeacher_id()<99999999){
				teacher.setTeacher_id(teacher3.getTeacher_id()+1);
			}else if(99999999<=teacher3.getTeacher_id()){
				model.addAttribute("message", "添加失败，该老师id已经达到最大值(不超过8位)，请维护数据库！！！");
				return "view/teacher/addteacher";
			}
			
		}
		
		System.out.println("添加的最终数据为："+teacher);
		int success = teacherService.insertTeacherByTeacher(teacher);
		System.out.println("" + success);

		teacher = new Teacher();
		List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
		for (Teacher teacher2 : teacherList) {
			System.out.println(teacher2);
		}
		model.addAttribute("teacherList", teacherList);

		return "view/teacher/teacherlist";
	}
	
	
	@RequestMapping(value = "/showTeacherInformation.do")
	public String showTeacherInformation(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Teacher teacher) {
		System.out.println("-------showTeacherInformation-----------");
		
		
		
		ActiveUser activeUser = (ActiveUser) session.getAttribute("activeUser");
		System.out.println(activeUser);
		Integer teacher_id1=null;
		try{
			teacher_id1=Integer.parseInt(activeUser.getUsercode());
		}catch(NumberFormatException e){
			System.err.println("数字格式异常：账号不是纯数字含有其他字符！");
			System.out.println("该老师账号不合法，不能访问！！！");
			model.addAttribute("message", "该老师账号不合法，不能访问！！！");
			return "refuse";
		}
		teacher.setTeacher_id(teacher_id1);
		
		// 根据id查询只有一个结果
		List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
		for (Teacher teacher2 : teacherList) {
			System.out.println(teacher2);
		}

		
		model.addAttribute("update_teacher", teacherList.get(0));
		
		return "view/teacher/teacherinformation";
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////
	//内部类
	class TeacherCompartor implements Comparator<Teacher>{
		private String sort="teacher_id";
		
		public TeacherCompartor(String sort) {
			super();
			// TODO Auto-generated constructor stub
			this.sort=sort;
		}

		@Override
		public int compare(Teacher t1, Teacher t2) {
			// TODO Auto-generated method stub
			if(sort!=null){
				switch (sort) {
					case "": ; 
					case "teacher_id": 	return t1.getTeacher_id().compareTo(t2.getTeacher_id());
					case "teacher_name": return t1.getTeacher_name().compareTo(t2.getTeacher_name());
						//compareTo()方法在对字符串进行比较时，比较的是Unicode码，并不能对汉字进行准确的排序，所以汉字比较时会出现比较混乱的结果。
						//对于英文字符，是比较的ASCII码，得出的结果是正常的
						//return o1.getName().compareTo(o2.getName());   //结果不正确
						
						//解决方案：重写compare方法
//						Collator instance = Collator.getInstance(Locale.CHINA);
//						return instance.compare(t1.getTeacher_name(), t2.getTeacher_name());
						
						
					case "age": 	return t1.getAge().compareTo(t2.getAge());
					case "sex": 	return t1.getSex().compareTo(t2.getSex());
					case "title": 	return t1.getTitle().compareTo(t2.getTitle());
				}
			}
			return t1.getTeacher_id().compareTo(t2.getTeacher_id());
		}


	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////
	

	
}



