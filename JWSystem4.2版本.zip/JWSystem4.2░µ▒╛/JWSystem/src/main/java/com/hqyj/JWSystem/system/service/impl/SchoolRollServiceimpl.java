package com.hqyj.JWSystem.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.SchoolrollMapper;
import com.hqyj.JWSystem.system.model.Schoolroll;
import com.hqyj.JWSystem.system.service.SchoolRollService;
@Service
public class SchoolRollServiceimpl implements SchoolRollService {
	@Autowired
	private SchoolrollMapper schoolrollMapper;
	@Override
	public List<Schoolroll> querySchoolrollBYAll() {
		// TODO Auto-generated method stub
		return schoolrollMapper.querySchoolrollBYAll();
	}
	@Override
	public int deleteByPrimaryKey(int schoolRoll_idInt) {
		// TODO Auto-generated method stub
		return schoolrollMapper.deleteByPrimaryKey(schoolRoll_idInt);
	}
	@Override
	public int insertSelective(Schoolroll schoolroll) {
		// TODO Auto-generated method stub
		return schoolrollMapper.insertSelective(schoolroll);
	}
	@Override
	public Schoolroll querySchoolrollByStudent_id(int student_id) {
		// TODO Auto-generated method stub
		return schoolrollMapper.querySchoolrollByStudent_id(student_id);
	}
	@Override
	public int updateByPrimaryKeySelective2(Schoolroll schoolroll) {
		// TODO Auto-generated method stub
		return schoolrollMapper.updateByPrimaryKeySelective2(schoolroll);
	}

}
