package com.hqyj.JWSystem.system.dao;

import java.util.List;

import com.hqyj.JWSystem.system.model.Course;
import com.hqyj.JWSystem.system.model.StuCourse;
import com.hqyj.JWSystem.system.model.Student;

public interface StuCourseMapper {
    int insert(StuCourse record);

    int insertSelective(StuCourse record);

	List<StuCourse> queryScoreByStu_id(Integer student_id);

	List<StuCourse> queryAllBytea_id(Integer teacherId);

	List<Course> queryCourse();

	int commitScore(StuCourse stuCourse);

	List<Student> queryAllStu();

	int update(StuCourse stuCourse);

	List<StuCourse> queryAll();
}