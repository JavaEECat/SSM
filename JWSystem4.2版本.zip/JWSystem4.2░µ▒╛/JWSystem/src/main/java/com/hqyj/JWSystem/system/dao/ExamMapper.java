package com.hqyj.JWSystem.system.dao;

import java.util.List;
import java.util.Map;

import com.hqyj.JWSystem.system.model.ActiveExam;
import com.hqyj.JWSystem.system.model.Exam;

public interface ExamMapper {
	int deleteByPrimaryKey(Integer exam_id);

	int insert(Exam record);

	int insertSelective(Exam record);

	Exam selectByPrimaryKey(Integer exam_id);

	int updateByPrimaryKeySelective(Exam record);

	int updateByPrimaryKey(Exam record);

	List<Exam> queryAll();

	List<ActiveExam> queryAllexamList();
	//查询所有考试安排
	List<ActiveExam> queryAllexamListPage();

	List<ActiveExam> queryStudentExamList(int student_id);

	List<ActiveExam> queryTeacherExamList(int teacher_id);

}