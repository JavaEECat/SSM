package com.hqyj.JWSystem.system.service;

import java.util.List;

import com.hqyj.JWSystem.system.model.Teacher;

public interface TeacherService {

	List<Teacher> queryTeacherListByTeacher(Teacher teacher);

	int updateTeacherByTeacher(Teacher teacher);

	int deleteTeacherByPrimaryKey(Integer teacherId);

	int insertTeacherByTeacher(Teacher teacher);

	Teacher selectByPrimaryKey(int userid);
}
