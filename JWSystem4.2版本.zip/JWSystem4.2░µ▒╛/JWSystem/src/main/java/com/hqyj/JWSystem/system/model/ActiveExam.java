package com.hqyj.JWSystem.system.model;

public class ActiveExam {

	private int exam_id;
	private String course_name;
	private String exam_time;
	private String timestamp;
	private String exam_longtime;
	private String class_room;
	private String teacher_name;

	public int getExam_id() {
		return exam_id;
	}

	public void setExam_id(int exam_id) {
		this.exam_id = exam_id;
	}

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public String getExam_time() {
		return exam_time;
	}

	public void setExam_time(String exam_time) {
		this.exam_time = exam_time;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getExam_longtime() {
		return exam_longtime;
	}

	public void setExam_longtime(String exam_longtime) {
		this.exam_longtime = exam_longtime;
	}

	public String getClass_room() {
		return class_room;
	}

	public void setClass_room(String class_room) {
		this.class_room = class_room;
	}

	public String getTeacher_name() {
		return teacher_name;
	}

	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}

	@Override
	public String toString() {
		return "ActiveExam [exam_id=" + exam_id + ", course_name=" + course_name + ", exam_time=" + exam_time
				+ ", timestamp=" + timestamp + ", exam_longtime=" + exam_longtime + ", class_room=" + class_room
				+ ", teacher_name=" + teacher_name + "]";
	}

	

}
