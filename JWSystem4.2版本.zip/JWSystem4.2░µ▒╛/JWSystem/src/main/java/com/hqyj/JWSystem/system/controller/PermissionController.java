package com.hqyj.JWSystem.system.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hqyj.JWSystem.system.model.Permission;
import com.hqyj.JWSystem.system.model.Role;
import com.hqyj.JWSystem.system.model.RolePermission;
import com.hqyj.JWSystem.system.model.User;
import com.hqyj.JWSystem.system.service.PermissionService;
import com.hqyj.JWSystem.system.service.RolePermissionService;
import com.hqyj.JWSystem.system.service.RoleService;
import com.hqyj.JWSystem.utils.PageBean;
import com.hqyj.JWSystem.utils.PageUtils;

@Controller
public class PermissionController {
	@Autowired
	private PermissionService permissionService;
	@Autowired
	private RoleService roleService;
	@Autowired
	private RolePermissionService rolePermissionService;
	@RequestMapping(value = "/permissionquery.do")
	public String queryall(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			int	pc = PageUtils.getPC(req, resp);
			// 3、调用业务
			int ps = 6;
			PageBean<Permission> pb = permissionService.queryAllPage(pc, ps);
			req.setAttribute("pb", pb);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// b、给定ps的值:每页记录数（page size）
		return "view/permission/menulist";

	}
	@RequestMapping(value = "/FPRoleMenuUI.do")
	public String FPRoleMenuUI(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //拿到选中行的角色id
		String role_idstr = req.getParameter("role_id");
		int role_id = Integer.parseInt(role_idstr);
		//通过角色id查找角色
		Role role = roleService.queryRoleById(role_id);
		req.setAttribute("role2", role);
		//查找 权限并回显权限和角色信息
		List<Permission> permissionlist = permissionService.queryall();
		req.setAttribute("permissionlist", permissionlist);
		//查询选中的菜单并将其回显通过读取内存数据进行回显
		List<Permission> permissionListXZList = permissionService.query_XZ_CByrole_id(role_id);
		List<Integer> list = new ArrayList<Integer>();
		for (Permission permission : permissionListXZList) {
			list.add(permission.getPermission_id());
		}
		req.setAttribute("ids", list);
		return "view/permission/getmenu";
	}
	
	@RequestMapping(value = "/FPMenuget.do")
	public String FPMenuget(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String role_idstr = req.getParameter("role_id");
		int role_id = Integer.parseInt(role_idstr);
		String[] arrmenu = req.getParameterValues("menuId");
		int i =rolePermissionService.deleteByRoleId(role_id);
		for (String string : arrmenu) {
			int menuid = Integer.parseInt(string);
			RolePermission rolePermission = new RolePermission();
			rolePermission.setRole_id(role_id);
			rolePermission.setPermission_id(menuid);
			int n = rolePermissionService.addRoleMenuByRM(rolePermission);
		}
		req.setAttribute("name", "分配菜单成功！继续分配吗？");
		Role role = roleService.queryRoleById(role_id);
		req.setAttribute("role2", role);
		List<Permission> permissionlist = permissionService.queryall();
		req.setAttribute("permissionlist", permissionlist);
		List<Permission> permissionListXZList = permissionService.query_XZ_CByrole_id(role_id);
		List<Integer> list = new ArrayList<Integer>();
		for (Permission permission : permissionListXZList) {
			list.add(permission.getPermission_id());
		}
		req.setAttribute("ids", list);
		return "view/permission/getmenu";
	}
	
	@RequestMapping(value = "/showUI.do")
	public String showUI(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<Permission> permissionlist = permissionService.queryall();
		req.setAttribute("permissionlist", permissionlist);
		return "view/permission/add";
	}
	@RequestMapping(value = "/permissionadd.do")
	public String permissionadd(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String menu_idstr = req.getParameter("menu_id");
		int p_id = Integer.parseInt(menu_idstr);
		String name = req.getParameter("name");
		String type = req.getParameter("type");
		String desc = req.getParameter("desc");
		String url = req.getParameter("url");
		String percode = req.getParameter("percode");
		Permission permission = new Permission();
		permission.setP_id(p_id);
		permission.setName(name);
		permission.setType(type);
		permission.setUrl(url);
		permission.setPercode(percode);
		int i = permissionService.addpermission(permission);
		List<Permission> permissionlist = permissionService.queryall();
		req.setAttribute("permissionlist", permissionlist);
		// req.getRequestDispatcher("view/user/add.jsp").forward(req, resp);
		return "view/permission/menulist";
	}
	
	@RequestMapping(value = "/permissiondelete.do")
	public String permissiondelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String permission_idstr = req.getParameter("permission_id");
		int permission_id = Integer.parseInt(permission_idstr);
		int i =permissionService.deleteById(permission_id);
		List<Permission> permissionlist = permissionService.queryall();
		req.setAttribute("permissionlist", permissionlist);
		return "view/permission/menulist";
	}
	
	@RequestMapping(value = "/permissionupdateUI.do")
	public String updateUI(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String permission_idstr = req.getParameter("permission_id");
		int permission_id = Integer.parseInt(permission_idstr);
		//查询修改行的内容并回显到页面
		Permission permission = permissionService.updateUI(permission_id);
		req.setAttribute("permission", permission);
		//查询所有内容并回显到页面
		List<Permission> menulist = permissionService.queryall();
		req.setAttribute("menulist", menulist);
		return "view/permission/update";
	}
	@RequestMapping(value = "/permissionupdate.do")
	public String update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String permission_idstr = req.getParameter("menu_id1");
		int permission_id = Integer.parseInt(permission_idstr);
		String p_idstr = req.getParameter("menu_id");
		int p_id = Integer.parseInt(p_idstr);
		String name = req.getParameter("name");
		String type = req.getParameter("type");
		String url = req.getParameter("url");
		String percode = req.getParameter("percode");
		Permission permission = new Permission();
		permission.setPermission_id(permission_id);
		permission.setP_id(p_id);
		permission.setName(name);
		permission.setType(type);
		permission.setUrl(url);
		permission.setPercode(percode);
		int n = permissionService.updateBypermission(permission);
		List<Permission> permissionlist = permissionService.queryall();
		req.setAttribute("permissionlist", permissionlist);
		return "view/permission/menulist";
	}

}
