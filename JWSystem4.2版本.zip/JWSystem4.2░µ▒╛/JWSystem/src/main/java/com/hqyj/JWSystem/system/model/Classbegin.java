package com.hqyj.JWSystem.system.model;

public class Classbegin {
    private Integer classbegin_id;

    private Integer course_id;

    private String course_type;

    private Integer teacher_id;

    private Integer credit;

    private Integer hour;

    private String class_time;

    private Integer class_id;

    private String isJX;

    private String class_room;

    public Integer getClassbegin_id() {
        return classbegin_id;
    }

    public void setClassbegin_id(Integer classbegin_id) {
        this.classbegin_id = classbegin_id;
    }

    public Integer getCourse_id() {
        return course_id;
    }

    public void setCourse_id(Integer course_id) {
        this.course_id = course_id;
    }

    public String getCourse_type() {
        return course_type;
    }

    public void setCourse_type(String course_type) {
        this.course_type = course_type;
    }

    public Integer getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }

    public Integer getCredit() {
        return credit;
    }

    public void setCredit(Integer credit) {
        this.credit = credit;
    }

    public Integer getHour() {
        return hour;
    }

    public void setHour(Integer hour) {
        this.hour = hour;
    }

    public String getClass_time() {
        return class_time;
    }

    public void setClass_time(String class_time) {
        this.class_time = class_time;
    }

    public Integer getClass_id() {
        return class_id;
    }

    public void setClass_id(Integer class_id) {
        this.class_id = class_id;
    }

    public String getIsJX() {
        return isJX;
    }

    public void setIsJX(String isJX) {
        this.isJX = isJX;
    }

    public String getClass_room() {
        return class_room;
    }

    public void setClass_room(String class_room) {
        this.class_room = class_room;
    }

	@Override
	public String toString() {
		return "Classbegin [classbegin_id=" + classbegin_id + ", course_id=" + course_id + ", course_type="
				+ course_type + ", teacher_id=" + teacher_id + ", credit=" + credit + ", hour=" + hour + ", class_time="
				+ class_time + ", class_id=" + class_id + ", isJX=" + isJX + ", class_room=" + class_room + "]";
	}
    
}