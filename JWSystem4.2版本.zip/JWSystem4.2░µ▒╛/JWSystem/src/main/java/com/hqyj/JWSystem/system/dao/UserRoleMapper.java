package com.hqyj.JWSystem.system.dao;

import com.hqyj.JWSystem.system.model.Role;
import com.hqyj.JWSystem.system.model.UserRole;

public interface UserRoleMapper {
    int deleteByPrimaryKey(Integer user_role_id);

    int insert(UserRole record);

    int insertSelective(UserRole record);

    UserRole selectByPrimaryKey(Integer user_role_id);

    int updateByPrimaryKeySelective(UserRole record);

    int updateByPrimaryKey(UserRole record);

	Role queryroleXZByUserId(int user_id);

	int deleteByUserId(int user_id);
}