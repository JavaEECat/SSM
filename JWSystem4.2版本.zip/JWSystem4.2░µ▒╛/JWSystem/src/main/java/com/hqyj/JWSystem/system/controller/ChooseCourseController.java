package com.hqyj.JWSystem.system.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hqyj.JWSystem.system.model.ActiveUser;
import com.hqyj.JWSystem.system.model.AfterChoose;
import com.hqyj.JWSystem.system.model.StuCourse;
import com.hqyj.JWSystem.system.service.ChooseCourse;

@Controller
@RequestMapping("/chooseCourseController")
public class ChooseCourseController {
	@Autowired
	private ChooseCourse chooseCourse;
	@RequestMapping("/findAll.do")
	public ModelAndView findAllCourse(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		ModelAndView mv = new ModelAndView();
		ActiveUser user=(ActiveUser) session.getAttribute("activeUser");
		int student_id=Integer.parseInt(user.getUsercode());
		List<ChooseCourse> list = chooseCourse.findAllCourse(student_id);
		mv.addObject("choosecourse", list);
		mv.setViewName("/view/chooseCourse/CourseList");
		return mv;	
	}

	@RequestMapping("/chooseCourse.do")
	public String chooseCourse(com.hqyj.JWSystem.system.model.ChooseCourse choose, HttpSession session) {

		//测试学生ID
		ActiveUser user=(ActiveUser) session.getAttribute("activeUser");
		choose.setStudent_id(Integer.parseInt(user.getUsercode()));
		int num = chooseCourse.addcourse(choose);
		if(num>0) {
			return "redirect:afterChooseCourse.do";
		}else {
			return "redirect:findAll.do";
		}
	}
	
	@RequestMapping("/afterChooseCourse.do")
	public ModelAndView afterChooseCourse(com.hqyj.JWSystem.system.model.ChooseCourse choose,HttpSession session) {
		ModelAndView mv = new ModelAndView();
		
		//测试学生ID
		ActiveUser user=(ActiveUser) session.getAttribute("activeUser");
		int student_id=Integer.parseInt(user.getUsercode());
				choose.setStudent_id(student_id);
		List<ChooseCourse> list = chooseCourse.findCourse(choose);
		mv.addObject("choosecourse", list);
		mv.setViewName("/view/chooseCourse/afterChoose");
		return mv;	
	}
	
	@RequestMapping("/findChoose.do")
	public ModelAndView findChoose(HttpSession session) {
		ModelAndView mv = new ModelAndView();
		
		//测试学生ID
		ActiveUser user=(ActiveUser) session.getAttribute("activeUser");
		int student_id=Integer.parseInt(user.getUsercode());
		List<AfterChoose> list = chooseCourse.findChoose(student_id);
		mv.addObject("afterchoose", list);
		mv.setViewName("/view/chooseCourse/List");
		return mv;	
	}
	
	@RequestMapping("/CourseManage.do")
	public ModelAndView CourseManage( HttpSession session) {
		ModelAndView mv = new ModelAndView();
		
		//测试学生ID
		ActiveUser user=(ActiveUser) session.getAttribute("activeUser");
		int student_id=Integer.parseInt(user.getUsercode());
		List<AfterChoose> list = chooseCourse.findChoose(student_id);
		mv.addObject("afterchoose", list);
		mv.setViewName("/view/chooseCourse/CourseManage");
		return mv;	
	}
	
	@RequestMapping("/delchooseCourse.do")
	public String delchooseCourse(StuCourse stuCourse,HttpSession session) {
		
		//测试学生ID
		ActiveUser user=(ActiveUser) session.getAttribute("activeUser");
		int student_id=Integer.parseInt(user.getUsercode());
		stuCourse.setStudent_id(student_id);
		int num = chooseCourse.delchooseCourse(stuCourse);
		return "redirect:findAll.do";

	}
}

