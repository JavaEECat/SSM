package com.hqyj.JWSystem.system.service.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.DepMapper;
import com.hqyj.JWSystem.system.model.Dep;
import com.hqyj.JWSystem.system.service.DepService;
@Service
public class DepServiceimpl implements DepService {

	@Autowired
	private DepMapper depMapper;

    //注入Dao层接口
	@Autowired
	DepMapper depmapper;
	@Override
	public List<Dep> queryAll() {
		// TODO Auto-generated method stub
		return depmapper.queryAll();
	}
	@Override
	public int adddep(String dep_name) {
		// TODO Auto-generated method stub
		return depmapper.adddep(dep_name);
	}
	@Override
	public int updateby_dep_id(Dep dep) {
		// TODO Auto-generated method stub
		return depmapper.updateby_dep_id(dep);
	}
	@Override
	public int deleteby_dep_id(int dep_id) {
		// TODO Auto-generated method stub
		return depmapper.deleteby_dep_id(dep_id);
	}
	@Override
	public int addmajor(String major_name,int dep_id) {
		// TODO Auto-generated method stub
		return depmapper.addmajor(major_name,dep_id);
}
	@Override
	public List<Dep> querydistinct(String dep_name) {
		// TODO Auto-generated method stub
		return depmapper.querydistinct(dep_name);
	}
	@Override
	public List<Dep> queryAllByStudent() {
		// TODO Auto-generated method stub
		return depMapper.queryAllByStudent();
	}
	@Override
	public Dep selectByPrimaryKey(Integer dep_id) {
		// TODO Auto-generated method stub
		return depMapper.selectByPrimaryKey(dep_id);
	}
	@Override
	public Dep queryDepByDep_id(String dep_name) {
		// TODO Auto-generated method stub
		return depMapper.queryDepByDep_id(dep_name);
	}
	@Override
	public int deleteby_dep_id_pl(List<Integer> dep_id_check_list) {
		// TODO Auto-generated method stub
		return depMapper.deleteby_dep_id_pl(dep_id_check_list);
	}
	
}
