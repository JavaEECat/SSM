package com.hqyj.JWSystem.system.service;

import java.util.List;

import com.hqyj.JWSystem.system.model.Information;

public interface InformationService {

	List<Information> queryInformation(Information information);

	int addinformation(Information information);

	int deleteinformationByid(int information_id);

}
