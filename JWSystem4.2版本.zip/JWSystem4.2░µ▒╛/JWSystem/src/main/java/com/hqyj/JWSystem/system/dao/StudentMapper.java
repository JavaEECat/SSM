package com.hqyj.JWSystem.system.dao;

import java.util.List;

import com.hqyj.JWSystem.system.model.Student;

public interface StudentMapper {
    int deleteByPrimaryKey(Integer student_id);

    int insert(Student record);

    int insertSelective(Student record);

    Student selectByPrimaryKey(Integer student_id);

    int updateByPrimaryKeySelective(Student record);

    int updateByPrimaryKey(Student record);
    
    
//--------------------------tf--------------------------------------
	Student queryStudentNumberByStudent_id(int student_idInt);

	List<Student> queryAllByStudent();

	List<Student> queryStudentByStudent(Student student);

	Student queryByName(String username);




    
//--------------------------tf--------------------------------------
}