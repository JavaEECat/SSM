package com.hqyj.JWSystem.system.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hqyj.JWSystem.system.model.GradeExamination;

public interface GEMapper {

	int updatencreByStudent_id(GradeExamination ge);

	int updatecetByStudent_id(GradeExamination ge);

	GradeExamination queryByStudent_id(int id);

	List<GradeExamination> queryAll(GradeExamination ge);

	int insertSelective(GradeExamination ges);

}
