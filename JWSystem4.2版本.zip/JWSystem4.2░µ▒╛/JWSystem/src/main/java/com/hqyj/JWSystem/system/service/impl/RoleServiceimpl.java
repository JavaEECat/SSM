package com.hqyj.JWSystem.system.service.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.RoleMapper;
import com.hqyj.JWSystem.system.model.Role;
import com.hqyj.JWSystem.system.service.RoleService;
@Service
public class RoleServiceimpl implements RoleService {
	@Autowired
	private RoleMapper roleMapper;

	@Override
	public List<Role> queryall() {
		// TODO Auto-generated method stub
		return roleMapper.queryall();
	}

	@Override
	public int addByRole(Role role) {
		// TODO Auto-generated method stub
		return roleMapper.insertSelective(role);
	}

	@Override
	public int delete(int role_id) {
		// TODO Auto-generated method stub
		return roleMapper.deleteByPrimaryKey(role_id);
	}

	@Override
	public Role updateUI(int role_id) {
		// TODO Auto-generated method stub
		return roleMapper.selectByPrimaryKey(role_id);
	}

	@Override
	public int updateByRole(Role role) {
		// TODO Auto-generated method stub
		return roleMapper.updateByPrimaryKeySelective(role);
	}

	@Override
	public Role queryRoleById(int role_id) {
		// TODO Auto-generated method stub
		return roleMapper.selectByPrimaryKey(role_id);
	}
	


}
