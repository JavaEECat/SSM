package com.hqyj.JWSystem.system.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hqyj.JWSystem.system.model.ActiveExam;
import com.hqyj.JWSystem.system.model.Course;
import com.hqyj.JWSystem.system.model.Exam;
import com.hqyj.JWSystem.system.model.Room;
import com.hqyj.JWSystem.system.model.Teacher;
import com.hqyj.JWSystem.system.service.RoomService;

@Controller
@RequestMapping(value = "/roomController")
public class RoomController {

	@Autowired
	private RoomService roomService;

	// 添加教室数据
	@RequestMapping(value = "/addRoom.do")
	public String addRoom(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Room room) {
		// 获取教室信息
		String class_room = request.getParameter("course_name");
		Room room2 = new Room();
		room2.setClass_room(class_room);
		System.out.println("-------------------addRoom-----------------" + room2);
		// 添加教室
		int i = roomService.addRoomByRoom(room2);
		if (i > 0) {
			model.addAttribute("message", "添加成功，继续添加吗？");
		} else {
			model.addAttribute("message", "添加失败，重新添加吗？");
		}
		return "view/room/addRoom";
	}

	// 删除教室
	@RequestMapping(value = "/deleteRoom.do")
	public String deleteRoom(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Room room) {
		// 获取要删除的该考试安排的信息（id）
		//
		int id = Integer.parseInt(request.getParameter("id"));
		System.out.println("----------------/deleteRoom.do-------------------------" + id);
		// 删除课程
		int i = roomService.deleteRoomById(id);
		// 删除后查询所有教室
		List<Room> roomList = roomService.queryAll();
		model.addAttribute("roomList", roomList);
		return "view/room/roomList";
	}

	// 教室信息列表
	@RequestMapping(value = "/roomList.do")
	public String roomList(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Room room) {
		System.out.println("-----------------roomController.do--------/roomList..do---------------");
		// 查询所有教室信息
		List<Room> roomList = roomService.queryAll();
		model.addAttribute("roomList", roomList);
		return "view/room/roomList";
	}

	//筛选
	@RequestMapping(value = "/screen.do")
	public String screen(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Room room) {
		System.out.println("-----------------roomController.do--------/screen..do---------------");
		System.out.println("------------------room："+room);
		if("".equals(room.getClass_room())){
			room.setClass_room(null);
		}
		List<Room> screenRoomList = roomService.queryAllScreen(room);
		for (Room room2 : screenRoomList) {
			System.err.println(room2);
		}
		model.addAttribute("roomList", screenRoomList);
		return "view/room/roomList";
	}

	// 修改教室
	@RequestMapping(value = "/updateRoomUI.do")
	public String updateRoomUI(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Room room) {
		System.out.println("----------------/updateRoomUI.do-------------------------");
		// 获取要修改的该教室的信息
		int id = Integer.parseInt(request.getParameter("id"));
		room = roomService.queryRoomById(id);
		System.out.println("-----------------updateRoomUI-----------------" + room);
		model.addAttribute("room", room);
		return "view/room/updateRoom";
	}

	// 修改课程
	@RequestMapping(value = "/updateRoom.do")
	public String updateRoom(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Room room) {
		System.out.println("----------------/updateRoom.do-------------------------" + room);
		// 获取要修改的该教室的信息
		int id = Integer.parseInt(request.getParameter("id"));
		String class_room = request.getParameter("class_room");
		room.setCourse_id(id);
		room.setClass_room(class_room);
		System.out.println("-----------------------------------------" + room);
		int i = roomService.updateRoomByRoom(room);
		// //修改完后查询所有课程并返回列表
		List<Room> roomList = roomService.queryAll();
		model.addAttribute("roomList", roomList);
		return "view/room/roomList";
	}
}
