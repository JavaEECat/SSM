package com.hqyj.JWSystem.system.model;

import java.util.Date;

public class GradeExamination {

	private int student_id;

	private String student_name;
	
	private String idcard;

	private String age;

	private String sex;

	private String ncre;
	
	private String ncre_score;
	private Date ncre_date;

	private String cet;
	private String cet_score;
	private Date cet_date;

	

	public String getStudent_name() {
		return student_name;
	}

	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}

	public String getIdcard() {
		return idcard;
	}

	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getNcre() {
		return ncre;
	}

	public void setNcre(String ncre) {
		this.ncre = ncre;
	}

	public Date getNcre_date() {
		return ncre_date;
	}

	public void setNcre_date(Date ncre_date) {
		this.ncre_date = ncre_date;
	}

	public String getCet() {
		return cet;
	}

	public void setCet(String cet) {
		this.cet = cet;
	}

	public Date getCet_date() {
		return cet_date;
	}

	public void setCet_date(Date cet_date) {
		this.cet_date = cet_date;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public String getNcre_score() {
		return ncre_score;
	}

	public void setNcre_score(String ncre_score) {
		this.ncre_score = ncre_score;
	}

	public String getCet_score() {
		return cet_score;
	}

	public void setCet_score(String cet_score) {
		this.cet_score = cet_score;
	}

	@Override
	public String toString() {
		return "GradeExamination [student_id=" + student_id + ", student_name=" + student_name + ", idcard=" + idcard
				+ ", age=" + age + ", sex=" + sex + ", ncre=" + ncre + ", ncre_score=" + ncre_score + ", ncre_date="
				+ ncre_date + ", cet=" + cet + ", cet_score=" + cet_score + ", cet_date=" + cet_date + "]";
	}


	

}
