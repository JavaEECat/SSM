package com.hqyj.JWSystem.system.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hqyj.JWSystem.system.model.ActiveCourse;
import com.hqyj.JWSystem.system.model.Course;

public interface CourseMapper {

	int deleteByPrimaryKey(Integer course_id);

	int insert(Course record);

	int insertSelective(Course record);

	Course selectByPrimaryKey(Integer course_id);

	int updateByPrimaryKeySelective(Course record);

	int updateByPrimaryKey(Course record);

	// 查询所有课程
	List<Course> queryAll(@Param("list")List<Course> courseList);
	// //分页
	// ArrayList<Course> getCourseList();
	
	//查询课程详情
	List<ActiveCourse> queryCourseDetailsByCourse_id(int course_id);
	
	//模糊查询课程名
	List<Course> queryAllCourseByCourse_name_screen(@Param("course_name_screen")String course_name_screen);

	List<Course> queryAllById(int course_id);

}