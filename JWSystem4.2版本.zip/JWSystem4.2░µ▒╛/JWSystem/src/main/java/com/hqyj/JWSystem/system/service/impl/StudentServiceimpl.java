package com.hqyj.JWSystem.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.StudentMapper;

import com.hqyj.JWSystem.system.model.Student;
import com.hqyj.JWSystem.system.service.StudentService;




@Service
public class StudentServiceimpl implements StudentService {
	@Autowired 
	private StudentMapper studentMapper;

	@Override
	public Student queryStudentNumberByStudent_id(int student_idInt) {
		// TODO Auto-generated method stub
		return studentMapper.queryStudentNumberByStudent_id(student_idInt);
	}

	@Override
	public int insertSelective(Student student) {
		// TODO Auto-generated method stub
		return studentMapper.insertSelective(student);
	}

	@Override
	public List<Student> queryAllByStudent() {
		// TODO Auto-generated method stub
		return studentMapper.queryAllByStudent();
	}

	@Override
	public int deleteByPrimaryKey(int student_id) {
		// TODO Auto-generated method stub
		return studentMapper.deleteByPrimaryKey(student_id);
	}

	@Override
	public Student selectByPrimaryKey(int student_id) {
		// TODO Auto-generated method stub
		return studentMapper.selectByPrimaryKey(student_id);
	}

	@Override
	public int updateByPrimaryKeySelective(Student student) {
		// TODO Auto-generated method stub
		return studentMapper.updateByPrimaryKeySelective(student);
	}

	@Override
	public List<Student> queryStudentByStudent(Student student) {
		// TODO Auto-generated method stub
		return studentMapper.queryStudentByStudent(student);
	}

	@Override
	public Student queryByName(String username) {
		// TODO Auto-generated method stub
		return studentMapper.queryByName(username);
	}




	
}
