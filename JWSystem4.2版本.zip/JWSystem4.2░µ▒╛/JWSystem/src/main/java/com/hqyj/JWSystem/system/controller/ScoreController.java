package com.hqyj.JWSystem.system.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hqyj.JWSystem.system.model.ActiveUser;
import com.hqyj.JWSystem.system.model.Course;
import com.hqyj.JWSystem.system.model.StuCourse;
import com.hqyj.JWSystem.system.model.Student;
import com.hqyj.JWSystem.system.model.Teacher;
import com.hqyj.JWSystem.system.service.StuCourseService;

@Controller
@RequestMapping("/scoreController")
public class ScoreController {
	@Autowired
	private StuCourseService stuCourseService;
	
	@RequestMapping("queryScoreByStu_id.do")
	public ModelAndView queryScoreByStu_id(HttpSession session) {
		ModelAndView mv = new ModelAndView();
		ActiveUser ac = (ActiveUser) session.getAttribute("activeUser");
		int stu_id =Integer.parseInt(ac.getUsercode());
//		Student student=new Student();
//		student.setStudent_id(stu_id);
		List<StuCourse> scores = stuCourseService.queryScoreByStu_id(stu_id);
		List<Course> courses = stuCourseService.queryCourse();
		mv.addObject("score", scores);
		mv.addObject("course", courses);
		mv.setViewName("/view/grades/stugradeslist");
		return mv;
	}
	@RequestMapping("queryAll.do")
	public ModelAndView queryAll(HttpSession session) {
		ModelAndView mv = new ModelAndView();
		List<StuCourse> scores = stuCourseService.queryAll();
		List<Course> courses = stuCourseService.queryCourse();
		mv.addObject("score", scores);
		mv.addObject("course", courses);
		mv.setViewName("/view/grades/stugradeslist");
		return mv;
	}

	@RequestMapping("updateStuScore.do")
	public ModelAndView updateStuScore(StuCourse stuCourse) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("sc", stuCourse);
		mv.setViewName("/view/grades/addScore");
		return mv;
	}
	
	@RequestMapping("update.do")
	public ModelAndView update(StuCourse stuCourse) {
		ModelAndView mv = new ModelAndView();
		int num = stuCourseService.update(stuCourse);
		return mv;
	}
	
	@RequestMapping("queryAllBytea_id.do")
	public ModelAndView queryAllBytea_id(HttpSession session) {
		ModelAndView mv = new ModelAndView();
//		Teacher teacher = (Teacher) session.getAttribute("user");
		//手动设置的tea_id
		Teacher teacher = new Teacher();
		teacher.setTeacher_id(1);
		List<StuCourse> stus = stuCourseService.queryAllBytea_id(teacher.getTeacher_id());
		List<Course> courses = stuCourseService.queryCourse();
		List<Student> stu = stuCourseService.queryAllStu();
		mv.addObject("stu", stu);
		mv.addObject("stus", stus);
		mv.addObject("course", courses);
		mv.setViewName("/view/grades/writeGrades");
		return mv;
	}
	
	@RequestMapping("addStuScore.do")
	public ModelAndView addStuScore(StuCourse stuCourse) {
		System.out.println(stuCourse);
		ModelAndView mv = new ModelAndView();
		mv.addObject("sc", stuCourse);
		mv.setViewName("/view/grades/addScore");
		return mv;
	}
	
	@RequestMapping("commit.do")
	public String commit(StuCourse stuCourse,HttpSession session) {
		System.out.println(stuCourse);
		ModelAndView mv = new ModelAndView();
		int num = stuCourseService.commitScore(stuCourse); 
		if(num>0) {
			return "redirect:queryAllBytea_id.do";
		}else {
			return "redirect:addStuScore.do";
		}
	}
}
