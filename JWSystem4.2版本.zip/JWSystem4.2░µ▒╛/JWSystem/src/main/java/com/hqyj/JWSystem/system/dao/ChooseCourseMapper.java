package com.hqyj.JWSystem.system.dao;

import java.util.List;

import com.hqyj.JWSystem.system.model.AfterChoose;
import com.hqyj.JWSystem.system.model.StuCourse;
import com.hqyj.JWSystem.system.service.ChooseCourse;

public interface ChooseCourseMapper {


	int addcourse(com.hqyj.JWSystem.system.model.ChooseCourse choose);

	List<ChooseCourse> findCourse(com.hqyj.JWSystem.system.model.ChooseCourse choose);

	List<AfterChoose> findChoose(int student_id);

	int delchooseCourse(StuCourse stuCourse);

	List<ChooseCourse> findAllCourse(int student_id);

}
