package com.hqyj.JWSystem.system.service;

import java.util.List;

import com.hqyj.JWSystem.system.model.AfterChoose;
import com.hqyj.JWSystem.system.model.StuCourse;

public interface ChooseCourse {


	int addcourse(com.hqyj.JWSystem.system.model.ChooseCourse choose);

	List<ChooseCourse> findCourse(com.hqyj.JWSystem.system.model.ChooseCourse choose);

	List<AfterChoose> findChoose(int student_id);

	int delchooseCourse(StuCourse stuCourse);

	List<ChooseCourse> findAllCourse(int student_id);

}
