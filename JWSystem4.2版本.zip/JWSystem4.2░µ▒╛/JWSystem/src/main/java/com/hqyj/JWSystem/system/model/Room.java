package com.hqyj.JWSystem.system.model;

public class Room {
    private Integer id;

    private String class_room;

    private Integer course_id;

    private String state;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getClass_room() {
        return class_room;
    }

    public void setClass_room(String class_room) {
        this.class_room = class_room;
    }

    public Integer getCourse_id() {
        return course_id;
    }

    public void setCourse_id(Integer course_id) {
        this.course_id = course_id;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

	@Override
	public String toString() {
		return "Room [id=" + id + ", class_room=" + class_room + ", course_id=" + course_id + ", state=" + state + "]";
	}
    
    
}