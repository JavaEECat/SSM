package com.hqyj.JWSystem.system.service;

import java.util.List;


import com.hqyj.JWSystem.system.model.Role;
import com.hqyj.JWSystem.system.model.User;
import com.hqyj.JWSystem.utils.PageBean;

public interface UserService {

	User queryUserByUserName(String username);

	List<User> queryall();

	int insert(User user);

	int delete(int user_id);

	User queryByUserid(int user_id);

	int update(User user);

	Role queryRoleNameByUserid(int userId);

	PageBean<User> queryAllPage(int pc, int ps);

	

	

	

	

}
