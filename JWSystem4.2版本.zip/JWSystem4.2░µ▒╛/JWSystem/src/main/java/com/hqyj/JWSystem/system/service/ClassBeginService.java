package com.hqyj.JWSystem.system.service;

import java.util.List;

import com.hqyj.JWSystem.system.model.Classbegin;

public interface ClassBeginService {

	List<com.hqyj.JWSystem.system.model.Classbegin> queryClassbeginListByClassbegin(Classbegin classbegin);

	int updateClassbeginByClassbegin(Classbegin classbegin);

	int deleteClassbeginByPrimaryKey(Integer classbegin_id);

	int insertClassbeginByClassbegin(Classbegin classbegin);

	List<com.hqyj.JWSystem.system.model.Classbegin> querybeginListBybegin(Classbegin classbegin);

}
