package com.hqyj.JWSystem.shiro.Realm;



import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.springframework.beans.factory.annotation.Autowired;

import com.hqyj.JWSystem.system.model.ActiveUser;
import com.hqyj.JWSystem.system.model.Permission;
import com.hqyj.JWSystem.system.model.Role;
import com.hqyj.JWSystem.system.model.User;
import com.hqyj.JWSystem.system.service.PermissionService;
import com.hqyj.JWSystem.system.service.UserService;




public class CustomRealm extends AuthorizingRealm {
	@Autowired
	private UserService userService;
	@Autowired
	private PermissionService permissionService;
	
     
	@Override
	public void setName(String name) {
		// TODO Auto-generated method stub
		super.setName("customRealm");
	}

	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		// 从 principals获取主身份信息
				// 将getPrimaryPrincipal方法返回值转为真实身份类型
				// （在上边的doGetAuthenticationInfo认证通过填充到SimpleAuthenticationInfo中身份类型），
				ActiveUser activeUser = (ActiveUser) principals.getPrimaryPrincipal();
				// 根据身份信息获取权限信息
				// 从数据库获取到权限数据
				int userId = activeUser.getUserid();
				List<Permission> permissionList = null;
				try {
					permissionList = permissionService.querypermissionByUserId(userId);
				} catch (Exception e) {
					e.printStackTrace();
				}
				List<String> permissions = new ArrayList<String>();
				if (permissionList != null) {
					for (Permission permission : permissionList) {
						permissions.add(permission.getPercode());
					}
				}
				//List<String> permissions = new ArrayList<String>();
				//permissions.add("user:userlist");// 用户列表
				//permissions.add("user:add");// 用户增加
				Role rolename = userService.queryRoleNameByUserid(userId);
				
				// ....
				// 查到权限数据，返回授权信息(要包括 上边的permissions)
				SimpleAuthorizationInfo simpleAuthorizationInfo = new SimpleAuthorizationInfo();
				// 将上边查询到授权信息填充到simpleAuthorizationInfo对象中
				simpleAuthorizationInfo.addStringPermissions(permissions);
				simpleAuthorizationInfo.addRole(rolename.getRole_name());
				
				return simpleAuthorizationInfo;
	}

	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
		//1.从token中取出用户输入
		String username = (String) token.getPrincipal();
		//2.通过usercode查询数据库返回用户信息
		User user = userService.queryUserByUserName(username);
		if (user == null) {
			return null;
		}
		String password = user.getPassword();
		String salt = "123";
		//String password = "111";
		ActiveUser activeUser = new ActiveUser();
		activeUser.setUserid(user.getUser_id());
		activeUser.setUsercode(user.getUsername());
		SimpleAuthenticationInfo simpleAuthenticationInfo = new SimpleAuthenticationInfo(
				activeUser, password,ByteSource.Util.bytes(salt), this.getName());
			
		return simpleAuthenticationInfo;
	}

}
