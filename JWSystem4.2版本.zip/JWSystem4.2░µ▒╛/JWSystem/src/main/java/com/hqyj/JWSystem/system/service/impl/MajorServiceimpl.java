package com.hqyj.JWSystem.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.MajorMapper;
import com.hqyj.JWSystem.system.model.Major;
import com.hqyj.JWSystem.system.service.MajorService;
@Service
public class MajorServiceimpl implements MajorService {
    //注入Dao层接口
	@Autowired
	MajorMapper majormapper;
	@Override
	public List<Major> queryAll() {
		// TODO Auto-generated method stub
		return majormapper.queryAll();
	}
	@Override
	public List<Major> querybydep_id(int dep_id) {
		// TODO Auto-generated method stub
		return majormapper.querybydep_id(dep_id);
	}

	@Override
	public int updatemajor(Major major) {
		// TODO Auto-generated method stub
		return majormapper.updatemajor(major);
	}
	@Override
	public int deleteby_major_id(int major_id) {
		// TODO Auto-generated method stub
		return majormapper.deleteby_major_id(major_id);
	}
	@Override
	public List<Major> query_distinct_major(Major major) {
		// TODO Auto-generated method stub
		return majormapper.query_distinct_major(major);
	}


	
	//------------------------------tf--------------------------------
	@Override
	public List<Major> queryAllByMajor() {
		// TODO Auto-generated method stub
		return majormapper.queryAllByMajor();
	}
	@Override
	public Major selectByPrimaryKey(Integer major_id) {
		// TODO Auto-generated method stub
		return majormapper.selectByPrimaryKey(major_id);
	}
	@Override
	public Major queryDepByMajor_id(String major_name) {
		// TODO Auto-generated method stub
		return majormapper.queryDepByMajor_id(major_name);
	}
	@Override
	public int deleteby_dep_id(Integer dep_id) {
		// TODO Auto-generated method stub
		return majormapper.deleteby_dep_id(dep_id);
	}
	
	
	//------------------------------tf--------------------------------

}
