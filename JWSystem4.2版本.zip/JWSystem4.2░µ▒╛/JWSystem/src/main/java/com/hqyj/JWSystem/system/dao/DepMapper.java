package com.hqyj.JWSystem.system.dao;

import java.util.List;

import java.util.List;

import org.apache.ibatis.annotations.Param;


import com.hqyj.JWSystem.system.model.Dep;

public interface DepMapper {
    int deleteByPrimaryKey(Integer dep_id);

    int insert(Dep record);

    int insertSelective(Dep record);

    Dep selectByPrimaryKey(Integer dep_id);

    int updateByPrimaryKeySelective(Dep record);

    int updateByPrimaryKey(Dep record);


    
    //--------------------------------tf----------------------------------------
	List<Dep> queryAllByStudent();
	
	Dep queryDepByDep_id(String dep_name);
	
    //--------------------------------tf----------------------------------------
    


	List<Dep> queryAll();

	int adddep(@Param("dep_name")String dep_name);


	int updateby_dep_id(Dep dep);

	int deleteby_dep_id(@Param("dep_id")int dep_id);

	int addmajor(@Param("major_name")String major_name,@Param("dep_id")int dep_id);

	List<Dep> querydistinct(@Param("dep_name")String dep_name);

	int deleteby_dep_id_pl(@Param("dep_id_check_list")List<Integer> dep_id_check_list);

}