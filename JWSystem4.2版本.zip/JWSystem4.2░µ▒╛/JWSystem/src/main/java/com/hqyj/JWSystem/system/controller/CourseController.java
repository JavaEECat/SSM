package com.hqyj.JWSystem.system.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hqyj.JWSystem.system.model.ActiveCourse;
import com.hqyj.JWSystem.system.model.Class;
import com.hqyj.JWSystem.system.model.Classbegin;
import com.hqyj.JWSystem.system.model.Course;
import com.hqyj.JWSystem.system.service.ClassBeginService;
import com.hqyj.JWSystem.system.service.ClassService;
import com.hqyj.JWSystem.system.service.CourseService;

@Controller
@RequestMapping(value = "/courseController")
public class CourseController {

	@Autowired
	private CourseService courseService;
	
	@Autowired
	private ClassBeginService ClassbeginService;
	
	@Autowired
	private ClassService classService;

	// 课程列表
	// //分页
	// @RequestMapping(value = "/courseLi.do")
	// public String courseLi(HttpServletRequest request, HttpServletResponse
	// response, HttpSession session,
	// Model model){
	// System.out.println("-----------------courseList--------/courseList.do---------------");
	// //查询所有课程
	// List<Course> courseList=courseService.queryAll();
	// for (Course course2 : courseList) {
	// System.out.println(course2);
	// }
	// model.addAttribute("courseList",courseList);
	// return"view/course/courseLi";
	//
	// }

	@RequestMapping(value = "/courseList.do")
	public String courseList(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model) {
		System.err.println("-----------------courseList--------/courseList.do---------------");
		// 查询所有课程
		List<Course> cl=null;
		List<Course> courseList = courseService.queryAll(cl);
		model.addAttribute("courseList", courseList);
		return "view/course/courseList";

	}
	@RequestMapping(value = "/courseScreen.do")
	public String courseScreen(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model,Course course) {
		System.err.println("-----------------courseList--------/courseScreen.do---------------");
		// 模糊查询所有课程
		String course_name_screen=request.getParameter("course_name_screen");
		System.err.println(""+course_name_screen);
		List<Course> courseList = courseService.queryAllCourseByCourse_name_screen(course_name_screen);
		model.addAttribute("courseList", courseList);
		return "view/course/courseList";
		
	}

	// 课程列表
	@RequestMapping(value = "/courseEdit.do")
	public String courseEdit(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Course course) {
		System.err.println("-----------------courseEdit--------/courseEdit.do---------------");
		//拿到课程ID
		int course_id = Integer.parseInt(request.getParameter("course_id"));
		System.err.println(course.getCourse_id());
		//先查看该课程类型是否为选修
		Course course2=courseService.queryCourseByCourse_id(course_id);
		model.addAttribute("activeCourse", course2);
		if(course2.getCourse_type().equals("选修")){
			//若为选修，则直接返回页面
			model.addAttribute("activeCourseList", course2);
			return "view/course/courseEdit";
		}
		//通过课程ID查询开课表的班级
		Classbegin classBegin=new Classbegin();
		classBegin.setCourse_id(course_id);
		List<Classbegin> cl=ClassbeginService.querybeginListBybegin(classBegin);
		System.err.println("通过课程ID查询开课表的班级:---数据条数"+cl.size()+cl);
		if(cl!=null){
			for (Classbegin cb : cl) {
				int class_id=cb.getClass_id();
				Class c=new Class();
				c.setClass_id(class_id);
				List<Class> clist=classService.queryClassListByClass(c);
				for (Class class1 : clist) {
					if(class1.getMajor_id()==null||class1.getDep_id()==null){
						model.addAttribute("message", "还未开课，暂无院系相关信息！");
						//直接返回页面
						model.addAttribute("activeCourseList", course2);
						return "view/course/courseEdit";
					}
					// 查询课程详情
					List<ActiveCourse> activeCourseList = courseService.queryCourseDetailsByCourse_id(course_id);
					List<String> deplistTemp = new ArrayList();
					List<String> majorlistTemp = new ArrayList();
					//去除重复的院系名字
			        for(int i=0;i<activeCourseList.size();i++){
			        	for (ActiveCourse ActiveCourse : activeCourseList) {
			        		System.err.println(ActiveCourse);
			        		String majorname=ActiveCourse.getMajor_name();
							String dep_name=ActiveCourse.getDep_name();
							if(!deplistTemp.contains(dep_name)){  
								deplistTemp.add(dep_name);  
							}
							if(!majorlistTemp.contains(majorname)){
								majorlistTemp.add(majorname);
							}
						}
			        }
			        
			        model.addAttribute("majorlistTemp", majorlistTemp);
			        model.addAttribute("deplistTemp", deplistTemp);
					model.addAttribute("activeCourseList", activeCourseList);
					return "view/course/courseEdit2";
				}
			}
		}
		model.addAttribute("message", "还未开课，暂无院系相关信息！");
		model.addAttribute("activeCourseList", course2);
		return "view/course/courseEdit";
	}

	// 添加新课程
	@RequestMapping(value = "/addCourse.do")
	public String addCourse(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Course course) {
		// 获取课程信息
		String course_type = request.getParameter("course_type");
		course.setCourse_type(course_type);
		System.err.println(course);
		// 添加课程
		int i = courseService.addCourseByCourse(course);
		if (i > 0) {
			model.addAttribute("message", "添加成功，继续添加吗？");
		} else {
			model.addAttribute("message", "添加失败，重新添加吗？");
		}
		return "view/course/addCourse";
	}

	// 删除课程
	@RequestMapping(value = "/deleteCourse.do")
	public String deleteCourse(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Course course) {
		// 获取要删除的该课程的信息（课程id）
		//
		int course_id = Integer.parseInt(request.getParameter("course_id"));
		System.err.println("----------------/deleteCourse.do-------------------------" + course_id);
		// 删除课程
		int i = courseService.deleteCourseByCourse_id(course_id);
		// 删除后查询所有课程
		List<Course> cl=null;
		List<Course> courseList = courseService.queryAll(cl);
		model.addAttribute("courseList", courseList);
		return "view/course/courseList";
	}

	// 修改课程ui
	@RequestMapping(value = "/updateCourseUI.do")
	public String updateCourseUI(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Course course) {
		// 获取要修改的该课程的信息（课程id）
		int course_id = Integer.parseInt(request.getParameter("course_id"));
		System.err.println("----------------/updateCourseUI.do-------------------------" + course_id);
		Course course2 = courseService.queryCourseByCourse_id(course_id);
		//
		session.setAttribute("updateCourse", course2);
		return "view/course/updateCourse";
	}

	// 修改课程
	@RequestMapping(value = "/updateCourse.do")
	public String updateCourse(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Course course,ActiveCourse activeCourse) {
		System.err.println("----------------/updateCourse.do-------------------------");
		System.err.println("---------------------------------------"+activeCourse);
		// 获取要修改的该课程的信息
		int course_id = Integer.parseInt(request.getParameter("course_id"));
		course.setCourse_id(course_id);
		int i = courseService.updateCourseByCourse(course);
		// //修改完后查询所有课程并返回列表
		List<Course> cl=null;
		List<Course> courseList = courseService.queryAll(cl);
		model.addAttribute("courseList", courseList);
		return "view/course/courseList";
	}

}
