package com.hqyj.JWSystem.system.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.model.GradeExamination;

@Service
public interface GEService {

	int updatencreByStudent_id(GradeExamination GradeExamination);

	int updatecetByStudent_id(GradeExamination GradeExamination);

	GradeExamination queryByStudent_id(int id);

	List<GradeExamination> queryAll(GradeExamination stuge);

	int insertSelective(GradeExamination ges);

}
