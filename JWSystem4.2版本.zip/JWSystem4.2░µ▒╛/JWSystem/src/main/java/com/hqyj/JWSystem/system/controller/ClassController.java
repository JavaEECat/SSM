package com.hqyj.JWSystem.system.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.hqyj.JWSystem.system.dao.DepMapper;
import com.hqyj.JWSystem.system.dao.MajorMapper;
import com.hqyj.JWSystem.system.model.Class;
import com.hqyj.JWSystem.system.model.Dep;
import com.hqyj.JWSystem.system.model.Major;
import com.hqyj.JWSystem.system.model.Teacher;
import com.hqyj.JWSystem.system.service.ClassService;
import com.hqyj.JWSystem.system.service.DepService;
import com.hqyj.JWSystem.system.service.MajorService;


	@Controller
	public class ClassController {
		String sort="";
		@Autowired
		private ClassService classService;
		
		@Autowired
		private MajorService majorService;
		
		@Autowired
		private DepService depService;
		

		/////////////////////////

		@Autowired
		MajorMapper majorMapper;
		/////////////////////////
		

		/**
		 * 
		 * 通过表中的所有字段作为条件（是否为null动态生成sql）进行查询（若有int ID 这id>0有效）
		 */
		@RequestMapping(value = "/queryClassListByClass.do")
		public String queryClassListByClass(HttpServletRequest request, HttpServletResponse response, HttpSession session,
				Model model,Class clazz,String sort) {
			System.out.println("------queryClassListByClass------------"+clazz);

			
			model.addAttribute("select_class_name",clazz.getClass_name());
			model.addAttribute("select_major_name", clazz.getMajor_name());
			model.addAttribute("select_dep_id", clazz.getDep_id());
			
			this.sort=sort;
			System.out.println("sort:"+sort);
			System.out.println("this.sort:"+this.sort);
			if("".equals(clazz.getClass_name())){
				clazz.setClass_name(null);
			}
			if("".equals(clazz.getMajor_name())){
				clazz.setMajor_name(null);
			}
			if("".equals(clazz.getDep_id())){
				clazz.setDep_id(null);
			}
			
			//查询所有院系
			List<Dep> depList = depService.queryAll();
			for (Dep dep : depList) {
				System.out.println(dep);
			}
			//查询该院系的所有专业集合
			System.out.println("clazz.getDep_id():"+clazz.getDep_id());
			List<Major> majorList=new ArrayList<Major>();
			if(clazz.getDep_id()==null||"".equals(clazz.getDep_id())){
				majorList = majorService.queryAll();
			}else{
				 majorList = majorService.querybydep_id(clazz.getDep_id());
			}
			
			for (Major major : majorList) {
				System.out.println("-major-"+major);
			}
			//查询班级集合
			List<Class> classList=classService.queryClassListByClass(clazz);
			//查询该院系 专业中的班级名集合
			List<String> class_nameList =new ArrayList<>();
//			List<String> class_nameList = Arrays.asList("1班","2班","3班","4班","5班","6班","7班","8班","9班","10班","11班","12班");
			for (Class class1 : classList) {
				System.out.println(class1);
				class_nameList.add(class1.getClass_name());
			}
			
			
			
			Collections.sort(classList, new ClassCompartor());//进行排序
			model.addAttribute("depList", depList);//院系集合
			model.addAttribute("majorList", majorList);//专业集合
			model.addAttribute("classList", classList);//班级集合
			model.addAttribute("class_nameList",class_nameList);
			return "view/clazz/classlist";
		}
		/**
		 * 
		 * 通过id找到该数据
		 */
		@RequestMapping(value = "/updateClassUI.do")
		public String updateClassUI(HttpServletRequest request, HttpServletResponse response, HttpSession session,
				Model model,Class clazz,Integer isFirstVisit) {
			System.out.println("-------updateClassUI-----------");
			System.out.println("clazz:"+clazz);
			System.out.println("isFirstVisit:"+isFirstVisit);

			if(isFirstVisit==null){//第一次跳转到更新页面回显数据是数据库里面的数据。
				//通过id查询只有一条
				System.out.println("第一次访问");
				List<Class> classList=classService.queryClassListByClass(clazz);
				for (Class class1 : classList) {
					System.out.println(class1);
				}
				clazz=classList.get(0);
				model.addAttribute("update_class", classList.get(0));
			}else{//如果在更新页面进行了选择框后回显数据就不是数据库里面的数据了
				System.out.println("不是第一次访问");
				model.addAttribute("update_class",clazz);
			}
			
			
			
			//查询所有院系集合
			List<Dep> depList = depService.queryAll();
			//查询该院系的所有专业集合
			List<Major> majorList=new ArrayList<Major>();
			if(clazz.getDep_id()==null||"".equals(clazz.getDep_id())){
				System.out.println("没有选择院系，查询所有专业");
				majorList = majorService.queryAll();
			}else{
				System.out.println("查询该院系的所有专业");
				 majorList = majorService.querybydep_id(clazz.getDep_id());
			}
			
			for (Major major : majorList) {
				System.out.println("-major-"+major);
			}
			
			model.addAttribute("majorList", majorList);//专业集合
			model.addAttribute("depList", depList);//专业集合
			return "view/clazz/updateclass";
		}
		
		/**
		 * 
		 * 通过id找到该数据，用表中的字段（除了id）作为更新字段进行更新
		 */
		@RequestMapping(value = "/updateClassByClass.do")
		public String updateClassByClass(HttpServletRequest request, HttpServletResponse response, HttpSession session,
				Model model,Class clazz) {
			System.out.println("-------updateClassByClass-----------");
			System.out.println(clazz);
			///------------------------------------------------------------------
			//根据专业id查询该专业的专业名（没有该业务），并赋值给clazz
			if(clazz.getMajor_id()==null){
			}else{
				Major major = majorMapper.selectByPrimaryKey(clazz.getMajor_id());
				clazz.setMajor_name(major.getMajor_name());
			}
			
			///--------------------------------------------------------------------

			//更新之前判断该院系 该专业 中是否存在该班级  不存在则更新  否则更新失败（提示该班级已经存在，请检查数据！！）
			List<Class> queryClassListByClass = classService.queryClassListByClass(clazz);
			System.out.println("queryClassListByClass:"+queryClassListByClass);
			for (Class class1 : queryClassListByClass) {
				System.out.println(class1);
			}
			
			if(queryClassListByClass.size()>=1){
				model.addAttribute("message", "该班级已经存在，请检查数据！！");
				Integer isFirstVisit=1;
				return updateClassUI(request, response, session, model, clazz,isFirstVisit);//大于0代表不是第一次访问updateClassUI
			}
			System.out.println("数据准备更新为clazz:"+clazz);
			int success=classService.updateClassByClass(clazz);
			System.out.println(""+success);
			

			List<Class> classList=classService.queryClassListByClass(new Class());
			//查询所有院系集合
			List<Dep> depList = depService.queryAll();
			//查询所有专业
			List<Major> majorList = majorService.queryAll();
			model.addAttribute("depList", depList);//专业集合
			model.addAttribute("majorList", majorList);
			model.addAttribute("classList", classList);
			return "view/clazz/classlist";
		}
		
		/**
		 * 
		 * 通过id找到该数据，用表中的字段作为更新字段（是否为null动态生成sql）进行更新
		 */
		@RequestMapping(value = "/deleteClassByPrimaryKey.do")
		public String deleteClassByPrimaryKey(HttpServletRequest request, HttpServletResponse response, HttpSession session,
				Model model,Class clazz) {
			System.out.println("------------------");

			int success=classService.deleteClassByPrimaryKey(clazz.getClass_id());
			System.out.println(""+success);

			clazz=new Class();
			List<Class> classList=classService.queryClassListByClass(clazz);
			for (Class class1 : classList) {
				System.out.println(class1);
			}
			//查询所有院系集合
			List<Dep> depList = depService.queryAll();
			model.addAttribute("depList", depList);//专业集合
			model.addAttribute("classList", classList);
			return "view/clazz/classlist";
		}
		
		/**
		 * 
		 * 添加（是否为null动态生成sql）进行添加
		 */
		@RequestMapping(value = "/insertClassByClassUI.do")
		public String insertClassByClassUI(HttpServletRequest request, HttpServletResponse response, HttpSession session,
				Model model,Class clazz) {
			System.out.println("------insertClassByClassUI------------");
			System.out.println("clazz:"+clazz);
			model.addAttribute("class_name", clazz.getClass_name());
			model.addAttribute("select_major_id", clazz.getMajor_id());
			model.addAttribute("select_dep_id", clazz.getDep_id());
			
			

//			List<Class> classList=classService.queryClassListByClass(new Class());
			//查询所有院系
			List<Dep> depList = depService.queryAll();
			//查询该院系的所有专业
			List<Major> majorList=new ArrayList<Major>();
			if(clazz.getDep_id()==null||"".equals(clazz.getDep_id())){
				System.out.println("ggggggg");
				majorList = majorService.queryAll();
			}else{
				 majorList = majorService.querybydep_id(clazz.getDep_id());
				 System.out.println("tttttttt");
			}
			
			for (Major major : majorList) {
				System.out.println("-major-"+major);
			}
			
			
//			model.addAttribute("classList", classList);//班级集合
			model.addAttribute("majorList", majorList);//专业集合
			model.addAttribute("depList", depList);//专业集合
			return "view/clazz/addclass";
		}
		
		/**
		 * 
		 * 添加（是否为null动态生成sql）进行添加
		 */
		@RequestMapping(value = "/insertClassByClass.do")
		public String insertClassByClass(HttpServletRequest request, HttpServletResponse response, HttpSession session,
				Model model,Class clazz) {
			System.out.println("-------insertClassByClass-----------");
			System.out.println("clazz:"+clazz);
			if("".equals(clazz.getMajor_id())){
				clazz.setMajor_id(null);
			}
			if("".equals(clazz.getDep_id())){
				clazz.setDep_id(null);
			}
			///------------------------------------------------------------------
			//根据专业id查询该专业的专业名（没有该业务），并赋值给clazz
			if(clazz.getMajor_id()==null){
				System.out.println("major_id为null");
			}else{
				Major major = majorMapper.selectByPrimaryKey(clazz.getMajor_id());
				System.out.println("根据major_id查询到的major："+major);
				clazz.setMajor_name(major.getMajor_name());
			}
			
			///--------------------------------------------------------------------
			//添加之前判断该院系 该专业 中是否存在该班级  不存在则添加  否则添加失败（提示该班级已经存在！！）
			List<Class> queryClassListByClass = classService.queryClassListByClass(clazz);
			System.out.println("queryClassListByClass:"+queryClassListByClass);
			for (Class class1 : queryClassListByClass) {
				System.out.println(class1);
			}
			if(queryClassListByClass.size()>=1){
				model.addAttribute("message", "该班级已经存在，无法添加！！");
				return insertClassByClassUI( request,  response,  session,model, clazz);
			}
			//该班级不存在时添加
			System.out.println("该班级不存在，准备向数据库添加班级："+clazz);
			int success=classService.insertClassByClass(clazz);
			System.out.println(""+success);


			//查询所有班级集合
			List<Class> classList=classService.queryClassListByClass(new Class());
			//查询所有专业集合
			List<Major> majorList = majorService.queryAll();
			//查询所有院系集合
			List<Dep> depList = depService.queryAll();
			model.addAttribute("classList", classList);//班级集合
			model.addAttribute("majorList", majorList);//专业集合
			model.addAttribute("depList", depList);//专业集合
			return "view/clazz/classlist";
		}
		
/////////////////////////////////////////////////////////////////////////////////////////
	// 内部类
	class ClassCompartor implements Comparator<Class> {

		@Override
		public int compare(Class t1, Class t2) {
			// TODO Auto-generated method stub
			if (sort != null) {
				switch (sort) {
				case "":
					;
				case "class_id":
					return t1.getClass_id().compareTo(t2.getClass_id());
				case "class_name":  return  t1.getClass_name().compareTo(t2.getClass_name());
					// compareTo()方法在对字符串进行比较时，比较的是Unicode码，并不能对汉字进行准确的排序，所以汉字比较时会出现比较混乱的结果。
					// 对于英文字符，是比较的ASCII码，得出的结果是正常的
					// return o1.getName().compareTo(o2.getName()); //结果不正确

					// 解决方案：重写compare方法
					// Collator instance = Collator.getInstance(Locale.CHINA);
					// return instance.compare(t1.getTeacher_name(),
					// t2.getTeacher_name());

				case "major_id":
					return t1.getMajor_id().compareTo(t2.getMajor_id());
				case "major_name":
					return t1.getMajor_name().compareTo(t2.getMajor_name());
				case "dep_id":
					return t1.getDep_id().compareTo(t2.getDep_id());
				}
			}
			return t1.getClass_id().compareTo(t2.getClass_id());
		}

	}
	//////////////////////////////////////////////////////////////////////////////////////

}
	
	