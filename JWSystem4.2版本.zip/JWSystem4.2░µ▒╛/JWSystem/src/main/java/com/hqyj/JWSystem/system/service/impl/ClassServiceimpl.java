package com.hqyj.JWSystem.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.ClassMapper;
import com.hqyj.JWSystem.system.model.Class;
import com.hqyj.JWSystem.system.service.ClassService;
@Service
public class ClassServiceimpl implements ClassService {
	@Autowired
	ClassMapper classMapper;

	@Override
	public List<Class> queryClassListByClass(Class clazz) {
		// TODO Auto-generated method stub
		System.out.println("22222222");
		return classMapper.queryClassListByClass( clazz);
	}

	@Override
	public int updateClassByClass(Class clazz) {
		// TODO Auto-generated method stub
		return classMapper.updateByPrimaryKey(clazz);
	}

	@Override
	public int deleteClassByPrimaryKey(Integer classId) {
		// TODO Auto-generated method stub
		return classMapper.deleteByPrimaryKey( classId);
	}

	@Override
	public int insertClassByClass(Class clazz) {
		// TODO Auto-generated method stub
		return classMapper.insertWithIdIntSelective(clazz);
	}

	@Override
	public List<Class> query_distinct_class_name(Class clazz) {
		// TODO Auto-generated method stub
		return classMapper.query_distinct_class_name(clazz);
	}

}
