package com.hqyj.JWSystem.system.service;

import com.hqyj.JWSystem.system.model.Role;
import com.hqyj.JWSystem.system.model.UserRole;

public interface UserRoleService {

	int deleteByUserId(int user_id);

	int addUserRole(UserRole userRole);

	Role queryroleXZByUserId(int user_id);

}
