package com.hqyj.JWSystem.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.PermissionMapper;
import com.hqyj.JWSystem.system.model.Permission;
import com.hqyj.JWSystem.system.service.PermissionService;
import com.hqyj.JWSystem.utils.PageBean;
@Service
public class PermissionServiceimpl implements PermissionService {
	@Autowired
	private PermissionMapper permissionMapper;

	@Override
	public List<Permission> queryMenuByUserId(int userId) {
		// TODO Auto-generated method stub
		return permissionMapper.queryMenuByUserId(userId);
	}

	@Override
	public List<Permission> querypermissionByPId_Son(Integer permission_id,Integer user_id) {
		// TODO Auto-generated method stub
		return permissionMapper.querypermissionByPId_Son(permission_id,user_id);
	}

	@Override
	public List<Permission> querypermissionByUserId(int userId) {
		// TODO Auto-generated method stub
		return permissionMapper.querypermissionByUserId(userId);
	}

	@Override
	public List<Permission> queryall() {
		// TODO Auto-generated method stub
		return permissionMapper.queryall();
	}

	@Override
	public List<Permission> query_XZ_CByrole_id(int role_id) {
		// TODO Auto-generated method stub
		return permissionMapper.query_XZ_CByrole_id(role_id);
	}

	@Override
	public int addpermission(Permission permission) {
		// TODO Auto-generated method stub
		return permissionMapper.addpermission(permission);
	}

	@Override
	public int deleteById(int permission_id) {
		// TODO Auto-generated method stub
		return permissionMapper.deleteByPrimaryKey(permission_id);
	}

	@Override
	public Permission updateUI(int permission_id) {
		// TODO Auto-generated method stub
		return permissionMapper.selectByPrimaryKey(permission_id);
	}

	@Override
	public int updateBypermission(Permission permission) {
		// TODO Auto-generated method stub
		return permissionMapper.updateByPrimaryKeySelective(permission);
	}

	@Override
	public PageBean<Permission> queryAllPage(int pc, int ps) {
		PageBean<Permission> pb = new PageBean<Permission>();
		pb.setPc(pc);
		pb.setPs(ps);

		// 查询总记录数:总记录数（total record）
		int tr = permissionMapper.queryUserTotalRecord();
		pb.setTr(tr);

		// 查询当前页的记录
		List<Permission> beanList =permissionMapper.queryCurrentPageDataList((pc - 1) * ps, ps);
		pb.setBeanList(beanList);
		return pb;
	}
}
