package com.hqyj.JWSystem.system.controller;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.session.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hqyj.JWSystem.system.dao.MajorMapper;
import com.hqyj.JWSystem.system.model.Dep;
import com.hqyj.JWSystem.system.model.Major;
import com.hqyj.JWSystem.system.model.User;
import com.hqyj.JWSystem.system.model.Class;
import com.hqyj.JWSystem.system.service.ClassService;
import com.hqyj.JWSystem.system.service.DepService;
import com.hqyj.JWSystem.system.service.MajorService;

@Controller
@RequestMapping(value = "/DepController")
public class DepController {

	// 注入业务接口
	@Autowired
	DepService depservice;
	@Autowired
	MajorService majorservice;
	@Autowired
	ClassService classservice;

	// 进入院系管理界面
	@RequestMapping(value = "/dep.do")
	public String dep(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model) {
		System.err.println("----DepController--- dep()--------");
		// 接收数据

		// 调用业务
		List<Dep> deplist = depservice.queryAll();

		System.out.println("院系列表" + deplist);
		System.err.println();
		model.addAttribute("deplist", deplist);
		for (Dep dep : deplist) {
			System.out.println(dep);
		}

		return "view/dep/dep";
	}

	// 返回主页面
	@RequestMapping(value = "/back.do")
	public String back(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model) {
		System.err.println("----DepController--- back()--------");

		return "view/main";
	}

	// 查看专业
	@RequestMapping(value = "/majorui.do")
	public String majorUI(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Major major1) {
		System.err.println("----DepController---majorui()--------");
		// 接收数据
		int dep_id = major1.getDep_id();
		// 调用业务
		List<Major> majorlist = majorservice.querybydep_id(dep_id);
		for (Major major : majorlist) {
			System.out.println(major);
		}
		model.addAttribute("dep_id", dep_id);
		model.addAttribute("majorlist", majorlist);

		// 跳转页面
		return "view/dep/major";
	}

	// 返回dep页面
	@RequestMapping(value = "/backdep.do")
	public String backdep(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model) {
		System.err.println("----DepController--- backdep()--------");

		// 返回后重查
		List<Dep> deplist = depservice.queryAll();
		model.addAttribute("deplist", deplist);

		return "view/dep/dep";
	}

	// 添加院系页面
	@RequestMapping(value = "/adddepui.do")
	public String adddepui(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model) {
		System.err.println("----DepController--- adddepui()--------");
		return "view/dep/adddep";
	}

	// 添加院系
	@RequestMapping(value = "/adddep.do")
	public String adddep(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Dep dep) throws UnsupportedEncodingException, InterruptedException {
		System.err.println("----DepController--- adddep()--------");
		// 接收数据

		// 调用业务
		int i = depservice.adddep(dep.getDep_name());
		if (i > 0) {
			model.addAttribute("message", "添加成功！");
			 //重查
			 List<Dep> deplist = depservice.queryAll();
				model.addAttribute("deplist", deplist);
			return "view/dep/dep";
		} else {
			model.addAttribute("message", "添加失败！！请重新添加");
			return "view/dep/adddep";
		}
	}

	// 修改院系UI
	@RequestMapping(value = "/updatedepui.do")
	public String updatedepUI(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Dep dep) {
		System.err.println("----DepController--- updatedepUI()--------");
		// 向前台设置数据
		model.addAttribute("dep_id", dep.getDep_id());
		model.addAttribute("dep_name", dep.getDep_name());
		return "view/dep/updatedep";
	}

	// 修改院系
	@RequestMapping(value = "/updatedep.do")
	public String updatedep(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Dep dep) {
		System.err.println("----DepController--- updatedep()--------");
		// 接受数据
		// 调用业务
		int i = depservice.updateby_dep_id(dep);

		// 修改后
		model.addAttribute("dep_name", dep.getDep_name());
		model.addAttribute("dep_id", dep.getDep_id());

		if (i > 0) {
			// 修改成功
			model.addAttribute("message", "修改成功，还要继续修改吗");
		} else {
			// 修改失败
			model.addAttribute("message", "修改失败！");
		}
		// 跳转页面
		return "view/dep/updatedep";

	}

	// 删除院系
	@RequestMapping(value = "/deletedep.do")
	public String deletedep(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Dep dep) {
		System.err.println("----DepController--- deletedep()--------");
		// 接收数据
		// 调用业务
		//删除院系
		depservice.deleteby_dep_id(dep.getDep_id());
		//删除院系所属专业
		majorservice.deleteby_dep_id(dep.getDep_id());
		// 删除后重查
		List<Dep> deplist = depservice.queryAll();
		model.addAttribute("deplist", deplist);
		model.addAttribute("message", "删除院系成功！");
		// 跳转页面
		return "view/dep/dep";
	}

	// 添加专业页面
	@RequestMapping(value = "/addmajorui.do")
	public String addmajorui(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Major major) {
		System.err.println("----DepController---addmajorui()--------");
		// 接收数据
		// 添加信息到页面
		model.addAttribute("dep_id", major.getDep_id());

		return "view/dep/addmajor";
	}

	// 添加专业
	@RequestMapping(value = "/addmajor.do")
	public String addmajor(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Major major) {
		System.err.println("----DepController---addmajor()--------");
		// 接受数据
		// 调用业务
		int i = depservice.addmajor(major.getMajor_name(), major.getDep_id());
		// 添加后
		model.addAttribute("dep_id", major.getDep_id());
		if (i > 0) {
			model.addAttribute("message", "添加专业成功！");
			//重查
			List<Major> majorlist = majorservice.querybydep_id(major.getDep_id());
			model.addAttribute("dep_id", major.getDep_id());
			model.addAttribute("majorlist", majorlist);
			return "view/dep/major";
		} else {
			model.addAttribute("message", "添加专业失败！");
			return "view/dep/addmajor";
		}
		// 跳转页面
	}

	// 修改专业页面
	@RequestMapping(value = "/updatemajorui.do")
	public String updatemajorui(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Major major) {
		System.err.println("----DepController---updatemajorui()--------");
		// 准备数据

		// ******************
		// 分配院系
		List<Dep> deplist = depservice.queryAll();
		model.addAttribute("deplist", deplist);

		// ******************

		model.addAttribute("major_id", major.getMajor_id());
		model.addAttribute("dep_id", major.getDep_id());
		model.addAttribute("major_name", major.getMajor_name());
		model.addAttribute("dep_id_select", major.getDep_id());

		return "view/dep/updatemajor";
	}

	// 修改专业
	@RequestMapping(value = "/updatemajor.do")
	public String updatemajor(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Major major) {
		System.err.println("----DepController---updatemajor()--------");
		// 接受数据
		// 设置原专业dep_id
		int dep_id_base = major.getDep_id();
		// ****************
		// 分配专业
		String dep_id_selectstr = request.getParameter("dep_id_select");
		int dep_id_select = Integer.parseInt(dep_id_selectstr);
		System.err.println("选中的院系id:" + dep_id_select);

		// 调用业务
		major.setDep_id(dep_id_select);
		int i = majorservice.updatemajor(major);

		// 重查
		List<Dep> deplist = depservice.queryAll();
		model.addAttribute("deplist", deplist);
		model.addAttribute("dep_id_select", dep_id_select);
		model.addAttribute("dep_id", dep_id_base);
		// ****************

		// 调用后
		if (i > 0) {
			model.addAttribute("message", "修改专业成功！还要继续修改吗");
			model.addAttribute("major_name", major.getMajor_name());
		} else {
			model.addAttribute("message", "修改专业失败！");
		}

		return "view/dep/updatemajor";
	}

	// 删除专业
	@RequestMapping(value = "/deletemajor.do")
	public String deletemajor(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Major major) {
		System.err.println("----DepController--- deletemajor()--------");
		// 接收数据
		// 调用业务
		majorservice.deleteby_major_id(major.getMajor_id());
		// 删除后重查
		List<Major> majorlist = majorservice.querybydep_id(major.getDep_id());
		model.addAttribute("majorlist", majorlist);

		model.addAttribute("major_id", major.getMajor_id());
		model.addAttribute("dep_id", major.getDep_id());
		model.addAttribute("major_name", major.getMajor_name());
		model.addAttribute("message","删除专业成功！");

		return "view/dep/major";
	}

	// 院系模糊查询
	@RequestMapping(value = "/distinctquery.do")
	public String distinctquery(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model) {
		System.err.println("----DepController--- distinctquery--------");
		// 接收数据
		String dep_name = request.getParameter("dep_name_query");
		System.err.println("院系模糊查询:" + dep_name);
		// 调用业务
		List<Dep> deplist = depservice.querydistinct(dep_name);
		model.addAttribute("deplist", deplist);
		model.addAttribute("dep_name_input", dep_name);

		return "view/dep/dep";
	}

	// 专业模糊查询
	@RequestMapping(value = "/distinctquerymajor.do")
	public ModelAndView distinctquerymajor(HttpServletRequest request, HttpServletResponse response,
			HttpSession session, Model model, Major major) {
		System.err.println("----DepController--- distinctquerymajor--------");
		// 接收数据
		String major_name_input = request.getParameter("major_name_query");
		System.err.println("专业模糊查询:" + major_name_input);
		// 准备数据
		major.setMajor_name(major_name_input);
		// 调用业务
		List<Major> majorlist = majorservice.query_distinct_major(major);
		System.out.println("----------:" + majorlist);
		// 调用业务后
		// 设置前台数据
		ModelAndView mav = new ModelAndView();
		mav.addObject("dep_id", major.getDep_id());
		mav.addObject("majorlist", majorlist);
		mav.setViewName("view/dep/major");
		mav.addObject("major_name_query", major_name_input);

		return mav;
	}

	// 查看班级信息
	@RequestMapping(value = "/class.do")
	public String classquery(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Class clazz) {
		System.err.println("----DepController---class()--------");
		// 接收数据
		System.err.println("班级---------" + clazz);
		// 调用业务
		List<Class> classlist = classservice.queryClassListByClass(clazz);
		System.out.println("班级:------" + classlist);

		// 准备前台数据
		model.addAttribute("classlist", classlist);
		model.addAttribute("dep_id", clazz.getDep_id());
		model.addAttribute("major_id", clazz.getMajor_id());

		return "view/dep/class";
	}

	// 模糊查询班级
	@RequestMapping(value = "/distinctqueryclass.do")
	public String distinctqueryclass(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Class clazz) {
		System.err.println("----DepController--- distinctqueryclass--------");
		// 接收数据
		String class_name_input = request.getParameter("class_name_input");
		// 调用业务
		Class clazz2 = new Class();
		clazz2.setMajor_id(clazz.getMajor_id());
		clazz2.setClass_name(class_name_input);
		List<Class> classlist = classservice.query_distinct_class_name(clazz2);
		System.err.println("clazz2:" + clazz2);
		model.addAttribute("classlist", classlist);
		model.addAttribute("major_id", clazz2.getMajor_id());
		model.addAttribute("dep_id", clazz.getDep_id());
		model.addAttribute("class_name_input", class_name_input);

		return "view/dep/class";
	}

	// 批量删除院系
	@RequestMapping(value = "/deletedeppl.do")
	public String deletedeppl(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Class clazz) {
		System.err.println("----DepController--- deletedeppl--------");
		//得到勾选框中的dep_id值装进String数组中
		String[] dep_id_check = request.getParameterValues("dep_id_check_name");
		// ********若没有勾选*************
		if (dep_id_check == null) {
			model.addAttribute("message", "您还没有勾选要删除的院系");
			// 删除后重查
			List<Dep> deplist = depservice.queryAll();
			model.addAttribute("deplist", deplist);
			return "view/dep/dep";
		}
		// ****************************
		List<Integer> dep_id_check_list = new ArrayList<>();
		// 把string循环转换成int，再添加到list里
		for (String dep_idstr : dep_id_check) {
			int dep_id = Integer.parseInt(dep_idstr);
			dep_id_check_list.add(dep_id);
		}
		// 调用业务
		depservice.deleteby_dep_id_pl(dep_id_check_list);
		// 删除后重查
		List<Dep> deplist = depservice.queryAll();
		model.addAttribute("deplist", deplist);
		model.addAttribute("message","删除勾选院系成功");
		// 跳转页面
		return "view/dep/dep";
	}
}
