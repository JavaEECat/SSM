package com.hqyj.JWSystem.system.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hqyj.JWSystem.system.dao.RolePermissionMapper;
import com.hqyj.JWSystem.system.model.RolePermission;
import com.hqyj.JWSystem.system.service.RolePermissionService;
@Service
public class RolePermissionServiceimpl implements RolePermissionService {
	@Autowired
	private RolePermissionMapper rolePermissionMapper;

	@Override
	public int deleteByRoleId(int role_id) {
		return rolePermissionMapper.deleteByRoleId(role_id);
	}

	@Override
	public int addRoleMenuByRM(RolePermission rolePermission) {
		// TODO Auto-generated method stub
		return rolePermissionMapper.insertSelective(rolePermission);
	}

}
