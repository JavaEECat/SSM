package com.hqyj.JWSystem.system.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hqyj.JWSystem.system.model.ActiveExam;
import com.hqyj.JWSystem.system.model.ActiveUser;
import com.hqyj.JWSystem.system.model.GradeExamination;
import com.hqyj.JWSystem.system.model.Student;
import com.hqyj.JWSystem.system.service.GEService;
import com.hqyj.JWSystem.system.service.StudentService;

@Controller
@RequestMapping("/GEController")
public class GEController {

	@Autowired
	public StudentService studentService;
	@Autowired
	public GEService geService;

	@RequestMapping(value = "/queryGrade.do")
	public String queryGrade(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model) {

		Subject subject = SecurityUtils.getSubject();
		ActiveUser activeUser = (ActiveUser) subject.getPrincipal();
		int userId = activeUser.getUserid();
		String usercode = activeUser.getUsercode();//
		List<ActiveExam> activeExamList = null;
		try {
			// 捕获将string类型转化为int的异常
			int userid = Integer.parseInt(usercode);
		} catch (NumberFormatException e) {
			// ---------------------------》
			GradeExamination s = null;
			List<GradeExamination> gel = geService.queryAll(s);
			// 先查询现有的等级考试学生信息"+gel);
			List<String> s1 = new ArrayList();
			for (GradeExamination g : gel) {
				String ss = String.valueOf(g.getStudent_id());
				s1.add(ss);
			}
			// 拿到学生基本信息管理里的学生ID："+s2);
			System.err.println(s1);
			List<Student> stList = studentService.queryAllByStudent();
			List<String> s2 = new ArrayList();
			for (Student ss : stList) {
				String sss = String.valueOf(ss.getStudent_id());
				s2.add(sss);
			}
			// 在拿到学生基本信息管理里的学生ID："+s2);
			System.err.println(s2);
			List<String> exists = new ArrayList(s2);
			exists.removeAll(s1);

			for (String string1 : exists) {

				int studetid = Integer.parseInt(string1);
				Student stu = studentService.queryStudentNumberByStudent_id(studetid);
				System.err.println(stu);
				GradeExamination ges = new GradeExamination();
				ges.setStudent_id(stu.getStudent_id());
				ges.setStudent_name(stu.getStudent_name());
				ges.setAge(stu.getAge());
				ges.setSex(stu.getSex());
				gel.add(ges);
				int i = geService.insertSelective(ges);

			}
			model.addAttribute("gelist", gel);
			System.err.println(gel);
			return "view/gradeExamination/gradeList";
			// --------------------------------》
			// //管理员查询所有考试安排
			// System.err.println("你是尊贵的admin管理员");
			// GradeExamination stuge=new GradeExamination();
			// List<GradeExamination> gl = geService.queryAll(stuge);
			// if (gl != null) {
			// model.addAttribute("gelist", gl);
			// return "view/gradeExamination/gradeList";
			// }
		}
		if (usercode.length() == 10)// 查询学生自己的考试
		{
			System.err.println("你是学生");
			GradeExamination stuge = new GradeExamination();
			stuge.setStudent_id(Integer.parseInt(usercode));
			List<GradeExamination> gl = geService.queryAll(stuge);
			if (gl != null) {
				model.addAttribute("gelist", gl);
				return "view/gradeExamination/gradeList";
			}
		}

		return "view/gradeExamination/gradeList";
	}

	@RequestMapping(value = "/enroll.do")
	public String enroll(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model) {
		Subject subject = SecurityUtils.getSubject();
		ActiveUser activeUser = (ActiveUser) subject.getPrincipal();
		System.err.println(activeUser.getUsercode());
		int userId = activeUser.getUserid();
		String usercode = activeUser.getUsercode();//
		int student_id = Integer.parseInt(usercode);
		System.err.println("报名者学号" + student_id);
		GradeExamination gradeExamination = new GradeExamination();
		gradeExamination.setStudent_id(student_id);
		model.addAttribute("gradeExamination", gradeExamination);
		return "view/gradeExamination/enroll";
	}

	@RequestMapping(value = "/addEnroll.do")
	public String addEnroll(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model) {
		String select = request.getParameter("select");
		System.err.println("选择的等级考试类型" + select);
		int id = Integer.parseInt(request.getParameter("student_id"));
		System.err.println("报名者ID" + id);
		GradeExamination gradeExamination = geService.queryByStudent_id(id);
		System.err.println("报名者信息：" + gradeExamination);
		if (select.equals("ncre")) {
			// 再查是否已经报过计算机
			try {
				String s = gradeExamination.getNcre();
				if (s != null) {
					model.addAttribute("message", "计算机你已经报过名了！");
					return "view/gradeExamination/success";
				}
				GradeExamination g2 = new GradeExamination();
				g2.setNcre("已报");
				g2.setStudent_id(id);
				int i = geService.updatencreByStudent_id(g2);
				if (i > 0) {
					model.addAttribute("message", "计算机报名成功！");
					return "view/gradeExamination/success";
				}
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			model.addAttribute("message", "计算机你已经报过名了！");
			return "view/gradeExamination/success";
		} else if (select.equals("cet")) {
			// 再查是否已经报过英语
			try {
				String s = gradeExamination.getCet();
				if (s != null) {
					model.addAttribute("message", "英语你已经报过名了！");
					return "view/gradeExamination/success";
				}
				GradeExamination g2 = new GradeExamination();
				g2.setCet("已报");
				g2.setStudent_id(id);
				int j = geService.updatecetByStudent_id(g2);
				if (j > 0) {
					model.addAttribute("message", "英语报名成功！");
					return "view/gradeExamination/success";
				}
			} catch (NullPointerException e) {
				e.printStackTrace();

			}
			model.addAttribute("message", "英语你已经报过名了");
			return "view/gradeExamination/success";
		}
		return "view/gradeExamination/success";
	}

}
