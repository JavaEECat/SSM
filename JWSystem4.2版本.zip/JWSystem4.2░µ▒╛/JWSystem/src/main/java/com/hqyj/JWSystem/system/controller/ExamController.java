package com.hqyj.JWSystem.system.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hqyj.JWSystem.system.model.ActiveExam;
import com.hqyj.JWSystem.system.model.ActiveUser;
import com.hqyj.JWSystem.system.model.Course;
import com.hqyj.JWSystem.system.model.Exam;
import com.hqyj.JWSystem.system.model.PageBean;
import com.hqyj.JWSystem.system.model.Room;
import com.hqyj.JWSystem.system.model.Student;
import com.hqyj.JWSystem.system.model.Teacher;
import com.hqyj.JWSystem.system.service.CourseService;
import com.hqyj.JWSystem.system.service.ExamService;
import com.hqyj.JWSystem.system.service.RoomService;
import com.hqyj.JWSystem.system.service.StudentService;
import com.hqyj.JWSystem.system.service.TeacherService;
import com.hqyj.JWSystem.utils.PageUtils;

@Controller
@RequestMapping(value = "/examController")
public class ExamController {

	@Autowired
	private ExamService examService;

	@Autowired
	private CourseService courseService;

	@Autowired
	private RoomService roomService;

	@Autowired
	private TeacherService teacherService;

	@Autowired
	public StudentService studentService;

	// 添加考试安排信息缓存
	@RequestMapping(value = "/addExamBuffer.do")
	public String addExamBuffer(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model) {
		//
		System.out.println("------------addExamBuffer.do------------------");
		// -------------------加载考试安排中没有的信息
//		// 1查询所有考试安排
//		List<ActiveExam> activeExamList = examService.queryAllexamList();
		List<Course> courseList = new ArrayList<Course>();
//		for (ActiveExam activeExam : activeExamList) {
//			Course course = new Course();
//			course.setCourse_name(activeExam.getCourse_name());
//			courseList.add(course);
//		}
//		for (Course course : courseList) {
//			System.out.println(course);
//		}
		// ->2返回没有的安排考试的课程信息
		String s="";
		List<Course> courseList2 = courseService.queryAllCourseByCourse_name_screen(s);
		for (Course course : courseList2) {
			System.out.println(course);
		}
		model.addAttribute("courseList", courseList2);
		// ->2教室信息
		List<Room> roomList = roomService.queryAll();
		System.out.println("------------------------------------------" + roomList);
		model.addAttribute("roomList", roomList);
		// ->3老师信息
		Teacher teacher = new Teacher();
		List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher);
		System.out.println("------------------------------------------" + teacherList);
		model.addAttribute("teacherList", teacherList);
		return "view/exam/addExam";
	}

	// 添加考试安排
	@RequestMapping(value = "/addExam.do")
	public String addExam(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Exam exam) {
		// 获取考试安排信息
		System.err.println("-----------------------addExam.do---------------------------" + exam);
		String datestr = request.getParameter("datetime1");
		String datestr2 = request.getParameter("datetime2");
		String exam_timestr = datestr + " " + datestr2;
		System.err.println(exam_timestr);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date exam_time = null;
		try {
			exam_time = sdf.parse(exam_timestr);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.err.println(exam_time);
		exam.setExam_time(exam_time);
		// 添加考试安排
		int i = examService.addExamByExam(exam);
		if (i > 0) {
			model.addAttribute("message", "添加成功，继续添加吗？");
		} else {
			model.addAttribute("message", "添加失败，重新添加吗？");
		}
		return "view/exam/select";
	}

	// 考试安排列表
	@RequestMapping(value = "/examList.do")
	public String examList(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Exam exam) {
		System.out.println("-----------------examList.do--------/examList..do---------------");
		PageHelper.startPage(1, 10, true);
		// ----------------
		Subject subject = SecurityUtils.getSubject();
		ActiveUser activeUser = (ActiveUser) subject.getPrincipal();
		int userId = activeUser.getUserid();
		String usercode = activeUser.getUsercode();//
		int userid = 0;
		List<ActiveExam> activeExamList = null;
		try {
			// 捕获将string类型转化为int的异常
			userid = Integer.parseInt(usercode);
		} catch (NumberFormatException e) {
			e.printStackTrace();
			// ---------------------管理员查询所有考试安排
			System.err.println("你是尊贵的admin管理员");
			activeExamList = examService.queryAllexamListPage();
		}
		if (usercode.length() == 10)// 查询学生自己的考试
		{
			System.err.println("你是学生");
			activeExamList = examService.queryStudentExamList(Integer.parseInt(usercode));
		} else if (usercode.length() == 8) {// 查询老师自己所授课程的考试安排
			System.err.println("你是老师");
			activeExamList = examService.queryTeacherExamList(Integer.parseInt(usercode));
		}

		// 打印分页信息
		PageInfo<ActiveExam> pageInfo = new PageInfo<ActiveExam>(activeExamList);
		PageBean pageBean = new PageBean();
		pageBean.setTotal(pageInfo.getTotal());
		pageBean.setPages(pageInfo.getPages());
		model.addAttribute("pageBean", pageBean);
		List<ActiveExam> temp = null;
		if (activeExamList != null) {

			for (ActiveExam activeExam : activeExamList) {	
				System.out.println(activeExam);
				try {
					// 获取当前时间
					long currentDate = new Date().getTime();
					// 格式化考试时间
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					Long longTime = sdf.parse(activeExam.getExam_time()).getTime();
					// 时间差
					long totalTime = longTime - currentDate;
					System.err.println(totalTime);// 秒
					long days = totalTime / (1000 * 60 * 60 * 24);
					totalTime = totalTime % (1000 * 60 * 60 * 24);
					long hours = totalTime / (1000 * 60 * 60);
					totalTime = totalTime % (1000 * 60 * 60);
					long minutes = totalTime / (1000 * 60);
					totalTime = totalTime % (1000 * 60);
					String time = "";
					if (days >= 1) {
						time = days + "天" + hours + "时" + minutes + "分";
					} else if (hours >= 1) {
						time = hours + "时" + minutes + "分";
					} else if (minutes >= 1) {
						time = minutes + "分";
					}
					activeExam.setTimestamp(time);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		} else {
			model.addAttribute("message", "暂无考试安排");
		}
		model.addAttribute("activeExamList", activeExamList);
		return "view/exam/examList";

	}

	// 考试安排列表
	@RequestMapping(value = "/examList2.do")
	public String examListPage(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Exam exam) {
		int num = Integer.parseInt(request.getParameter("PC"));
		PageHelper.startPage(num, 10, true);

		// 查询所有考试安排
		List<ActiveExam> activeExamList = examService.queryAllexamListPage();
		// // 打印分页信息
		PageInfo<ActiveExam> pageInfo = new PageInfo<ActiveExam>(activeExamList);
		PageBean pageBean = new PageBean();
		pageBean.setTotal(pageInfo.getTotal());
		pageBean.setPages(pageInfo.getPages());
		model.addAttribute("pageBean", pageBean);
		for (ActiveExam activeExam : activeExamList) {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Long longTime = sdf.parse(activeExam.getExam_time()).getTime();
				long currentDate = new Date().getTime();
				long totalTime = longTime - currentDate;
				System.err.println(totalTime);// 秒
				long days = totalTime / (1000 * 60 * 60 * 24);
				totalTime = totalTime % (1000 * 60 * 60 * 24);
				long hours = totalTime / (1000 * 60 * 60);
				totalTime = totalTime % (1000 * 60 * 60);
				long minutes = totalTime / (1000 * 60);
				totalTime = totalTime % (1000 * 60);
				String time = "";
				if (days >= 1) {
					time = days + "天" + hours + "时" + minutes + "分";
				} else if (hours >= 1) {
					time = hours + "时" + minutes + "分";
				} else if (minutes >= 1) {
					time = minutes + "分";
				}
				activeExam.setTimestamp(time);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		model.addAttribute("activeExamList", activeExamList);
		return "view/exam/examList";

	}

	// 取消考试
	@RequestMapping(value = "/deleteExam.do")
	public String deleteExam(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Exam exam) {
		// 获取要删除的该考试安排的信息（exam_id）
		//
		int exam_id = Integer.parseInt(request.getParameter("exam_id"));
		System.out.println("----------------/deleteExam.do-------------------------" + exam_id);
		// 删除课程
		int i = examService.deleteExamByExam_id(exam_id);
		// 删除后查询所有考试安排
		// 查询所有考试安排
		List<ActiveExam> activeExamList = examService.queryAllexamList();
		model.addAttribute("activeExamList", activeExamList);
		return "view/exam/examList";
	}

	// 修改考试安排ui
	@RequestMapping(value = "/updateExamUI.do")
	public String updateExamUI(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			Model model, Exam exam) {
		// 获取要修改的该考试的信息（考试exam_id）
		int exam_id = Integer.parseInt(request.getParameter("exam_id"));
		System.err.println("----------------/updateExamUI.do-------------------------" + exam_id);
		Exam exam2 = examService.queryexamByExam_id(exam_id);
		System.err.println(exam2);
		int course_id = exam2.getCourse_id();
		Course course = courseService.queryCourseByCourse_id(course_id);
		model.addAttribute("currentcourse", course);
		// 1查询所有课程
		List<Course> cl = null;
		List<Course> courseList = courseService.queryAll(cl);
		model.addAttribute("courseList", courseList);
		// ->2教室信息
		Room room = roomService.queryRoomById(exam2.getRoom_id());
		System.err.println("回显教室数据：" + room);
		model.addAttribute("currentroom", room);
		List<Room> roomList = roomService.queryAll();
		model.addAttribute("roomList", roomList);
		// ->3老师信息
		Teacher teacher = new Teacher();
		teacher.setTeacher_id(exam2.getTeacher_id());
		List<Teacher> currentteacher = teacherService.queryTeacherListByTeacher(teacher);
		System.err.println("回显教师数据：" + currentteacher);
		model.addAttribute("currentteacher", currentteacher);
		Teacher teacher2 = new Teacher();
		List<Teacher> teacherList = teacherService.queryTeacherListByTeacher(teacher2);
		model.addAttribute("teacherList", teacherList);
		model.addAttribute("updateExam", exam2);
		System.err.println("----------------/updateExamUI.do-----结束--------------------");
		return "view/exam/updateExam";
	}

	// 修改考试安排
	@RequestMapping(value = "/updateExam.do")
	public String updateExam(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model,
			Exam exam) {
		// 获取要修改的该课程的信息
		System.err.println("----------------/updateExam.do-------------------------" + exam);
		String datestr = request.getParameter("datetime1");
		String datestr2 = request.getParameter("datetime2");
		String exam_timestr = datestr + " " + datestr2;
		System.err.println(exam_timestr);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date exam_time = null;
		try {
			exam_time = sdf.parse(exam_timestr);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.err.println(exam_time);
		exam.setExam_time(exam_time);
		int i = examService.updateExamByExam(exam);
		PageHelper.startPage(1, 10, true);

		// 查询所有考试安排
		List<ActiveExam> activeExamList = examService.queryAllexamListPage();
		// 打印分页信息
		PageInfo<ActiveExam> pageInfo = new PageInfo<ActiveExam>(activeExamList);
		PageBean pageBean = new PageBean();
		pageBean.setTotal(pageInfo.getTotal());
		pageBean.setPages(pageInfo.getPages());
		model.addAttribute("pageBean", pageBean);
		for (ActiveExam activeExam : activeExamList) {
			try {
				SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Long longTime = sdf2.parse(activeExam.getExam_time()).getTime();
				long currentDate = new Date().getTime();
				long totalTime = longTime - currentDate;
				System.err.println(totalTime);// 秒
				long days = totalTime / (1000 * 60 * 60 * 24);
				totalTime = totalTime % (1000 * 60 * 60 * 24);
				long hours = totalTime / (1000 * 60 * 60);
				totalTime = totalTime % (1000 * 60 * 60);
				long minutes = totalTime / (1000 * 60);
				totalTime = totalTime % (1000 * 60);
				String time = "";
				if (days >= 1) {
					time = days + "天" + hours + "时" + minutes + "分";
				} else if (hours >= 1) {
					time = hours + "时" + minutes + "分";
				} else if (minutes >= 1) {
					time = minutes + "分";
				}
				activeExam.setTimestamp(time);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		model.addAttribute("activeExamList", activeExamList);
		return "view/exam/examList";
	}
}
