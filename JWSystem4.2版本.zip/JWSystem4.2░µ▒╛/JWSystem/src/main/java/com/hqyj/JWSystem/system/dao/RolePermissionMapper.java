package com.hqyj.JWSystem.system.dao;

import com.hqyj.JWSystem.system.model.RolePermission;

public interface RolePermissionMapper {
    int deleteByPrimaryKey(Integer role_permission_id);

    int insert(RolePermission record);

    int insertSelective(RolePermission record);

    RolePermission selectByPrimaryKey(Integer role_permission_id);

    int updateByPrimaryKeySelective(RolePermission record);

    int updateByPrimaryKey(RolePermission record);

	int deleteByRoleId(int role_id);
}