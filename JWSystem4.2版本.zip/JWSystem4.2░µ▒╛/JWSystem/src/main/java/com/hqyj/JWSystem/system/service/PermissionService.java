package com.hqyj.JWSystem.system.service;

import java.util.List;


import com.hqyj.JWSystem.system.model.Permission;
import com.hqyj.JWSystem.utils.PageBean;




public interface PermissionService {

	List<Permission> queryMenuByUserId(int userId);

	List<Permission> querypermissionByPId_Son(Integer permission_id,Integer user_id);

	List<Permission> querypermissionByUserId(int userId);

	List<Permission> queryall();

	List<Permission> query_XZ_CByrole_id(int role_id);

	int addpermission(Permission permission);

	int deleteById(int permission_id);

	Permission updateUI(int permission_id);

	int updateBypermission(Permission permission);

	PageBean<Permission> queryAllPage(int pc, int ps);

}
