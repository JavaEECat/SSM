package com.hqyj.JWSystem.system.service;

import java.util.List;



import com.hqyj.JWSystem.system.model.Schoolroll;


public interface SchoolRollService {

	List<Schoolroll> querySchoolrollBYAll();

	int deleteByPrimaryKey(int schoolRoll_idInt);

	int insertSelective(Schoolroll schoolroll);

	Schoolroll querySchoolrollByStudent_id(int student_id);

	int updateByPrimaryKeySelective2(Schoolroll schoolroll);

}
