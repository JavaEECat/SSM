package com.hqyj.JWSystem.system.dao;

import java.util.List;

import com.hqyj.JWSystem.system.model.Room;

public interface RoomMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Room record);

    int insertSelective(Room record);

    Room selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Room record);

    int updateByPrimaryKey(Room record);

	List<Room> queryAll();

	int addExamByExam(Room room);

	List<Room> queryAllScreen(Room room);

	List<Room> queryAllByRoom();

	Room queryDepByRood_id(String class_room);
}