package com.hqyj.JWSystem.system.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hqyj.JWSystem.system.model.Permission;

public interface PermissionMapper {
    int deleteByPrimaryKey(Integer permission_id);

    int insert(Permission record);

    int insertSelective(Permission record);

    Permission selectByPrimaryKey(Integer permission_id);

    int updateByPrimaryKeySelective(Permission record);

    int updateByPrimaryKey(Permission record);

	List<Permission> queryMenuByUserId(int userId);

	List<Permission> querypermissionByPId_Son(@Param("permission_id")Integer permission_id, @Param("user_id")Integer user_id);

	List<Permission> querypermissionByUserId(int userId);

	List<Permission> queryall();

	List<Permission> query_XZ_CByrole_id(int role_id);

	int addpermission(Permission permission);

	int queryUserTotalRecord();

	List<Permission> queryCurrentPageDataList(@Param("i")Integer i, @Param("ps")Integer ps);


}