package com.framework.utils;

import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.util.ByteSource;

public  class EncryptionUtil {
	public static String getEncryptionStr(Object obj,String pwd) {
		String algorithmName="MD5";
    	Object source=pwd;
    	Object salt=ByteSource.Util.bytes(obj);
    	int hashIterations=1024;
		SimpleHash MD5=new SimpleHash(algorithmName, source, salt, hashIterations);		
		return MD5.toString();
	}
}
