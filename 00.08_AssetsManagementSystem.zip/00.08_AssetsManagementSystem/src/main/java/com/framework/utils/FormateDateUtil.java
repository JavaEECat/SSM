package com.framework.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class FormateDateUtil {
	
	public String getFormateDate() {
		Date d=new Date();
		DateFormat df=new SimpleDateFormat("YYYY-MM-dd hh:mm:ss");
		return df.format(d);
	}

}
