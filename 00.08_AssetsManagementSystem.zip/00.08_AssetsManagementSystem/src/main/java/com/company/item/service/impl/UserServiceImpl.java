package com.company.item.service.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.ExcessiveAttemptsException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.company.item.mapper.UserMapper;
import com.company.item.model.User;
import com.company.item.service.UserService;
import com.framework.utils.TimeFormatUtil;
import com.google.gson.Gson;
@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserMapper userMapper;

	public String checkUser(HttpServletRequest request,HttpServletResponse response) {
		String account=request.getParameter("account");
		String pwd=request.getParameter("pwd");
		if(account==null || account.equals("")){
			return "ACCOUNTNULL";
		}/*else if(pwd==null || pwd.equals("")){
			return "PWDNULL";
		}*/else {
			User user=userMapper.quaryUserByAccount(account);
			if(user!=null){
				if(user.getPassword().equals(pwd)){
					request.getSession().setAttribute("USERID", user.getUserId());
					Date d=new Date();
					DateFormat df=new SimpleDateFormat("YYYY-MM-dd hh:mm:ss");
					request.getSession().setAttribute("LOGINTIME", df.format(d));
					String rememberMe=request.getParameter("rememberMe");
					if(rememberMe.equals("YES")){
						Cookie cookie=new Cookie("ERPSTSTEMUSERSS", user.getUserId());
						response.addCookie(cookie);
						cookie.setMaxAge(30*24*60*60);
					}
					return "SUCCESS";
				}else {
					return "PWDERROR";
				}	
			}else{
				return "ACCOUNTERROR";
			}
		}
		

	}
	
	
	
	public User getUserBySession() {
	Session session	= SecurityUtils.getSubject().getSession();
		String i=(String) session.getAttribute("USERID");
		User user=userMapper.selectByPrimaryKey(i);
		return user;
	}

	//获取服务器的名称
	public String getServerName() {
		try {
			InetAddress id=InetAddress.getLocalHost();
			//id.getHostAddress();获取服务器的ip地址
			return id.getHostName();
		} catch (UnknownHostException e) {
			
			return "无法获取";
		}
		
	}
	//获取服务器当前时间
	public String getServerTime() {
		Date d=new Date();
		DateFormat dF=new SimpleDateFormat("YYYY-MM-dd hh-mm-ss");
		return dF.format(d);
	}

	public String rememberUser(HttpServletRequest request) {
	Cookie[] cookies=request.getCookies();
	if(cookies!=null){
		for (Cookie cookie : cookies) {
			if(cookie.getName().equals("RSEAMSYSAPRIL")){
				User user=userMapper.selectByPrimaryKey(cookie.getValue());
				if(null!=user) {
					Gson g=new Gson();
					user.setPassword("RememberMe");
					return g.toJson(user);
				}
				
			}
		}
	}
	return "NOREMEMBER";
		
	}
	
	
	
	public void setRememberMe(HttpServletRequest request, HttpServletResponse response,String userId) {
		String rememberMe=request.getParameter("rememberMe");
		if (rememberMe.equals("YES")) {
			Cookie cookie=new Cookie("RSEAMSYSAPRIL",userId);
			response.addCookie(cookie);
			cookie.setMaxAge(30*24*60*60);
		}
		
	}
	public void deleteAutoLogin(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] sk=request.getCookies();
		if(sk!=null){
			for (Cookie cookie : sk) {
				if(cookie.getName().equals("RSEAMSYSAPRIL")){
					cookie.setMaxAge(0);
					response.addCookie(cookie);
				}
				
			}
		}
		
	}

	public void deleteUserSession(HttpServletRequest request) {
		ServletContext servletContext= request.getServletContext();
        @SuppressWarnings("unchecked")
		Set<String> Online= (Set<String>) servletContext.getAttribute("OnlineNum");
        Online.remove((String)SecurityUtils.getSubject().getSession().getAttribute("USERID"));
        servletContext.setAttribute("OnlineNum",Online);	
	}



	public String Userlogin(HttpServletRequest request, HttpServletResponse response) {
		String resultPageURL = InternalResourceViewResolver.FORWARD_URL_PREFIX + "/";  
        String username = request.getParameter("account");
        
        String password = request.getParameter("pwd");
       
        
        System.out.println("-----------------------------------------------------");
        UsernamePasswordToken token = new UsernamePasswordToken(username, password);  
        System.out.println("为了验证登录用户而封装的token为" + ReflectionToStringBuilder.toString(token, ToStringStyle.MULTI_LINE_STYLE));  
        //获取当前的Subject  
        Subject currentUser = SecurityUtils.getSubject();
        //如何验证
        if (!rememberUser(request).equals("NOREMEMBER")) {
        	currentUser.getSession().setAttribute("remberMe","YES");
		}else {
			currentUser.getSession().setAttribute("remberMe","NO");
		}
        try {  
            //在调用了login方法后,SecurityManager会收到AuthenticationToken,并将其发送给已配置的Realm执行必须的认证检查  
            //每个Realm都能在必要时对提交的AuthenticationTokens作出反应  
            //所以这一步在调用login(token)方法时,它会走到MyRealm.doGetAuthenticationInfo()方法中,具体验证方式详见此方法  
            System.out.println("对用户[" + username + "]进行登录验证..验证开始");
            currentUser.login(token);  
            System.out.println("对用户[" + username + "]进行登录验证..验证通过");
            setRememberMe(request,response, (String)currentUser.getSession().getAttribute("USERID"));
            resultPageURL = "登陆成功";
            //处理登陆时间与在线人数
            request.getSession().setAttribute("LOGINTIME",TimeFormatUtil.getNowTime());
            ServletContext servletContext= request.getServletContext();
            @SuppressWarnings("unchecked")
			Set<String> Online= (Set<String>) servletContext.getAttribute("OnlineNum");
            Online.add((String)currentUser.getSession().getAttribute("USERID"));
            servletContext.setAttribute("OnlineNum",Online);
        }catch(UnknownAccountException uae){  
            System.out.println("对用户[" + username + "]进行登录验证..验证未通过,未知账户");  
            request.setAttribute("message_login", "未知账户"); 
            resultPageURL="账户不存在";
        }catch(IncorrectCredentialsException ice){  
            System.out.println("对用户[" + username + "]进行登录验证..验证未通过,错误的凭证");  
            request.setAttribute("message_login", "密码不正确");
            resultPageURL="密码错误";
        }catch(LockedAccountException lae){  
            System.out.println("对用户[" + username + "]进行登录验证..验证未通过,账户已锁定");  
           resultPageURL="LockedAccount";  
        }catch(ExcessiveAttemptsException eae){  
            System.out.println("对用户[" + username + "]进行登录验证..验证未通过,错误次数过多");  
            request.setAttribute("message_login", "用户名或密码错误次数过多");
            resultPageURL="ExcessiveAttempts";  
        }catch(AuthenticationException ae){  
            //通过处理Shiro的运行时AuthenticationException就可以控制用户登录失败或密码错误时的情景  
            System.out.println("对用户[" + username + "]进行登录验证..验证未通过,堆栈轨迹如下");  
            ae.printStackTrace();  
            request.setAttribute("message_login", "用户名或密码不正确");  
        }  
        //验证是否登录成功  
        if(currentUser.isAuthenticated()){  
            System.out.println("用户[" + username + "]登录认证通过(这里可以进行一些认证通过后的一些系统参数初始化操作)");  
        }else{  
            token.clear();  
        }  
        return resultPageURL;  
	}



	public String toIndex(HttpServletRequest request) {
		String userId= (String) SecurityUtils.getSubject().getSession().getAttribute("USERID");
		User user=userMapper.selectByPrimaryKey(userId);
		request.setAttribute("userName",user.getUserName());
		return null;
	}

	
}
