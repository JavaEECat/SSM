package com.company.item.controller;



import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.company.item.model.Porchase;
import com.framework.controller.BaseController;
import com.framework.utils.PrimaryKeyUtil;
import com.framework.utils.pageUtil.PagedResult;

@Controller
@RequestMapping("/porchaseController")
public class PorchaseController extends BaseController{

	/**  */
	private static final long serialVersionUID = -384917726089271277L;
	
	
//		@RequestMapping(value="/showPorchase.ajax",produces="text/html; charset=utf-8")
//	public @ResponseBody String showPage(String n){
//
//			return porchaseService.getjson(n);
//		
//	}
		
		@RequestMapping(value = "/showPorchase.do", produces = "application/json;charset=utf-8")
		public ModelAndView showPorchase(@RequestParam(value = "pageNumber", defaultValue = "1") Integer pageNumber,
				@RequestParam(value = "pageSize", defaultValue = "3") Integer pageSize, Porchase porchase,HttpServletRequest request) {
			ModelAndView mv = new ModelAndView();
			// 当前页和每页的条数
			// 传入数据到分页工具类
			PagedResult<Porchase> pageResult = porchaseService.getAllPorchaseByPage(pageNumber, pageSize, porchase,request);
			// 数据传递到前台页面展示层
			mv.addObject("pageResult", pageResult);
			mv.setViewName("/view/porchase/allporchase_list");
			return mv;
		}
	
		/**
		 * 采购核算
		 */
		@RequestMapping("/quaryBill.ajax")
		public @ResponseBody String quaryBill(HttpServletRequest request){
			return porchaseService.getBillByTime(request);
			
		}
		
		@RequestMapping(value = "porchaseAdd.do")
		public String porchaseAdd(HttpServletRequest request, HttpServletResponse response, Model model) {
			
			return "view/porchase/porchase_add";

		}
		
		/**
		 * <p>
		 * 采购申请
		 * </p>
		 * @author ss
		 * @Date 2018年3月16日
		 * @param request
		 * @param response
		 * @param model
		 * @param porchase
		 * @return
		 */
		@RequestMapping(value = "addPorchase.do", produces = "application/text;charset=utf-8")
		public String addPorchase(HttpServletRequest request, HttpServletResponse response, Model model,Porchase porchase) {
			
			int i=porchaseService.addPorchaseByPorchase(porchase,request);	
			return "redirect:/porchaseController/showPorchaseByUserName.do";
		}

		/**
		 * <p>
		 * 显示该用户的采购单信息
		 * </p>
		 * @author ss
		 * @Date 2018年3月16日
		 * @param pageNumber
		 * @param pageSize
		 * @param porchase
		 * @param request
		 * @return
		 */
		@RequestMapping(value = "/showPorchaseByUserName.do", produces = "application/json;charset=utf-8")
		public ModelAndView showPorchaseByUserName(@RequestParam(value = "pageNumber", defaultValue = "1") Integer pageNumber,
				@RequestParam(value = "pageSize", defaultValue = "3") Integer pageSize, Porchase porchase,HttpServletRequest request) {

			ModelAndView mv = new ModelAndView();
			// 当前页和每页的条数
			// 传入数据到分页工具类
			PagedResult<Porchase> pageResult = porchaseService.getAllPorchaseByUserName(pageNumber, pageSize, porchase,request);
			// 数据传递到前台页面展示层
			mv.addObject("pageResult", pageResult);
			mv.setViewName("/view/porchase/userporchase_list");
			return mv;

		}
		
		
		@RequestMapping(value="/updateState.ajax",produces="text/html; charset=utf-8")
		public @ResponseBody String updateState(HttpServletRequest request){
			porchaseService.updateState(request);
				return "";
			
		}
		
		@RequestMapping(value="/updateStateDo.ajax",produces="text/html; charset=utf-8")
		public @ResponseBody String updateStateDo(HttpServletRequest request){
			porchaseService.updateStateDo(request);
				return "";
			
		}
		
		
		
		@RequestMapping(value = "deletePorchase.do", produces = "application/text;charset=utf-8")
		public String deletePorchase(HttpServletRequest request, HttpServletResponse response, Model model,Porchase porchase,String porchaseId) {
			porchaseService.deletePorchase(porchaseId);
			return "redirect:/porchaseController/showPorchase.do";
		}

		@RequestMapping(value = "updatePorchaseUI.do", produces = "application/text;charset=utf-8")
		public String updatePorchaseUI(HttpServletRequest request, HttpServletResponse response, Model model,String porchaseId) {
			Porchase porchase=porchaseService.quaryPorchaseByPorchaseId(porchaseId);
			model.addAttribute("porchase", porchase);
			return "view/porchase/porchase_update";
		}
		
		@RequestMapping(value = "updatePorchase.do", produces = "application/text;charset=utf-8")
		public String updatePorchase(HttpServletRequest request, HttpServletResponse response, Model model,Porchase porchase) {
			Date date=new Date();
			porchase.setApplyTime(date);
			porchase.setPropertyTotalprece(porchase.getPropertyPrece()*porchase.getPropertyNum());
			System.err.println(porchase);
			porchaseService.updatePorchase(porchase);
			
			return "redirect:/porchaseController/showPorchaseByUserName.do";
		}

}
