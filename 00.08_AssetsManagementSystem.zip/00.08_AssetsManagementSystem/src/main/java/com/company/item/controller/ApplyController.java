package com.company.item.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.company.item.model.Apply;
import com.company.item.model.Property;
import com.framework.controller.BaseController;
import com.framework.utils.pageUtil.PagedResult;

/**
 * @author ss
 *
 */
@Controller
@RequestMapping("applyController")
public class ApplyController extends BaseController{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3169440530247392595L;
	
	@RequestMapping("/addApply.do")
	public  String addApply(HttpServletRequest request) {
		
		request.setAttribute("propertyList", propertyService.quaryAllProperty());

		return "view/apply/apply_add";
	}
	
	/**
	 *返回该资产所有类型
	 * @return
	 */
	@RequestMapping("/returnType.do")
	public @ResponseBody List<Property> returnType(HttpServletRequest request,String propertyName) {
		
		return propertyService.quaryPerpertysByPropertyName(propertyName);
	}
	
	
	/**
	 *返回所有不重名资产
	 * @return
	 */
	@RequestMapping("/returnPropertyName.ajax")
	public @ResponseBody List<Property> returnPropertyName() {
		
		return propertyService.quaryAllProperty();
	}
	
	
	
	
	/**
	 * 添加申请
	 * @return
	 */
	@RequestMapping("/propertyAdd.do")
	public  String propertyAdd(Apply apply,HttpServletRequest request) {
		int i=propertyService.addPropertyByProperty(apply,request);
		
		return "view/apply/apply_add";
	}
	
	/**
	 * 查询所有申请
	 * @return
	 */
	@RequestMapping("/showApply.ajax")
	public @ResponseBody String showApply(String n) {
		return applyService.quaryApply(n);
	}
	
	
	@RequestMapping(value = "/showAllapply.do", produces = "application/json;charset=utf-8")
	public ModelAndView showAllapply(@RequestParam(value = "pageNumber", defaultValue = "1") Integer pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "3") Integer pageSize, Apply apply,HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		// 当前页和每页的条数
		// 传入数据到分页工具类
		PagedResult<Apply> pageResult = applyService.getAllPorchaseByPage(pageNumber, pageSize, apply,request);
		// 数据传递到前台页面展示层
		mv.addObject("pageResult", pageResult);
		mv.setViewName("view/apply/allapply_list");
		request.setAttribute("propertyList", propertyService.quaryAllProperty());
		return mv;
	}
	
	/**
	 * 批准申请
	 * @return
	 */
	@RequestMapping(value="/updateState.ajax", produces = "application/text;charset=utf-8")
	public @ResponseBody String updateState(String applyId) {
		return applyService.updateState(applyId);
	}
	
	/**
	 * 否定申请
	 * @return
	 */
	@RequestMapping("/updateStateDo.ajax")
	public @ResponseBody String updateStateDo(String applyId) {
		applyService.updateStateDo(applyId);
		return "";
	}
	
	/**
	 * 删除申请
	 * @return
	 */
	@RequestMapping(value = "deleteApply.do", produces = "application/text;charset=utf-8")
	public String deleteApply(String applyId) {
		applyService.deleteApply(applyId);
		return "redirect:/applyController/showAllapply.do";
	}
	
	
	/**
	 * 查询出该登录用户的所有申请
	 * @param pageNumber
	 * @param pageSize
	 * @param apply
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/showApplyByUserName.do", produces = "application/json;charset=utf-8")
	public ModelAndView showApplyByUserName(@RequestParam(value = "pageNumber", defaultValue = "1") Integer pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "3") Integer pageSize, Apply apply,HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		// 当前页和每页的条数
		// 传入数据到分页工具类
		PagedResult<Apply> pageResult = applyService.getAllApplyByUsernameByPage(pageNumber, pageSize, apply,request);
		// 数据传递到前台页面展示层
		mv.addObject("pageResult", pageResult);
		mv.setViewName("view/apply/userallapply_list");
		request.setAttribute("propertyList", propertyService.quaryAllProperty());
		return mv;
	}
	

	/**
	 * 归还资产
	 * @return
	 */
	@RequestMapping("/returnProperty.ajax")
	public @ResponseBody String returnProperty(String applyId) {
		applyService.returnProperty(applyId);
		return "";
	}
}
