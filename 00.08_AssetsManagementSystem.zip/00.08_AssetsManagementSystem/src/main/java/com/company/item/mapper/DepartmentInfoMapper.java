package com.company.item.mapper;

import java.util.List;

import com.company.item.model.DepartmentInfo;
import com.company.item.pageModel.ZtreeModel;

public interface DepartmentInfoMapper {
    int deleteByPrimaryKey(String departId);

    int insert(DepartmentInfo record);

    int insertSelective(DepartmentInfo record);

    DepartmentInfo selectByPrimaryKey(String departId);

    int updateByPrimaryKeySelective(DepartmentInfo record);

    int updateByPrimaryKey(DepartmentInfo record);

	List<DepartmentInfo> queryAllDeparts();
	
	List<ZtreeModel> selectByDepZtree();

	int selectDepartByName(String departName);
}