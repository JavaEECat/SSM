package com.company.item.mapper;

import java.util.List;

import com.company.item.model.Position;

public interface PositionMapper {
    int deleteByPrimaryKey(String positionId);

    int insert(Position record);

    int insertSelective(Position record);

    Position selectByPrimaryKey(String positionId);

    int updateByPrimaryKeySelective(Position record);

    int updateByPrimaryKey(Position record);

	List<Position> queryUserAuthr(String parameter);
}