package com.company.item.service.impl;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.item.mapper.ApplyMapper;
import com.company.item.mapper.BorrowreturnMapper;
import com.company.item.mapper.MaintainMapper;
import com.company.item.mapper.PropertyMapper;
import com.company.item.mapper.UserMapper;
import com.company.item.model.Apply;
import com.company.item.model.Borrowreturn;
import com.company.item.model.Maintain;
import com.company.item.model.Porchase;
import com.company.item.model.Property;
import com.company.item.model.User;
import com.company.item.service.ApplyService;
import com.framework.utils.PrimaryKeyUtil;
import com.framework.utils.pageUtil.PageBeanUtil;
import com.framework.utils.pageUtil.PagedResult;
import com.github.pagehelper.PageHelper;
import com.google.gson.Gson;

import sun.applet.AppletAudioClip;

@Service
public class ApplyServiceImpl implements ApplyService {

	@Autowired
	private ApplyMapper applyMapper;
	@Autowired
	private BorrowreturnMapper borrowreturnMapper;
	@Autowired
	private UserMapper userMapper;
	@Autowired
	private PropertyMapper propertyMapper;
	@Autowired
	private MaintainMapper maintainMapper;

	public String quaryApply(String n) {
		int nn = 0;
		if (n != null) {
			nn = Integer.parseInt(n);
		} else {
			nn = 1;
		}
		nn = (nn + 1) * 3;
		List<Apply> applyList = applyMapper.quaryApply(nn);
		System.out.println(applyList);
		Gson g = new Gson();
		return g.toJson(applyList);
	}

	public PagedResult<Apply> getAllPorchaseByPage(Integer pageNumber, Integer pageSize, Apply apply,
			HttpServletRequest request) {
		if (apply.getPropertyName() == null || apply.getType() == null) {

		} else {
			if (apply.getPropertyName().equals("请选择资产名字")) {
				apply.setPropertyName("");
			}
			if (apply.getType().equals("请选择型号")) {
				apply.setType("");
			}
		}
		List<Apply> g = applyMapper.queryAllPorchases(apply);
		request.setAttribute("applysNum", g.size());
		// 1.调用分页插件
		PageHelper.startPage(pageNumber, pageSize);
		// 2.查询数据库，获取数据
		List<Apply> glist = applyMapper.queryAllPorchases(apply);
		// 3.通过分页工具类加载分页数据
		// request.setAttribute("porchasesNum",
		// glist.size());因为分页插件的原因，只能查出某页的数据
		return PageBeanUtil.toPagedResult(glist);
	}

	public String updateState(String applyId) {
		Apply apply = applyMapper.selectByPrimaryKey(applyId);
			// 维护资产表
		Property property = propertyMapper.quaryPropertyByName(apply.getPropertyName(), apply.getType());
		int k = property.getPropertyNum() - apply.getPropertyNum();//通过资产库存和申请数量的比较得出k，k值的正负决定是否库存充足
		if (k < 0) {
			return "库存不足";
		} else {
			// 同意申请
			apply.setApplyState("同意");
			applyMapper.updateByPrimaryKeySelective(apply);
			// 维护资产流动表
			Borrowreturn br = new Borrowreturn();
			br.setBorrowreturnId(PrimaryKeyUtil.getPrimaryKey());
			br.setPropertyName(apply.getPropertyName());
			br.setPropertyNum(apply.getPropertyNum());
			br.setType(apply.getType());
			br.setUserName(apply.getUserName());
			br.setBorrowreturnState("借");
			borrowreturnMapper.insertSelective(br);
			// 维护资产表
			property.setPropertyNum(k);
			propertyMapper.updateByPrimaryKeySelective(property);
			return "";
		}
	}
	public void updateStateDo(String applyId) {
		// 否定申请
		Apply apply = applyMapper.selectByPrimaryKey(applyId);
		apply.setApplyState("审核中");
		applyMapper.updateByPrimaryKeySelective(apply);

		Borrowreturn borrowreturn = borrowreturnMapper.quaryBorrowReturn(apply.getPropertyName(), apply.getType(),
				apply.getUserName());
		if (borrowreturn != null) {
			borrowreturnMapper.deleteByPrimaryKey(borrowreturn.getBorrowreturnId());
		}
	}
	public void deleteApply(String applyId) {
		applyMapper.deleteByPrimaryKey(applyId);

	}
	public PagedResult<Apply> getAllApplyByUsernameByPage(Integer pageNumber, Integer pageSize, Apply apply,
			HttpServletRequest request) {
		if (apply.getPropertyName() == null || apply.getType() == null) {

		} else {
			if (apply.getPropertyName().equals("请选择资产名字")) {
				apply.setPropertyName("");
			}
			if (apply.getType().equals("请选择型号")) {
				apply.setType("");
			}
		}
		String userId = (String) request.getSession().getAttribute("USERID");
		User user = userMapper.selectByPrimaryKey(userId);
		apply.setUserName(user.getUserName());
		apply.setApplyState("同意");

		List<Apply> g = applyMapper.getAllApplyByUsername(apply);
		request.setAttribute("userApplysNum", g.size());

		// 返回所有维修单
		Maintain maintain = new Maintain();
		List<Maintain> mList = maintainMapper.queryAllMaintain(maintain);
		request.setAttribute("mList", mList);
		// 1.调用分页插件
		PageHelper.startPage(pageNumber, pageSize);
		// 2.查询数据库，获取数据
		List<Apply> glist = applyMapper.getAllApplyByUsername(apply);
		// 3.通过分页工具类加载分页数据
		// request.setAttribute("porchasesNum",
		// glist.size());因为分页插件的原因，只能查出某页的数据
		return PageBeanUtil.toPagedResult(glist);
	}
	public void returnProperty(String applyId) {
		// 维护申请表的归还时间字段
		Apply apply = applyMapper.selectByPrimaryKey(applyId);
		apply.setApplyState("使用完");//修改状态实现申请批准
		Date date = new Date();
		apply.setSestoreTime(date);//申请时间
		applyMapper.updateByPrimaryKeySelective(apply);
		// 维护资产流动（借还）表
		Borrowreturn borrowreturn = borrowreturnMapper.quaryBorrowReturn(apply.getPropertyName(), apply.getType(),
				apply.getUserName());
		borrowreturn.setBorrowreturnState("还");
		borrowreturn.setBorrowreturnTime(date);
		borrowreturnMapper.updateByPrimaryKeySelective(borrowreturn);
		// 维护资产表的信息
		Property property = propertyMapper.quaryPropertyByName(apply.getPropertyName(), apply.getType());
		int k = property.getPropertyNum() + apply.getPropertyNum();
		property.setPropertyNum(k);
		propertyMapper.updateByPrimaryKeySelective(property);
	}
		//返回在用资产
	public List<Apply> quaryAllUserApply(HttpServletRequest request) {
		Apply apply = new Apply();
		String userId = (String) request.getSession().getAttribute("USERID");
		User user = userMapper.selectByPrimaryKey(userId);
		String applyState = "同意";
		apply.setUserName(user.getUserName());
		apply.setApplyState(applyState);
		List<Apply> aList = applyMapper.getAllApplyByUsername(apply);
		return aList;
	}

}
