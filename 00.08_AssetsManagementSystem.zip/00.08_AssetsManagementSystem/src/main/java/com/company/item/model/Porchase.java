package com.company.item.model;

import java.util.Date;

public class Porchase {
    private String porchaseId;

    private String propertyName;

    private String type;

    private Integer propertyNum;

    private Integer propertyPrece;

    private Integer propertyTotalprece;

    private String userName;

    private String approveState;

    private Date applyTime;

    private Date finishTime;

 
	public Porchase() {
		super();
	}

	public Porchase(String porchaseId, String propertyName, String type, Integer propertyNum, Integer propertyPrece,
			Integer propertyTotalprece, String userName, String approveState, Date applyTime, Date finishTime) {
		super();
		this.porchaseId = porchaseId;
		this.propertyName = propertyName;
		this.type = type;
		this.propertyNum = propertyNum;
		this.propertyPrece = propertyPrece;
		this.propertyTotalprece = propertyTotalprece;
		this.userName = userName;
		this.approveState = approveState;
		this.applyTime = applyTime;
		this.finishTime = finishTime;
	}

	@Override
	public String toString() {
		return "Porchase [porchaseId=" + porchaseId + ", propertyName=" + propertyName + ", type=" + type
				+ ", propertyNum=" + propertyNum + ", propertyPrece=" + propertyPrece + ", propertyTotalprece="
				+ propertyTotalprece + ", userName=" + userName + ", approveState=" + approveState + ", applyTime="
				+ applyTime + ", finishTime=" + finishTime + "]";
	}

	public String getPorchaseId() {
        return porchaseId;
    }

    public void setPorchaseId(String porchaseId) {
        this.porchaseId = porchaseId;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getPropertyNum() {
        return propertyNum;
    }

    public void setPropertyNum(Integer propertyNum) {
        this.propertyNum = propertyNum;
    }

    public Integer getPropertyPrece() {
        return propertyPrece;
    }

    public void setPropertyPrece(Integer propertyPrece) {
        this.propertyPrece = propertyPrece;
    }

    public Integer getPropertyTotalprece() {
        return propertyTotalprece;
    }

    public void setPropertyTotalprece(Integer propertyTotalprece) {
        this.propertyTotalprece = propertyTotalprece;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getApproveState() {
        return approveState;
    }

    public void setApproveState(String approveState) {
        this.approveState = approveState;
    }

    public Date getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    public Date getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(Date finishTime) {
        this.finishTime = finishTime;
    }
}