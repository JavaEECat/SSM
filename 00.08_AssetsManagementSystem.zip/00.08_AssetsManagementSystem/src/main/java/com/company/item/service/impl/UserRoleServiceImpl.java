package com.company.item.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.company.item.mapper.AuthorityMapper;
import com.company.item.mapper.DepartmentInfoMapper;
import com.company.item.mapper.PositionMapper;
import com.company.item.mapper.RoleAuthrMapper;
import com.company.item.mapper.UserMapper;
import com.company.item.mapper.UserPositionMapper;
import com.company.item.model.Authority;
import com.company.item.model.DepartmentInfo;
import com.company.item.model.Position;
import com.company.item.model.RoleAuthr;
import com.company.item.model.User;
import com.company.item.model.UserPosition;
import com.company.item.pageModel.PageModel;
import com.company.item.service.UserRoleService;
@Service
public class UserRoleServiceImpl implements UserRoleService {
	@Resource
	UserMapper userMapper;
	@Resource
	PositionMapper pMapper;
	@Resource
	UserPositionMapper UPMapper;
	@Resource
	DepartmentInfoMapper departMapper;
	@Resource
	AuthorityMapper AMapper;
	@Resource
	RoleAuthrMapper RAMapper;
	public String getUserRole(HttpServletRequest request) {
		String index=request.getParameter("index");
		//创建分页对象
		PageModel pageModel=new PageModel();
		int PageIndex=0;
		if (index!=null&&!index.equals("-1")) {
			PageIndex=(Integer.parseInt(index)-1)*1;
		}else {
			
				String total;
				List<User> uerNum=userMapper.queryByRole(request.getParameter("depart"), request.getParameter("authr"), request.getParameter("userName"), null);
				total= uerNum.get(0).getAccountNumber();
				pageModel.setTotal(total);
			
		}
		//取出分页的数据
		List<User> users=userMapper.queryByRole(request.getParameter("depart"), request.getParameter("authr"), request.getParameter("userName"), PageIndex);
		pageModel.setList(users);
		return PageModel.toJson(pageModel);
	}

	public String changeUserRole(HttpServletRequest request) {
		String userId=request.getParameter("userId");
		List<Position> positions=pMapper.queryUserAuthr(userId);
		request.setAttribute("role",positions);
		User userDB=userMapper.selectByPrimaryKey(userId);
		User userView=new User();
		userView.setUserId(userId);
		userView.setUserName(userDB.getUserName());
		userView.setUserPosition(userDB.getUserPosition());
		request.setAttribute("user", userView);
		return positions.size()+"";
	}

	public String submitRoles(HttpServletRequest request) {
		String[] roles=request.getParameterValues("roles");
		String userId=request.getParameter("userId");
		List<String> addRoles=new ArrayList<String>();
		List<Position> delRoles=pMapper.queryUserAuthr(userId);
		if (roles!=null&&roles.length>0) {
		addRoles.addAll(Arrays.asList(roles));
		if (delRoles!=null&&delRoles.size()>0) {
			for (int i = 0; i < roles.length; i++) {
				for (int j = 0; j < delRoles.size(); j++) {
					if (roles[i].equals(delRoles.get(j).getPositionId())) {
						addRoles.remove(roles[i]);//删除公共元素
						delRoles.remove(j);//获得新增加权限与删除的权限
					}
				}
			}
		}
		
	}	
		if (addRoles!=null&&addRoles.size()>0) {
			//addroles 有元素代表有添加操作
			for(String id:addRoles) {
				UserPosition userPosition=new UserPosition();
				userPosition.setUserPositionId(UUID.randomUUID().toString());
				userPosition.setUserId(userId);
				userPosition.setPositionId(id);
				UPMapper.insert(userPosition);
			}			
		}
		if (delRoles!=null&&delRoles.size()>0) {
			for(Position position:delRoles) {
				UserPosition userPosition=new UserPosition();
				userPosition.setUserId(userId);
				userPosition.setPositionId(position.getPositionId());
			int n=UPMapper.deleteByUserAndPosId(userPosition);
			}
		}
		
		return null;
	}

	public String getDeparts(HttpServletRequest request) {
		List<DepartmentInfo> departs=departMapper.queryAllDeparts();
		request.setAttribute("departs", departs);
		return departs.size() +"";
	}

	public String getDepartsRole(HttpServletRequest request) {
		String departId=request.getParameter("departId");
		System.err.println(departId);
		List<Authority> departAuthr=AMapper.selectByDepart(departId);
		List<Authority> AllAuthrs=AMapper.selectAllAuthrs();
		request.setAttribute("AllAuthrs", AllAuthrs);
		request.setAttribute("authrs",departAuthr);
		
		DepartmentInfo departmentInfo=departMapper.selectByPrimaryKey(departId);
		request.setAttribute("depart",departmentInfo);
		return null;
	}

	public String submitDepartRoles(HttpServletRequest request) {
		String[] roles=request.getParameterValues("roles");//前台获取权限checkbox勾选值
		String departId=request.getParameter("departId");//前台传来的departId
		System.err.println(departId);
		List<String> addRoles=new ArrayList<String>();//要添加的新权限
		List<Authority> delRoles=AMapper.selectByDepart(departId);//要删除的旧权限
		if (roles!=null&&roles.length>0) {
		addRoles.addAll(Arrays.asList(roles));
		if (delRoles!=null&&delRoles.size()>0) {
			for (int i = 0; i < roles.length; i++) {
				for (int j = 0; j < delRoles.size(); j++) {
					if (roles[i].equals(delRoles.get(j).getAuthorityId())) {
						addRoles.remove(roles[i]);//删除公共元素
						delRoles.remove(j);//获得新增加权限与删除的权限
					}
				}
			}
		}
		
	}	
		if (addRoles!=null&&addRoles.size()>0) {
			//addroles 有元素代表有添加操作
			for(String id:addRoles) {
				RoleAuthr rAuthr=new RoleAuthr();
				rAuthr.setRoleAuthrId(UUID.randomUUID().toString());
				rAuthr.setAuthrId(id);
				rAuthr.setRoleId(departId);
				RAMapper.insert(rAuthr);
			}			
		}
		if (delRoles!=null&&delRoles.size()>0) {
			//删除公共部分有剩余代表要删除
			for(Authority authority:delRoles) {
				RoleAuthr rAuthr=new RoleAuthr();
				rAuthr.setRoleId(departId);
				rAuthr.setAuthrId(authority.getAuthorityId());
			int n=RAMapper.deleteByRoleAndAuthr(rAuthr);
			}
		}
		
		return null;
	}

}
