package com.company.item.model;

import java.util.Date;

public class User {
	
    private String userId;

    private String userName;

    private String userSex;

    private String userPosition;

    private String userTelephone;

    private String userEmail;

    private String userAddress;

    private Date userEntrytime;

    private String userDiploma;

    private String userDepartement;

    private String accountNumber;

    private String password;

    private Date userBirthday;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserSex() {
        return userSex;
    }

    public void setUserSex(String userSex) {
        this.userSex = userSex;
    }

    public String getUserPosition() {
        return userPosition;
    }

    public void setUserPosition(String userPosition) {
        this.userPosition = userPosition;
    }

    public String getUserTelephone() {
        return userTelephone;
    }

    public void setUserTelephone(String userTelephone) {
        this.userTelephone = userTelephone;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public Date getUserEntrytime() {
        return userEntrytime;
    }

    public void setUserEntrytime(Date userEntrytime) {
        this.userEntrytime = userEntrytime;
    }

    public String getUserDiploma() {
        return userDiploma;
    }

    public void setUserDiploma(String userDiploma) {
        this.userDiploma = userDiploma;
    }

    public String getUserDepartement() {
        return userDepartement;
    }

    public void setUserDepartement(String userDepartement) {
        this.userDepartement = userDepartement;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getUserBirthday() {
        return userBirthday;
    }

    public void setUserBirthday(Date userBirthday) {
        this.userBirthday = userBirthday;
    }

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userSex=" + userSex + ", userPosition="
				+ userPosition + ", userTelephone=" + userTelephone + ", userEmail=" + userEmail + ", userAddress="
				+ userAddress + ", userEntrytime=" + userEntrytime + ", userDiploma=" + userDiploma
				+ ", userDepartement=" + userDepartement + ", accountNumber=" + accountNumber + ", password=" + password
				+ ", userBirthday=" + userBirthday + "]";
	}
    
}