package com.company.item.mapper;

import com.company.item.model.UserPosition;

public interface UserPositionMapper {
    int deleteByPrimaryKey(String userPositionId);

    int insert(UserPosition record);

    int insertSelective(UserPosition record);

    UserPosition selectByPrimaryKey(String userPositionId);

    int updateByPrimaryKeySelective(UserPosition record);

    int updateByPrimaryKey(UserPosition record);

	int deleteByUserAndPosId(UserPosition userPosition);
}