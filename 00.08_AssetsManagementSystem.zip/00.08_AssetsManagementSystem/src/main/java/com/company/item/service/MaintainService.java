package com.company.item.service;

import javax.servlet.http.HttpServletRequest;

import com.company.item.model.Maintain;
import com.framework.utils.pageUtil.PagedResult;

public interface MaintainService {

	int addMaintainByMaintain(Maintain maintain, HttpServletRequest request);

	PagedResult<Maintain> getAllMaintainByPage(Integer pageNumber, Integer pageSize, Maintain maintain,
			HttpServletRequest request);

	String updateState(String maintainId);

	void updateStateDo(String maintainId);

	void deleteApply(String maintainId);

	void maintainFinish(String maintainId);

}
