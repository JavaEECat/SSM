package com.company.item.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.company.item.model.User;

public interface UserService {

	String checkUser(HttpServletRequest request,HttpServletResponse response);

	User getUserBySession();
	
	String getServerName();
	
	String getServerTime();

	String rememberUser(HttpServletRequest request);

	void deleteAutoLogin(HttpServletRequest request, HttpServletResponse response);

	void deleteUserSession(HttpServletRequest request);
	
	String Userlogin(HttpServletRequest request, HttpServletResponse response);

	String toIndex(HttpServletRequest request);
}
