package com.company.item.service;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.company.item.model.Apply;
import com.framework.utils.pageUtil.PagedResult;

public interface ApplyService {

	String quaryApply(String n);

	PagedResult<Apply> getAllPorchaseByPage(Integer pageNumber, Integer pageSize, Apply apply,
			HttpServletRequest request);

	String updateState(String applyId);

	void updateStateDo(String applyId);

	void deleteApply(String applyId);

	PagedResult<Apply> getAllApplyByUsernameByPage(Integer pageNumber, Integer pageSize, Apply apply,
			HttpServletRequest request);

	void returnProperty(String applyId);

	List<Apply> quaryAllUserApply(HttpServletRequest request);

}
