package com.company.item.pageModel;

import java.util.Date;

public class RoleModel {
	 private String userId;

	    private String userName;


	    private String userPosition;


	    private Date userEntrytime;


	    private String userDepartement;


		@Override
		public String toString() {
			return "RoleModel [userId=" + userId + ", userName=" + userName + ", userPosition=" + userPosition
					+ ", userEntrytime=" + userEntrytime + ", userDepartement=" + userDepartement + "]";
		}


		public String getUserId() {
			return userId;
		}


		public void setUserId(String userId) {
			this.userId = userId;
		}


		public String getUserName() {
			return userName;
		}


		public void setUserName(String userName) {
			this.userName = userName;
		}


		public String getUserPosition() {
			return userPosition;
		}


		public void setUserPosition(String userPosition) {
			this.userPosition = userPosition;
		}


		public Date getUserEntrytime() {
			return userEntrytime;
		}


		public void setUserEntrytime(Date userEntrytime) {
			this.userEntrytime = userEntrytime;
		}


		public String getUserDepartement() {
			return userDepartement;
		}


		public void setUserDepartement(String userDepartement) {
			this.userDepartement = userDepartement;
		}
	    
	    


}
