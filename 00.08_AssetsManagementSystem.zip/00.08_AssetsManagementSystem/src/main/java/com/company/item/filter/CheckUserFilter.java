package com.company.item.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class CheckUserFilter implements Filter{

	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
			throws IOException, ServletException {
		//获取当前项目的spring ioc容器
		ApplicationContext context=WebApplicationContextUtils.getWebApplicationContext(arg0.getServletContext());
		
		
		HttpServletRequest hsr=(HttpServletRequest) arg0;
		HttpServletResponse hsp=(HttpServletResponse) arg1;
		String projectName=hsr.getContextPath();//获取项目名称
		String url=hsr.getRequestURI();//获取请求路径
		if(url.equals(projectName+"/indexController/login.do")) {//判定是否为合法请求
			arg2.doFilter(arg0, arg1);//放行
		}else {
			String userid=(String) hsr.getSession().getAttribute("USERID");

			if(userid!=null) {
//				System.err.println(url);
//				System.err.println(userid);判断访问路径是否符合逻辑
				arg2.doFilter(arg0, arg1);//放行
			}else {
				hsp.sendRedirect(projectName+"/indexController/login.do");//未登录，跳转到登录页面
//				hsr.getRequestDispatcher("").forward(arg0, arg1);转发
			}
		}
		
	}

	public void init(FilterConfig arg0) throws ServletException {
		
		
	}

}
