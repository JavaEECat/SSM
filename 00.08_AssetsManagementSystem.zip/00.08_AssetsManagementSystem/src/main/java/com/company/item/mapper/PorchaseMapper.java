package com.company.item.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.company.item.model.Porchase;

public interface PorchaseMapper {
    int deleteByPrimaryKey(String porchaseId);

    int insert(Porchase record);

    int insertSelective(Porchase record);

    Porchase selectByPrimaryKey(String porchaseId);

    int updateByPrimaryKeySelective(Porchase record);

    int updateByPrimaryKey(Porchase record);
    
    
    List<Porchase> getAllPorchaseByUserName(Porchase porchase);

	int updateState(@Param(value="porchaseId") String porchaseId, @Param(value="approveState") String approveState);

	List<Porchase> queryAllPorchases(Porchase porchase);

	List<Porchase> quaryPorchasesBytime(@Param(value="time1") String time1, @Param(value="time2") String time2);
}