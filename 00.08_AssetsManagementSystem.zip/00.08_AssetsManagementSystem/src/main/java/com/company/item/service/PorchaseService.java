package com.company.item.service;

import javax.servlet.http.HttpServletRequest;

import com.company.item.model.Porchase;
import com.company.item.model.Property;
import com.framework.utils.pageUtil.PagedResult;

public interface PorchaseService {

	String getjson(String n);

	PagedResult<Porchase> getAllPorchaseByPage(Integer pageNumber, Integer pageSize, Porchase porchase,HttpServletRequest request);

	String getBillByTime(HttpServletRequest request);

	int addPorchaseByPorchase(Porchase porchase, HttpServletRequest request);

	

	PagedResult<Porchase> getAllPorchaseByUserName(Integer pageNumber, Integer pageSize, Porchase porchase,
			HttpServletRequest request);

	void updateState(HttpServletRequest request);

	void updateStateDo(HttpServletRequest request);

	void deletePorchase(String porchaseId);

	Porchase quaryPorchaseByPorchaseId(String porchaseId);

	void updatePorchase(Porchase porchase);

}
