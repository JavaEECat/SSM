package com.company.item.service.impl;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.item.mapper.BorrowreturnMapper;
import com.company.item.mapper.PorchaseMapper;
import com.company.item.mapper.PropertyMapper;
import com.company.item.mapper.UserMapper;
import com.company.item.model.Borrowreturn;
import com.company.item.model.Porchase;
import com.company.item.model.Property;
import com.company.item.model.User;
import com.company.item.service.PorchaseService;
import com.framework.utils.PrimaryKeyUtil;
import com.framework.utils.pageUtil.PageBeanUtil;
import com.framework.utils.pageUtil.PagedResult;
import com.github.pagehelper.PageHelper;
import com.google.gson.Gson;

@Service
public class PorchaseServiceImpl implements PorchaseService {
	@Autowired
	private PorchaseMapper porchaseMapper;

	@Autowired
	private UserMapper userMapper;

	@Autowired
	private PropertyMapper propertyMapper;

	@Autowired
	private BorrowreturnMapper borrowreturnMapper;

	public String getjson(String n) {
		int nn = Integer.parseInt(n);
		nn = (nn - 1) * 3;
		// List<Porchase> pList=porchaseMapper.auqryAllPorchase(nn);
		Gson g = new Gson();
		// return g.toJson(pList);
		return null;
	}

	public PagedResult<Porchase> getAllPorchaseByPage(Integer pageNumber, Integer pageSize, Porchase porchase,
			HttpServletRequest request) {

		List<Porchase> g = porchaseMapper.queryAllPorchases(porchase);
		request.setAttribute("porchasesNum", g.size());
		// 1.调用分页插件
		PageHelper.startPage(pageNumber, pageSize);
		// 2.查询数据库，获取数据
		List<Porchase> glist = porchaseMapper.queryAllPorchases(porchase);
		// 3.通过分页工具类加载分页数据
		// request.setAttribute("porchasesNum",
		// glist.size());因为分页插件的原因，只能查出某页的数据
		return PageBeanUtil.toPagedResult(glist);
	}

	public String getBillByTime(HttpServletRequest request) {
		int totalPrices = 0;

		String time1 = request.getParameter("porchaseTime1");
		String time2 = request.getParameter("porchaseTime2");

		/*
		 * DateFormat df=new SimpleDateFormat("YYYY-MM-dd");
		 * 
		 * try { Date time1=df.parse(porchaseTime1); Date
		 * time2=df.parse(porchaseTime2); List<Porchase>
		 * pList=porchaseMapper.quaryPorchasesBytime(time1,time2); } catch
		 * (ParseException e) {
		 * 
		 * e.printStackTrace(); }
		 */
		List<Porchase> pList = porchaseMapper.quaryPorchasesBytime(time1, time2);
		for (int i = 0; i < pList.size(); i++) {
			if (pList.get(i).getApproveState().equals("同意")) {
				totalPrices = totalPrices + pList.get(i).getPropertyPrece() * pList.get(i).getPropertyNum();
			}
		}
		String totalPricesString = String.valueOf(totalPrices);// double转化成字符串
		return totalPricesString;
	}

	public PagedResult<Porchase> getAllPorchaseByUserName(Integer pageNumber, Integer pageSize, Porchase porchase,
			HttpServletRequest request) {
		String userId = (String) request.getSession().getAttribute("USERID");
		User user = userMapper.selectByPrimaryKey(userId);
		porchase.setUserName(user.getUserName());

		List<Porchase> g = porchaseMapper.getAllPorchaseByUserName(porchase);
		request.setAttribute("porchasesNum", g.size());
		// 1.调用分页插件
		PageHelper.startPage(pageNumber, pageSize);
		// 2.查询数据库，获取数据
		List<Porchase> glist = porchaseMapper.getAllPorchaseByUserName(porchase);

		// 3.通过分页工具类加载分页数据
		request.setAttribute("porchasesNum", glist.size());// 因为分页插件的原因，只能查出某页的数据
		return PageBeanUtil.toPagedResult(glist);
	}

	public void updateState(HttpServletRequest request) {
		String porchaseId = request.getParameter("porchaseId");
		Porchase p = porchaseMapper.selectByPrimaryKey(porchaseId);
		String approveState = "审核中";
		int i = porchaseMapper.updateState(porchaseId, approveState);
		// 删除之前存在的流动单
		Borrowreturn borrowreturn = borrowreturnMapper.quaryBorrowReturn(p.getPropertyName(), p.getType(),
				p.getUserName());
		if (borrowreturn != null) {
			borrowreturnMapper.deleteByPrimaryKey(borrowreturn.getBorrowreturnId());
		}
	}
		//通过改变采购表的批准状态来实现对采购的审批
	public void updateStateDo(HttpServletRequest request) {
		String porchaseId = request.getParameter("porchaseId");
		Porchase p = porchaseMapper.selectByPrimaryKey(porchaseId);//获取选中采购信息
		String approveState = "同意";//修改状态来实现批准
		// 修改审批状态
		int i = porchaseMapper.updateState(porchaseId, approveState);
		// 增加资产流动表的信息
		String userId = (String) request.getSession().getAttribute("USERID");
		User user = userMapper.selectByPrimaryKey(userId);//用过session
		Borrowreturn bw = new Borrowreturn();
		bw.setBorrowreturnId(PrimaryKeyUtil.getPrimaryKey());
		bw.setPropertyName(p.getPropertyName());
		bw.setType(p.getType());
		bw.setPropertyNum(p.getPropertyNum());
		bw.setBorrowreturnState("采购");
		bw.setBorrowreturnTime(p.getFinishTime());
		int m = borrowreturnMapper.insertSelective(bw);
		// 维护资产表信息
		Property pp = propertyMapper.quaryPropertyByName(p.getPropertyName(), p.getType());
		pp.setPropertyNum(pp.getPropertyNum() + p.getPropertyNum());//将该资产的数量进行叠加
		propertyMapper.updateByPrimaryKeySelective(pp);
	}
		// 删除财产
	public void deletePorchase(String porchaseId) {
		porchaseMapper.deleteByPrimaryKey(porchaseId);
	}
		// 查询该id的资产
	public Porchase quaryPorchaseByPorchaseId(String porchaseId) {
		return porchaseMapper.selectByPrimaryKey(porchaseId);
	}
		// 修改资产
	public void updatePorchase(Porchase porchase) {
		porchaseMapper.updateByPrimaryKey(porchase);
	}
		// 增加采购申请
	public int addPorchaseByPorchase(Porchase porchase, HttpServletRequest request) {
		String userId = (String) request.getSession().getAttribute("USERID");
		User user = userMapper.selectByPrimaryKey(userId);
		porchase.setPorchaseId(PrimaryKeyUtil.getPrimaryKey());
		porchase.setApproveState("审核中");
		Date d = new Date();
		// DateFormat dF=new SimpleDateFormat("YYYY-MM-dd hh-mm-ss");
		porchase.setApplyTime(d);
		porchase.setUserName(user.getUserName());
		porchase.setPropertyTotalprece(porchase.getPropertyPrece() * porchase.getPropertyNum());
		return porchaseMapper.insertSelective(porchase);
	}

}
