package com.company.item.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.company.item.model.Apply;
import com.company.item.model.Borrowreturn;
import com.company.item.model.Property;
import com.framework.utils.pageUtil.PagedResult;

public interface PropertyService {

	List<Property> quaryPerpertysByPropertyName(String propertyName);

	int addPropertyByProperty(Apply apply, HttpServletRequest request);

	List<Property> quaryAllProperty();

	PagedResult<Property> getAllPropertyByPage(Integer pageNumber, Integer pageSize, Property property,
			HttpServletRequest request);

	List<Property> returnMalltypeName(String bigtypeName);

	List<Property> returnPropertyName(String malltypeName);

	void deleteProperty(String propertyId);

	PagedResult<Borrowreturn> getAllBorrowreturnByPage(Integer pageNumber, Integer pageSize, Borrowreturn borrowreturn,
			HttpServletRequest request);

	void addProperty(Property property, String malltypeName2, String propertyName2, String type2);


}
