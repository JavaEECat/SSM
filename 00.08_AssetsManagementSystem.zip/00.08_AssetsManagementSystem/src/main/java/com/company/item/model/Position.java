package com.company.item.model;

public class Position {
    private String positionId;

    private String positionName;

    private String positionDescription;

    private String positionDepart;

    public String getPositionId() {
        return positionId;
    }

    public void setPositionId(String positionId) {
        this.positionId = positionId;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public String getPositionDescription() {
        return positionDescription;
    }

    public void setPositionDescription(String positionDescription) {
        this.positionDescription = positionDescription;
    }

    public String getPositionDepart() {
        return positionDepart;
    }

    public void setPositionDepart(String positionDepart) {
        this.positionDepart = positionDepart;
    }

	@Override
	public String toString() {
		return "Position [positionId=" + positionId + ", positionName=" + positionName + ", positionDescription="
				+ positionDescription + ", positionDepart=" + positionDepart + "]";
	}
    
}