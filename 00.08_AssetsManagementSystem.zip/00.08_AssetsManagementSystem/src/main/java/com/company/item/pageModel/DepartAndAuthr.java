package com.company.item.pageModel;

import java.util.List;

import org.aspectj.weaver.ast.Var;

import com.company.item.model.Authority;
import com.company.item.model.DepartmentInfo;

public class DepartAndAuthr {
    private String departId;

    private String departName;

    private String departDesc;

    private String departManager;
    
    private String authrs;

    public  DepartAndAuthr() {
    	
    }
    	public  DepartAndAuthr(DepartmentInfo departmentInfo,List<Authority> authorities) {
    	departId=departmentInfo.getDepartId();
    	departName=departmentInfo.getDepartName();
    	departDesc=departmentInfo.getDepartDesc();
    	departManager=departmentInfo.getDepartManager();
    	String str="";
    	for(Authority authr  :authorities){
    		str+=authr.getAuthorityDescription()+" ";
    	}
    	authrs=str;
    }
	public String getDepartId() {
		return departId;
	}

	public void setDepartId(String departId) {
		this.departId = departId;
	}

	public String getDepartName() {
		return departName;
	}

	public void setDepartName(String departName) {
		this.departName = departName;
	}

	public String getDepartDesc() {
		return departDesc;
	}

	public void setDepartDesc(String departDesc) {
		this.departDesc = departDesc;
	}

	public String getDepartManager() {
		return departManager;
	}

	public void setDepartManager(String departManager) {
		this.departManager = departManager;
	}

	public String getAuthrs() {
		return authrs;
	}

	public void setAuthrs(String authrs) {
		this.authrs = authrs;
	}

	@Override
	public String toString() {
		return "DepartAndAuthr [departId=" + departId + ", departName=" + departName + ", departDesc=" + departDesc
				+ ", departManager=" + departManager + ", authrs=" + authrs + "]";
	}
    
  
}
