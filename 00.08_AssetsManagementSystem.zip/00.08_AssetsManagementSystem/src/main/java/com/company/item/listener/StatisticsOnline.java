package com.company.item.listener;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class StatisticsOnline implements HttpSessionListener{

	public void sessionCreated(HttpSessionEvent arg0) {
		ServletContext sc=arg0.getSession().getServletContext();
		Integer integer= (Integer) sc.getAttribute("OnlineNum");
		integer++;
		sc.setAttribute("OnlineNum", integer);
		
	}

	public void sessionDestroyed(HttpSessionEvent arg0) {
		ServletContext sc=arg0.getSession().getServletContext();
		Integer integer=(Integer) sc.getAttribute("OnlineNum");
		integer--;
		if(integer<0){
			integer=0;
		}
		sc.setAttribute("OnlineNum", integer);
	}

}
