package com.company.item.model;

import java.util.Date;

public class Borrowreturn {
    private String borrowreturnId;

    private String propertyName;

    private String type;

    private Integer propertyNum;

    private String userName;

    private String borrowreturnState;

    private Date borrowreturnTime;

    public String getBorrowreturnId() {
        return borrowreturnId;
    }

    public void setBorrowreturnId(String borrowreturnId) {
        this.borrowreturnId = borrowreturnId;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getPropertyNum() {
        return propertyNum;
    }

    public void setPropertyNum(Integer propertyNum) {
        this.propertyNum = propertyNum;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getBorrowreturnState() {
        return borrowreturnState;
    }

    public void setBorrowreturnState(String borrowreturnState) {
        this.borrowreturnState = borrowreturnState;
    }

    public Date getBorrowreturnTime() {
        return borrowreturnTime;
    }

    public void setBorrowreturnTime(Date borrowreturnTime) {
        this.borrowreturnTime = borrowreturnTime;
    }
}