package com.company.item.model;

public class Structure {
    private Integer structureId;

    private Integer structurePid;

    private String structureDescription;

    public Integer getStructureId() {
        return structureId;
    }

    public void setStructureId(Integer structureId) {
        this.structureId = structureId;
    }

    public Integer getStructurePid() {
        return structurePid;
    }

    public void setStructurePid(Integer structurePid) {
        this.structurePid = structurePid;
    }

    public String getStructureDescription() {
        return structureDescription;
    }

    public void setStructureDescription(String structureDescription) {
        this.structureDescription = structureDescription;
    }
}