package com.company.item.service.impl;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.company.item.mapper.AuthorityMapper;
import com.company.item.mapper.DepartmentInfoMapper;
import com.company.item.mapper.RoleAuthrMapper;
import com.company.item.mapper.UserMapper;
import com.company.item.model.Authority;
import com.company.item.model.DepartmentInfo;
import com.company.item.model.RoleAuthr;
import com.company.item.model.User;
import com.company.item.pageModel.DepartAndAuthr;
import com.company.item.pageModel.PageModel;
import com.company.item.pageModel.ZtreeModel;
import com.company.item.searchModel.UserSearch;
import com.company.item.service.EmeSerive;
import com.framework.utils.EncryptionUtil;
@Service
public class EmeServiceImpl implements EmeSerive {
		@Resource
		UserMapper UM;
		@Resource
		DepartmentInfoMapper DIM;
		@Resource
		AuthorityMapper AM;
		@Resource
		RoleAuthrMapper RAM;
		/**
		 * UserSearch 跟的成员变量为过滤条件获取数据
		 * </br> request中index为-1 会查询所有的数据条数
		 * */
		public String getUsersDB(HttpServletRequest request, UserSearch uSearch) {
//			String indexStr=request.getParameter("index");
//			Integer index=0;
			PageModel pageModel=new PageModel();
			if (uSearch!=null&&uSearch.getIndex()!=null&&uSearch.getIndex()!=-1) {
				uSearch.setIndex((uSearch.getIndex()-1)*1);
				//indexStr 为有效范围 0-n时为正常查询数据
			}else {
				//否则查询所有数据条数
				uSearch.setIndex(null);
				List<User> userTotal=UM.quaryUserByManager(uSearch);
				pageModel.setTotal(userTotal.get(0).getAccountNumber());
				uSearch.setIndex(0);//查询第一页
			}
			
			List<User> userDB=UM.quaryUserByManager(uSearch);
			//System.err.println(uSearch);
			pageModel.setList(userDB);
			
			
			return PageModel.toJson(pageModel);
		}
		public String getDeparts(HttpServletRequest request) {
			List<DepartmentInfo> departs=DIM.queryAllDeparts();
			request.setAttribute("departs", departs);
			return null;
		}
		public String isRepeatAccount(HttpServletRequest request) {
			User user=UM.quaryUserByAccount(request.getParameter("account"));
			if (user==null) {
				return "NO";
			}else {
				return "YES";
				
			}
		}
		public String insertUser(HttpServletRequest request, User user) {
			user.setUserId(UUID.randomUUID().toString());
			user.setPassword(EncryptionUtil.getEncryptionStr(user.getAccountNumber(), user.getPassword()));
			int i=UM.insert(user);
			
			return i+"";
		}
		public String getOneUser(HttpServletRequest request) {
			String userId=request.getParameter("userId");
			User user=UM.selectByPrimaryKey(userId);
			user.setPassword(null);
			request.setAttribute("user",user);
			getDeparts(request);
			return null;
		}
		public String UpdataUser(HttpServletRequest request, User user) {
			if (user.getPassword()!=null&&!user.getPassword().equals("")) {
				user.setPassword(EncryptionUtil.getEncryptionStr(user.getAccountNumber(), user.getPassword()));
				
			}else {
				user.setPassword(null);//防止存空字符串
			}
			System.err.println(user+"------");
			int i=UM.updateByPrimaryKeySelective(user);
			return i+"";
		}
		public String DelUser(HttpServletRequest request, User user) {
			int i= UM.deleteByPrimaryKey(user.getUserId());
			return i+"";
		}
		public String getOrganization(HttpServletRequest request) {
			List<ZtreeModel> organization=UM.selectUserZtree();
			organization.addAll(DIM.selectByDepZtree());
			return PageModel.toJson(organization);
		}
		public String getUsersByPMKey(HttpServletRequest request) {
			User user=UM.selectByPrimaryKey(request.getParameter("userId"));
			user.setPassword(null);
			return PageModel.toJson(user);
		}
		public String getDepartWithAuthr(HttpServletRequest request) {
			List<DepartmentInfo> departs=DIM.queryAllDeparts();
			//获得所有部门集合
			List<DepartAndAuthr> DwithA=new ArrayList<DepartAndAuthr>();
			//新建一个组合部门与权限的对象集合
			for(DepartmentInfo DF :departs){
				//遍历部门集合，将对应权限和部门装入DwithA
				List<Authority> authorities=AM.selectByDepart(DF.getDepartId());
				
				DwithA.add(new DepartAndAuthr(DF, authorities));
			}
			request.setAttribute("DwAs",DwithA);//设置request中相应到前台
			System.err.println(DwithA);
			return null;
		}
		public String getDepartInfo(HttpServletRequest request) {
			String departId=request.getParameter("departId");//
			List<Authority> departAuthr=AM.selectByDepart(departId);
			List<Authority> AllAuthrs=AM.selectAllAuthrs();
			request.setAttribute("AllAuthrs", AllAuthrs);
			request.setAttribute("authrs",departAuthr);
			
			DepartmentInfo departmentInfo=DIM.selectByPrimaryKey(departId);
			request.setAttribute("depart",departmentInfo);
			return null;
		}
		public String isRepeatDepart(HttpServletRequest request) {
			String departName=request.getParameter("departName");
			int i =DIM.selectDepartByName(departName);
			if (i>0) {
				return "YES";
			}else {
				return "NO";
			}
		
		}
		public String updateDepart(HttpServletRequest request, DepartmentInfo depart) {
			if (depart!=null&&depart.getDepartId()!=null) {
				int iM=DIM.updateByPrimaryKeySelective(depart);
				RoleAuthr roleAuthr=new RoleAuthr();
				roleAuthr.setRoleAuthrId(UUID.randomUUID().toString());
				//修改算法
				String[] roles=request.getParameterValues("roles");
				String departId=depart.getDepartId();
				System.err.println(departId);
				List<String> addRoles=new ArrayList<String>();
				List<Authority> delRoles=AM.selectByDepart(departId);
				if (roles!=null&&roles.length>0) {
				addRoles.addAll(Arrays.asList(roles));
				if (delRoles!=null&&delRoles.size()>0) {
					for (int i = 0; i < roles.length; i++) {
						for (int j = 0; j < delRoles.size(); j++) {
							if (roles[i].equals(delRoles.get(j).getAuthorityId())) {
								addRoles.remove(roles[i]);//删除公共元素
								delRoles.remove(j);//获得新增加权限与删除的权限
							}
						}
					}
				}
				
			}	
				if (addRoles!=null&&addRoles.size()>0) {
					//addroles 有元素代表有添加操作
					for(String id:addRoles) {
						RoleAuthr rAuthr=new RoleAuthr();
						rAuthr.setRoleAuthrId(UUID.randomUUID().toString());
						rAuthr.setAuthrId(id);
						rAuthr.setRoleId(departId);
						RAM.insert(rAuthr);
					}			
				}
				if (delRoles!=null&&delRoles.size()>0) {
					//删除公共部分有剩余代表要删除
					for(Authority authority:delRoles) {
						RoleAuthr rAuthr=new RoleAuthr();
						rAuthr.setRoleId(departId);
						rAuthr.setAuthrId(authority.getAuthorityId());
					int n=RAM.deleteByRoleAndAuthr(rAuthr);
					}
				}
				return iM+"-";
			}else{
				return null;
			}
			
			
		}
		public String toAddDepart(HttpServletRequest request) {
			List<Authority> AllAuthrs=AM.selectAllAuthrs();
			request.setAttribute("AllAuthrs", AllAuthrs);
			return null;
		}
		public String AddDepart(HttpServletRequest request, DepartmentInfo depart) {
			String departId=UUID.randomUUID().toString();
			depart.setDepartId(departId);
			int d=DIM.insert(depart);
			String[] roles=request.getParameterValues("roles");
			for(int i=0;i<roles.length;i++) {
				RoleAuthr roleAuthr=new RoleAuthr();
				roleAuthr.setRoleAuthrId(UUID.randomUUID().toString());
				roleAuthr.setAuthrId(roles[i]);
				roleAuthr.setRoleId(departId);
				RAM.insert(roleAuthr);
			}
			return d+"";
		}
		public String AddDepart(HttpServletRequest request) {
			String departId=request.getParameter("departId");
			int i=DIM.deleteByPrimaryKey(departId);
			return i+"";
		}
		
}
