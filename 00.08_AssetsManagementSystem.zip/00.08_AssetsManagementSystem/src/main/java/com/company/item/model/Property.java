package com.company.item.model;

public class Property {
    private String propertyId;

    private String propertyName;

    private String type;

    private String bigtypeName;

    private String malltypeName;

    private Integer propertyNum;

    private Integer brokenNum;

    public Property() {
		super();
	}

	public Property(String propertyId, String propertyName, String type, String bigtypeName, String malltypeName,
			Integer propertyNum, Integer brokenNum) {
		super();
		this.propertyId = propertyId;
		this.propertyName = propertyName;
		this.type = type;
		this.bigtypeName = bigtypeName;
		this.malltypeName = malltypeName;
		this.propertyNum = propertyNum;
		this.brokenNum = brokenNum;
	}

	@Override
	public String toString() {
		return "Property [propertyId=" + propertyId + ", propertyName=" + propertyName + ", type=" + type
				+ ", bigtypeName=" + bigtypeName + ", malltypeName=" + malltypeName + ", propertyNum=" + propertyNum
				+ ", brokenNum=" + brokenNum + "]";
	}

	public String getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(String propertyId) {
        this.propertyId = propertyId;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getBigtypeName() {
        return bigtypeName;
    }

    public void setBigtypeName(String bigtypeName) {
        this.bigtypeName = bigtypeName;
    }

    public String getMalltypeName() {
        return malltypeName;
    }

    public void setMalltypeName(String malltypeName) {
        this.malltypeName = malltypeName;
    }

    public Integer getPropertyNum() {
        return propertyNum;
    }

    public void setPropertyNum(Integer propertyNum) {
        this.propertyNum = propertyNum;
    }

    public Integer getBrokenNum() {
        return brokenNum;
    }

    public void setBrokenNum(Integer brokenNum) {
        this.brokenNum = brokenNum;
    }
}