package com.company.item.service;


import javax.servlet.http.HttpServletRequest;

import com.company.item.model.DepartmentInfo;
import com.company.item.model.User;
import com.company.item.searchModel.UserSearch;

public interface EmeSerive {
	
	String getUsersDB(HttpServletRequest request,UserSearch uSearch);

	String getDeparts(HttpServletRequest request);

	String isRepeatAccount(HttpServletRequest request);

	String insertUser(HttpServletRequest request, User user);

	String getOneUser(HttpServletRequest request);

	String UpdataUser(HttpServletRequest request, User user);

	String DelUser(HttpServletRequest request, User user);

	String getOrganization(HttpServletRequest request);

	String getUsersByPMKey(HttpServletRequest request);

	String getDepartWithAuthr(HttpServletRequest request);

	String getDepartInfo(HttpServletRequest request);

	String isRepeatDepart(HttpServletRequest request);

	String updateDepart(HttpServletRequest request, DepartmentInfo depart);

	String toAddDepart(HttpServletRequest request);

	String AddDepart(HttpServletRequest request, DepartmentInfo depart);

	String AddDepart(HttpServletRequest request);
}
