package com.company.item.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.company.item.model.User;
import com.company.item.pageModel.ZtreeModel;
import com.company.item.searchModel.UserSearch;

public interface UserMapper {
    int deleteByPrimaryKey(String userId);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(String userId);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);

	User quaryUserByAccount(String account);
	/**
	 * index为空时则查询所有数据数量
	 * 不为空则为正常的分页操作
	 * @param depart 部门名称可以为空
	 * @param authr  权限名称可以为空
	 * @param name   模糊查询的用户名字字段
	 * @param index  分页查询的index，为空时再AccountNumber字段返回数据条数
	 * */
	List<User> queryByRole(@Param(value="depart")String depart,@Param(value="authr")String authr,
			@Param(value="userName")String name,@Param(value="index")Integer index);
	
	
	/**
	 * 使用userSearch为过滤条件
	 * 收索用户
	 * @see com.company.item.searchModel.UserSearch
	 * 
	 * */
	List<User> quaryUserByManager(UserSearch userSearch);
	
	List<ZtreeModel> selectUserZtree();
}