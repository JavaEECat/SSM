package com.company.item.mapper;

import com.company.item.model.Structure;

public interface StructureMapper {
    int deleteByPrimaryKey(Integer structureId);

    int insert(Structure record);

    int insertSelective(Structure record);

    Structure selectByPrimaryKey(Integer structureId);

    int updateByPrimaryKeySelective(Structure record);

    int updateByPrimaryKey(Structure record);
}