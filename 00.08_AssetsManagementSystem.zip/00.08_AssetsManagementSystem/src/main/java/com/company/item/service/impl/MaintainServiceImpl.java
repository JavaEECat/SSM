package com.company.item.service.impl;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.item.mapper.MaintainMapper;
import com.company.item.mapper.UserMapper;
import com.company.item.model.Apply;
import com.company.item.model.Maintain;
import com.company.item.model.User;
import com.company.item.service.MaintainService;
import com.framework.utils.PrimaryKeyUtil;
import com.framework.utils.pageUtil.PageBeanUtil;
import com.framework.utils.pageUtil.PagedResult;
import com.github.pagehelper.PageHelper;

@Service
public class MaintainServiceImpl implements MaintainService {
	@Autowired
	private UserMapper userMapper;
	@Autowired
	private MaintainMapper maintainMapper;

	// 添加报修单
	public int addMaintainByMaintain(Maintain maintain, HttpServletRequest request) {
		maintain.setMaintainId(PrimaryKeyUtil.getPrimaryKey());
		String userId = (String) request.getSession().getAttribute("USERID");
		User user = userMapper.selectByPrimaryKey(userId);
		maintain.setUserName(user.getUserName());
		maintain.setApproveState("审核中");
		Date d = new Date();
		maintain.setApplyTime(d);
		int i = maintainMapper.insertSelective(maintain);
		if (i > 0) {
			request.setAttribute("ifo", "申请提交成功");
			return i;
		} else {
			request.setAttribute("ifo", "申请提交失败");
			return i;
		}
	}

	public PagedResult<Maintain> getAllMaintainByPage(Integer pageNumber, Integer pageSize, Maintain maintain,
			HttpServletRequest request) {
		List<Maintain> g = maintainMapper.queryAllMaintain(maintain);
		request.setAttribute("maintainsNum", g.size());
		// 1.调用分页插件
		PageHelper.startPage(pageNumber, pageSize);
		// 2.查询数据库，获取数据
		List<Maintain> glist = maintainMapper.queryAllMaintain(maintain);
		// 3.通过分页工具类加载分页数据
		// request.setAttribute("porchasesNum",
		// glist.size());因为分页插件的原因，只能查出某页的数据
		return PageBeanUtil.toPagedResult(glist);
	}

	public String updateState(String maintainId) {
		// 修改维修表
		Maintain maintain = maintainMapper.selectByPrimaryKey(maintainId);
		maintain.setApproveState("同意");
		maintainMapper.updateByPrimaryKeySelective(maintain);
		return "";
	}

	public void updateStateDo(String maintainId) {
		// 修改维修表
		Maintain maintain = maintainMapper.selectByPrimaryKey(maintainId);
		maintain.setApproveState("审核中");
		maintainMapper.updateByPrimaryKeySelective(maintain);

	}

	public void deleteApply(String maintainId) {
		//删除维修单
		maintainMapper.deleteByPrimaryKey(maintainId);
	}

	public void maintainFinish(String maintainId) {
		Maintain maintain=maintainMapper.selectByPrimaryKey(maintainId);
		Date date=new Date();
		maintain.setFinishTime(date);
		maintainMapper.updateByPrimaryKeySelective(maintain);	
	}

}
