package com.company.item.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.company.item.model.Borrowreturn;
import com.company.item.model.Property;
import com.framework.controller.BaseController;
import com.framework.utils.pageUtil.PagedResult;

@Controller
@RequestMapping("propertyController")
public class PropertyController extends BaseController {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7488370990810468835L;

	@RequestMapping(value = "/showAllProperty.do", produces = "application/json;charset=utf-8")
	public ModelAndView showAllapply(@RequestParam(value = "pageNumber", defaultValue = "1") Integer pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "3") Integer pageSize, Property property,
			HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		// 当前页和每页的条数
		// 传入数据到分页工具类
		PagedResult<Property> pageResult = propertyService.getAllPropertyByPage(pageNumber, pageSize, property,
				request);
		// 数据传递到前台页面展示层
		mv.addObject("pageResult", pageResult);
		mv.setViewName("view/property/allproperty_list");
		return mv;
	}

	/**
	 * 返回所有不重类资产
	 * 
	 * @return
	 */
	@RequestMapping("/returnMalltypeName.ajax")
	public @ResponseBody List<Property> returnMalltypeName(String bigtypeName) {

		return propertyService.returnMalltypeName(bigtypeName);
	}

	/**
	 * 返回所有不重名资产
	 * 
	 * @return
	 */
	@RequestMapping("/returnPropertyName.ajax")
	public @ResponseBody List<Property> returnPropertyName(String malltypeName) {

		return propertyService.returnPropertyName(malltypeName);
	}

	/**
	 * 删除资产
	 * 
	 * @return
	 */
	@RequestMapping(value = "deleteProperty.do", produces = "application/text;charset=utf-8")
	public String deleteProperty(String propertyId) {
		propertyService.deleteProperty(propertyId);
		return "redirect:/propertyController/showAllProperty.do";
	}

	/**
	 * 准备增加资产
	 * 
	 * @return
	 */
	@RequestMapping(value = "addUIProperty.do", produces = "application/text;charset=utf-8")
	public String addUIProperty(String propertyId) {

		return "view/property/property_add";
	}

	/**
	 * 增加资产
	 * 
	 * @return
	 */
	@RequestMapping(value = "addProperty.do", produces = "application/text;charset=utf-8")
	public String addProperty(Property property, String malltypeName2, String propertyName2, String type2) {
		System.err.println(property);
		propertyService.addProperty(property, malltypeName2, propertyName2, type2);
		return "redirect:/propertyController/showAllProperty.do";
	}

	/**
	 * 资产流动记录
	 * 
	 * @return
	 */
	@RequestMapping(value = "/showBorrowreturn.do", produces = "application/json;charset=utf-8")
	public ModelAndView showBorrowreturn(@RequestParam(value = "pageNumber", defaultValue = "1") Integer pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "3") Integer pageSize, Borrowreturn borrowreturn,
			HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		// 当前页和每页的条数
		// 传入数据到分页工具类
		PagedResult<Borrowreturn> pageResult = propertyService.getAllBorrowreturnByPage(pageNumber, pageSize, borrowreturn,
				request);
		// 数据传递到前台页面展示层
		mv.addObject("pageResult", pageResult);
		request.setAttribute("propertyList", propertyService.quaryAllProperty());
		mv.setViewName("view/borrowreturn/borrowreturn_list");
		return mv;
	}
}
