package com.company.item.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.company.item.model.Borrowreturn;

public interface BorrowreturnMapper {
    int deleteByPrimaryKey(String borrowreturnId);

    int insert(Borrowreturn record);

    int insertSelective(Borrowreturn record);

    Borrowreturn selectByPrimaryKey(String borrowreturnId);

    int updateByPrimaryKeySelective(Borrowreturn record);

    int updateByPrimaryKey(Borrowreturn record);
    
    Borrowreturn quaryBorrowReturn(@Param(value="propertyName") String propertyName, @Param(value="type") String type,@Param(value="userName") String userName);

	List<Borrowreturn> quaryAllBorrowreturn(Borrowreturn borrowreturn);
}