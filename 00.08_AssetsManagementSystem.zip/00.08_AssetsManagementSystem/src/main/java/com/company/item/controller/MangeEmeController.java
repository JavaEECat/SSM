package com.company.item.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.company.item.model.DepartmentInfo;
import com.company.item.model.User;
import com.company.item.searchModel.UserSearch;
import com.framework.controller.BaseController;
import com.sun.swing.internal.plaf.synth.resources.synth_es;

@Controller
@RequestMapping("/manageEmeController")
public class MangeEmeController  extends BaseController{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@RequestMapping("/toUserList.do")
	public  String entryIndex(HttpServletRequest request,HttpServletResponse response) {
		String result=ESerive.getDeparts(request);
		return "view/UserManger/userList";
	}
	
	@RequestMapping(value="/getUsersDB.ajax",produces="text/html;charset=utf-8")
	public @ResponseBody String getUserDB(HttpServletRequest request,HttpServletResponse response,UserSearch uSearch) {
		
		return ESerive.getUsersDB(request, uSearch);
	}
	@RequestMapping("/toUserAdd.do")
	public  String toUserAdd(HttpServletRequest request,HttpServletResponse response) {
		String result=ESerive.getDeparts(request);
		return "view/UserManger/userAdd";
	}
	
	@RequestMapping(value="/isRepeat.ajax",produces="text/html;charset=utf-8")
	public @ResponseBody String isRepeat(HttpServletRequest request,HttpServletResponse response) {
		
		return ESerive.isRepeatAccount(request);
	}
	@RequestMapping(value="/userAdd.ajax",produces="text/html;charset=utf-8")
	public @ResponseBody String userAdd(HttpServletRequest request,HttpServletResponse response,User user) {
		return ESerive.insertUser(request,user);
	}
	@RequestMapping("/toUserEdit.do")
	public  String toUserEdit(HttpServletRequest request,HttpServletResponse response) {
		String result=ESerive.getOneUser(request);
		return "view/UserManger/userEdit";
	}
	@RequestMapping(value="/userChanged.ajax",produces="text/html;charset=utf-8")
	public @ResponseBody String userChanged(HttpServletRequest request,HttpServletResponse response,User user) {
		return ESerive.UpdataUser(request,user);
	}
	@RequestMapping(value="/userDel.ajax",produces="text/html;charset=utf-8")
	public @ResponseBody String userDel(HttpServletRequest request,HttpServletResponse response,User user) {
		return ESerive.DelUser(request,user);
	}
	@RequestMapping(value="/getOrg.ajax",produces="text/html;charset=utf-8")
	public @ResponseBody String getOrg(HttpServletRequest request,HttpServletResponse response) {
		return ESerive.getOrganization(request);
	}
	@RequestMapping(value="/getUserInfo.ajax",produces="text/html;charset=utf-8")
	public @ResponseBody String getUserInfoByPimaryKey(HttpServletRequest request,HttpServletResponse response) {
		
		return ESerive.getUsersByPMKey(request);
	}
	@RequestMapping(value="/toDepartList.do")
	public String toDepartList(HttpServletRequest request,HttpServletResponse response) {
		String result=ESerive.getDepartWithAuthr(request);
		return "view/department/departList";
	}
	@RequestMapping(value="/toDeparInfo.do")
	public String toDeparInfo(HttpServletRequest request,HttpServletResponse response) {
		String result=ESerive.getDepartInfo(request);
		return "view/department/departsUpdate";
	}
	
	@RequestMapping(value="/isRepeatDepart.ajax",produces="text/html;charset=utf-8")
	public @ResponseBody String isRepeatDepart(HttpServletRequest request,HttpServletResponse response) {
		
		return ESerive.isRepeatDepart(request);
	}
	@RequestMapping(value="/updateDepart.ajax",produces="text/html;charset=utf-8")
	public @ResponseBody String UpdateDepart(HttpServletRequest request,HttpServletResponse response,DepartmentInfo depart) {
		
		return ESerive.updateDepart(request,depart);
	}
	@RequestMapping(value="/toDepartAdd.do",produces="text/html;charset=utf-8")
	public String toDepartAdd(HttpServletRequest request,HttpServletResponse response) {
		 ESerive.toAddDepart(request);
		return "view/department/departsUpdate";
	}
	@RequestMapping(value="/addDepart.ajax",produces="text/html;charset=utf-8")
	public @ResponseBody String addDepart(HttpServletRequest request,HttpServletResponse response,DepartmentInfo depart) {
		return ESerive.AddDepart(request,depart);
	}
	@RequestMapping(value="/delDepart.ajax",produces="text/html;charset=utf-8")
	public @ResponseBody String delDepart(HttpServletRequest request,HttpServletResponse response) {
		return ESerive.AddDepart(request);
	}
}
