package com.company.item.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.company.item.model.User;
import com.framework.controller.BaseController;

@Controller
@RequestMapping("/indexController")
public class IndexController extends BaseController{
	/**  */
	private static final long serialVersionUID = -140659268406477267L;

	@RequestMapping("/entryIndex.do")
	public  String entryIndex() {
		return "index";
	}
	
	@RequestMapping("/showWelcome.do")
	public  String showWelcome(HttpServletRequest request,HttpSession session) {
		try {
			InetAddress inetAddress=InetAddress.getLocalHost();
			
			User user=userService.getUserBySession();
			request.setAttribute("user", user);
			request.setAttribute("userIp", request.getRemoteAddr());
			request.setAttribute("serverName", userService.getServerName());
			request.setAttribute("timeout", session.getMaxInactiveInterval());
			request.setAttribute("localIp", inetAddress.getHostAddress());
		} catch (UnknownHostException e) {
			request.setAttribute("localIp", "无法获取");
		}
		return "welcome";
	}
	
	
	@RequestMapping("/OnlineNum.ajax")
	public @ResponseBody String OnlineNum(HttpSession session) {
		Set online=(Set) session.getServletContext().getAttribute("OnlineNum");
		return ""+online.size();
	}
	
	
	@RequestMapping("/getServerTime.ajax")
	public @ResponseBody String getServerTime() {
		return userService.getServerTime();
	}
	
	@RequestMapping("/exitLogin.do")
	public  String exitLogin(HttpServletRequest request) {
		userService.deleteUserSession(request);
		return "redirect:/logout";//使用shiro的方式注销
	}
	//为了防止jsp泄漏，全部请求都要经过控制层。
	@RequestMapping("/login.do")
	public  String exitLogin() {
		return "login";
	}
}
