package com.company.item.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.framework.controller.BaseController;

@Controller
@RequestMapping("/roleController")
public class RoleController extends BaseController{

	/**  */
	private static final long serialVersionUID = -1040137534476077333L;
	
	@RequestMapping(value="/getUserRole.ajax",produces="text/html;charset=utf-8")
	public @ResponseBody String checkUser(HttpServletRequest request,HttpServletResponse response){
		return URS.getUserRole(request);
		
	}
	
	@RequestMapping("/toUserRole.do")
	public  String kickOut (HttpServletRequest request,HttpServletResponse response){
		return "view/authr/userAuthr";
		
	}
	@RequestMapping("/changeUserRole.do")
	public  String changeUserRole (HttpServletRequest request,HttpServletResponse response){
		String result=URS.changeUserRole(request);
		return "view/authr/userAuthrEidt";
		
	}
	@RequestMapping("/submitUserRole.ajax")
	public  @ResponseBody String submitUserRole (HttpServletRequest request,HttpServletResponse response,String[] roles){
		String result=URS.submitRoles(request);
		return "view/authr/userAuthrEidt";
		
	}
	
	@RequestMapping("/toDepart.do")
	public  String toDepart (HttpServletRequest request,HttpServletResponse response){
		String result=URS.getDeparts(request);
		return "view/authr/departsAuthr";
		
	}
	@RequestMapping("/changeDepartRole.do")
	public  String changeDepartRole (HttpServletRequest request,HttpServletResponse response){
		String result=URS.getDepartsRole(request);
		return "view/authr/departsAuthrEidt";
		
	}
	
	@RequestMapping("/submitDepartRole.ajax")
	public  @ResponseBody String submitDepartRole (HttpServletRequest request,HttpServletResponse response,String[] roles){
		String result=URS.submitDepartRoles(request);
		return result;
		
	}
}
