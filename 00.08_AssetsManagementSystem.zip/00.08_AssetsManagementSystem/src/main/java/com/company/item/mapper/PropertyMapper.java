package com.company.item.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.company.item.model.Property;

public interface PropertyMapper {
    int deleteByPrimaryKey(String propertyId);

    int insert(Property record);

    int insertSelective(Property record);

    Property selectByPrimaryKey(String propertyId);

    int updateByPrimaryKeySelective(Property record);

    int updateByPrimaryKey(Property record);
    
    Property quaryPropertyByName(@Param(value="propertyName") String propertyName, @Param(value="type") String type);

   	List<Property> quaryPerpertysByPropertyName(String propertyName);

   	List<Property> quaryAllProperty(Property property);

   	List<Property> quaryPropertyByBigtypeName(String bigtypeName);

   	List<Property> quaryPropertyByMalltypeName(String malltypeName);
    
    
}