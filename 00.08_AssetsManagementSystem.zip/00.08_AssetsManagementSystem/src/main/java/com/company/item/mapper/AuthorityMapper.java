package com.company.item.mapper;

import java.util.List;

import com.company.item.model.Authority;

public interface AuthorityMapper {
	
    int deleteByPrimaryKey(String authorityId);

    int insert(Authority record);

    int insertSelective(Authority record);

    Authority selectByPrimaryKey(String authorityId);

    int updateByPrimaryKeySelective(Authority record);

    int updateByPrimaryKey(Authority record);
    
    List<Authority> selectByUser(String userId);

	List<Authority> selectByDepart(String departId);

	List<Authority> selectAllAuthrs();
}