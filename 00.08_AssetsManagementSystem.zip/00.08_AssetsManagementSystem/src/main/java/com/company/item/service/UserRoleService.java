package com.company.item.service;

import javax.servlet.http.HttpServletRequest;

public interface UserRoleService {

	String getUserRole(HttpServletRequest request);

	String changeUserRole(HttpServletRequest request);

	String submitRoles(HttpServletRequest request);

	String getDeparts(HttpServletRequest request);

	String getDepartsRole(HttpServletRequest request);

	String submitDepartRoles(HttpServletRequest request);

}
