package com.company.item.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.framework.controller.BaseController;

@Controller
@RequestMapping("/userController")
public class UserController extends BaseController{

	/**  */
	private static final long serialVersionUID = -1040137534476077333L;
	
	@RequestMapping("/checkUser.ajax")
	public @ResponseBody String checkUser(HttpServletRequest request,HttpServletResponse response){
		return userService.checkUser(request,response);
		
	}
	@RequestMapping(value="/login.ajax",produces="text/html;charset=utf-8")
	public @ResponseBody String logInUser(HttpServletRequest request,HttpServletResponse response){
		return userService.Userlogin(request,response);
		
	}
	@RequestMapping("/rememberUser.ajax")
	public @ResponseBody String rememberUser (HttpServletRequest request){
		return userService.rememberUser(request);
		
	}
	
	
	@RequestMapping("/outLogin.ajax")
	public @ResponseBody String outLogin (HttpServletRequest request,HttpServletResponse response){
		userService.deleteAutoLogin(request,response);
		return "";
		
	}
	
	@RequestMapping("/kickOut.do")
	public  String kickOut (HttpServletRequest request,HttpServletResponse response){
		request.setAttribute("kickOut", "YES");
		return "login";
		
	}
	@RequestMapping("/toIndex.do")
	public  String toIndex (HttpServletRequest request,HttpServletResponse response){
		String result=userService.toIndex(request);
		return "index";
		
	}
}
