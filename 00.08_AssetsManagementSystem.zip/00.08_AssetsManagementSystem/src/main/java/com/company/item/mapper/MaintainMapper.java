package com.company.item.mapper;

import java.util.List;

import com.company.item.model.Maintain;

public interface MaintainMapper {
    int deleteByPrimaryKey(String maintainId);

    int insert(Maintain record);

    int insertSelective(Maintain record);

    Maintain selectByPrimaryKey(String maintainId);

    int updateByPrimaryKeySelective(Maintain record);

    int updateByPrimaryKey(Maintain record);
    
    List<Maintain> queryAllMaintain(Maintain maintain);
}