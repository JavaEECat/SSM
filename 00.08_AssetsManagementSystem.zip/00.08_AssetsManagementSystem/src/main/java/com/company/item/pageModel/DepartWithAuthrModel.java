package com.company.item.pageModel;

import java.util.List;

import com.company.item.model.Authority;
import com.company.item.model.DepartmentInfo;

public class DepartWithAuthrModel {
	private DepartmentInfo Departs;
	private List<Authority> Authrs;
	@Override
	public String toString() {
		return "DepartWithAuthrModel [Departs=" + Departs + ", Authrs=" + Authrs + "]";
	}
	public DepartmentInfo getDeparts() {
		return Departs;
	}
	public void setDeparts(DepartmentInfo departs) {
		Departs = departs;
	}
	public List<Authority> getAuthrs() {
		return Authrs;
	}
	public void setAuthrs(List<Authority> authrs) {
		Authrs = authrs;
	}
	
}
