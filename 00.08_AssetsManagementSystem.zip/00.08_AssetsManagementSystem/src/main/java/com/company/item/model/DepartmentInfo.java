package com.company.item.model;

public class DepartmentInfo {
    private String departId;

    private String departName;

    private String departDesc;

    private String departManager;

    public String getDepartId() {
        return departId;
    }

    public void setDepartId(String departId) {
        this.departId = departId;
    }

    public String getDepartName() {
        return departName;
    }

    public void setDepartName(String departName) {
        this.departName = departName;
    }

    public String getDepartDesc() {
        return departDesc;
    }

    public void setDepartDesc(String departDesc) {
        this.departDesc = departDesc;
    }

    public String getDepartManager() {
        return departManager;
    }

    public void setDepartManager(String departManager) {
        this.departManager = departManager;
    }
}