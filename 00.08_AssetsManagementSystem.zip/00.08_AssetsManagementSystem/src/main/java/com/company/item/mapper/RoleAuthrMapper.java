package com.company.item.mapper;

import com.company.item.model.RoleAuthr;

public interface RoleAuthrMapper {
    int deleteByPrimaryKey(String roleAuthrId);

    int insert(RoleAuthr record);

    int insertSelective(RoleAuthr record);

    RoleAuthr selectByPrimaryKey(String roleAuthrId);

    int updateByPrimaryKeySelective(RoleAuthr record);

    int updateByPrimaryKey(RoleAuthr record);

	int deleteByRoleAndAuthr(RoleAuthr rAuthr);
}