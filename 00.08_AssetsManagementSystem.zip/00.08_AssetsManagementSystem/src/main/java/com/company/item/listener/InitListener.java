package com.company.item.listener;

import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class InitListener implements ServletContextListener{

	public void contextDestroyed(ServletContextEvent arg0) {
		
		
	}

	public void contextInitialized(ServletContextEvent arg0) {
		
		ServletContext sc=arg0.getServletContext();
		Set<String> Online=new HashSet<String>();
		sc.setAttribute("OnlineNum", Online);
	}

}
