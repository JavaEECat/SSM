package com.company.item.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.company.item.model.Apply;
import com.company.item.model.Maintain;
import com.company.item.model.Property;
import com.framework.controller.BaseController;
import com.framework.utils.pageUtil.PagedResult;
@Controller
@RequestMapping("maintainController")
public class MaintainController extends BaseController{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5061394820257545182L;
	
	/**
	 * 申请报修
	 */
	@RequestMapping("/applyRepairs.do")
	public String applyRepairs(HttpServletRequest request){
		List<Apply> propertyList=applyService.quaryAllUserApply(request);
		request.setAttribute("propertyList", propertyList);
		return "view/maintain/maintain_add";
		
	}
	
	/**
	 * 添加报修
	 * @return
	 */
	@RequestMapping("/maintainAdd.do")
	public  String propertyAdd(Maintain maintain,HttpServletRequest request) {
		int i=maintainService.addMaintainByMaintain(maintain,request);
		
		return "view/maintain/maintain_add";
	}
	
	@RequestMapping(value = "/showallmaintain.do", produces = "application/json;charset=utf-8")
	public ModelAndView showallmaintain(@RequestParam(value = "pageNumber", defaultValue = "1") Integer pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "3") Integer pageSize, Maintain maintain,HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		// 当前页和每页的条数
		// 传入数据到分页工具类
		PagedResult<Maintain> pageResult = maintainService.getAllMaintainByPage(pageNumber, pageSize, maintain,request);
		// 数据传递到前台页面展示层
		mv.addObject("pageResult", pageResult);
		request.setAttribute("propertyList", propertyService.quaryAllProperty());
		mv.setViewName("view/maintain/allmaintain_list");
		return mv;
	}
	
	
	/**
	 * 批准申请
	 * @return
	 */
	@RequestMapping(value="/updateState.ajax")
	public @ResponseBody String updateState(String maintainId) {
		return maintainService.updateState(maintainId);
	}
	
	/**
	 * 否定申请
	 * @return
	 */
	@RequestMapping("/updateStateDo.ajax")
	public @ResponseBody String updateStateDo(String maintainId) {
		maintainService.updateStateDo(maintainId);
		return "";
	}
	
	/**
	 * 删除申请
	 * @return
	 */
	@RequestMapping(value = "deleteMaintain.do", produces = "application/text;charset=utf-8")
	public String deleteMaintain(String maintainId) {
		maintainService.deleteApply(maintainId);
		return "redirect:/maintainController/showallmaintain.do";
	}
	
	
	/**
	 * 维修完成
	 * @return
	 */
	@RequestMapping("/maintainFinish.ajax")
	public @ResponseBody String maintainFinish(String maintainId) {
		maintainService.maintainFinish(maintainId);
		return "";
	}

}
