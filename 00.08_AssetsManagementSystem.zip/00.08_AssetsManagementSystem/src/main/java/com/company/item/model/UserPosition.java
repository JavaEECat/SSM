package com.company.item.model;

public class UserPosition {
    private String userPositionId;

    private String userId;

    private String positionId;

    public String getUserPositionId() {
        return userPositionId;
    }

    public void setUserPositionId(String userPositionId) {
        this.userPositionId = userPositionId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPositionId() {
        return positionId;
    }

    public void setPositionId(String positionId) {
        this.positionId = positionId;
    }
}