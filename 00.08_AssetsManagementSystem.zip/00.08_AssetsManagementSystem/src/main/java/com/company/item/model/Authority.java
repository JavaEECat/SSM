package com.company.item.model;

public class Authority {
    private String authorityId;

    private String authorityPid;

    private String authorityName;

    private String authorityDescription;

    public String getAuthorityId() {
        return authorityId;
    }

    public void setAuthorityId(String authorityId) {
        this.authorityId = authorityId;
    }

    public String getAuthorityPid() {
        return authorityPid;
    }

    public void setAuthorityPid(String authorityPid) {
        this.authorityPid = authorityPid;
    }

    public String getAuthorityName() {
        return authorityName;
    }

    public void setAuthorityName(String authorityName) {
        this.authorityName = authorityName;
    }

    public String getAuthorityDescription() {
        return authorityDescription;
    }

    public void setAuthorityDescription(String authorityDescription) {
        this.authorityDescription = authorityDescription;
    }

	@Override
	public String toString() {
		return "Authority [authorityId=" + authorityId + ", authorityPid=" + authorityPid + ", authorityName="
				+ authorityName + ", authorityDescription=" + authorityDescription + "]";
	}
    
}