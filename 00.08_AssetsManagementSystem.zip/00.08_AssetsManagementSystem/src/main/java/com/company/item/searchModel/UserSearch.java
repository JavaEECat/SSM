package com.company.item.searchModel;
/**
 * 
 * @author siwash
 * 用户管理的分页 搜索过滤条件
 * 
 * */
public class UserSearch {
	private String userDepart;
	private String EntryStart;
	private String EntryEnd;
	private String birthRange;
	private String userName;
	private Integer index;
	@Override
	public String toString() {
		return "UserSearch [userDepart=" + userDepart + ", EntryStart=" + EntryStart + ", EntryEnd=" + EntryEnd
				+ ", birthRange=" + birthRange + ", userName=" + userName + ", index=" + index + "]";
	}
	public String getUserDepart() {
		return userDepart;
	}
	public void setUserDepart(String userDepart) {
		this.userDepart = userDepart;
	}
	public String getEntryStart() {
		return EntryStart;
	}
	public void setEntryStart(String entryStart) {
		EntryStart = entryStart;
	}
	public String getEntryEnd() {
		return EntryEnd;
	}
	public void setEntryEnd(String entryEnd) {
		EntryEnd = entryEnd;
	}
	public String getBirthRange() {
		return birthRange;
	}
	public void setBirthRange(String birthRange) {
		this.birthRange = birthRange;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	
}
