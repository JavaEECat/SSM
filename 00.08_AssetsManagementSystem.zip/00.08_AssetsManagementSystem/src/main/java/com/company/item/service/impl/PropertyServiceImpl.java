package com.company.item.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.item.mapper.ApplyMapper;
import com.company.item.mapper.BorrowreturnMapper;
import com.company.item.mapper.PropertyMapper;
import com.company.item.mapper.UserMapper;
import com.company.item.model.Apply;
import com.company.item.model.Borrowreturn;
import com.company.item.model.Property;
import com.company.item.model.User;
import com.company.item.service.PropertyService;
import com.framework.utils.PrimaryKeyUtil;
import com.framework.utils.pageUtil.PageBeanUtil;
import com.framework.utils.pageUtil.PagedResult;
import com.github.pagehelper.PageHelper;

@Service
public class PropertyServiceImpl implements PropertyService {

	@Autowired
	private PropertyMapper propertyMapper;
	@Autowired
	private ApplyMapper applyMapper;

	@Autowired
	private UserMapper userMapper;
	@Autowired
	private BorrowreturnMapper borrowreturnMapper;

	// 根据资产名字查处所有资产
	public List<Property> quaryPerpertysByPropertyName(String propertyName) {
		// String propertyName=(String) request.getAttribute("propertyName");
		return propertyMapper.quaryPerpertysByPropertyName(propertyName);
	}

	// 增加申请表
	public int addPropertyByProperty(Apply apply, HttpServletRequest request) {
		apply.setApplyId(PrimaryKeyUtil.getPrimaryKey());
		String userId = (String) request.getSession().getAttribute("USERID");
		User user = userMapper.selectByPrimaryKey(userId);
		apply.setUserName(user.getUserName());
		apply.setApplyState("审核中");
		Date d = new Date();
		apply.setApplyTime(d);
		int i = applyMapper.insertSelective(apply);
		if (i > 0) {
			request.setAttribute("ifo", "申请提交成功");
			return i;
		} else {
			request.setAttribute("ifo", "申请提交失败");
			return i;
		}
	}

	// 返回不同名的所有资产
	public List<Property> quaryAllProperty() {
		List<Property> pp = new ArrayList<Property>();// 用于储存不同名资产
		Property property = new Property();
		List<Property> properties = propertyMapper.quaryAllProperty(property);
		for (int i = 0; i < properties.size(); i++) {
			int a = 0;
			if (i == 0) {
				pp.add(properties.get(i));
			} else {
				for (int k = 0; k < pp.size(); k++) {
					if (!pp.get(k).getPropertyName().equals(properties.get(i).getPropertyName())) {
						a++;// 每比较一次，没出现同名，加1
					}
				}
				int m = pp.size();
				if (a == m) {// 比较a值的大小，等于集合长度，就证明和集合里面所有名字都不重名
					pp.add(properties.get(i));
				}
			}
		}
		return pp;// 返回不同名的资产集合
	}

	public PagedResult<Property> getAllPropertyByPage(Integer pageNumber, Integer pageSize, Property property,
			HttpServletRequest request) {
		// 判断查询条件是否有选择
		if (property.getPropertyName() == null || property.getType() == null || property.getBigtypeName() == null
				|| property.getMalltypeName() == null) {

		} else {
			if (property.getPropertyName().equals("请选择资产名字")) {
				property.setPropertyName("");
			}
			if (property.getType().equals("请选择型号")) {
				property.setType("");
			}
			if (property.getBigtypeName().equals("请选择类型")) {

			}
			if (property.getMalltypeName().equals("请选择分类")) {

			}
		}
		List<Property> g = propertyMapper.quaryAllProperty(property);
		request.setAttribute("propertysNum", g.size());
		// 1.调用分页插件
		PageHelper.startPage(pageNumber, pageSize);
		// 2.查询数据库，获取数据
		List<Property> glist = propertyMapper.quaryAllProperty(property);
		// 3.通过分页工具类加载分页数据
		// request.setAttribute("porchasesNum",
		// glist.size());因为分页插件的原因，只能查出某页的数据
		return PageBeanUtil.toPagedResult(glist);
	}

	// 取出所有不同类型的资产
	public List<Property> returnMalltypeName(String bigtypeName) {
		List<Property> properties = propertyMapper.quaryPropertyByBigtypeName(bigtypeName);
		List<Property> pp = new ArrayList<Property>();
		for (int i = 0; i < properties.size(); i++) {
			int a = 0;
			if (i == 0) {
				pp.add(properties.get(i));
			} else {
				for (int k = 0; k < pp.size(); k++) {
					if (!pp.get(k).getMalltypeName().equals(properties.get(i).getMalltypeName())) {
						a++;// 每比较一次，没出现同名，加1
					}
				}
				int m = pp.size();
				if (a == m) {// 比较a值的大小，等于集合长度，就证明和集合里面所有类型都不重名
					pp.add(properties.get(i));
				}
			}
		}
		return pp;// 取出所有不同类型的集合
	}

	// 通过小类名返回所有不同名资产
	public List<Property> returnPropertyName(String malltypeName) {
		List<Property> properties = propertyMapper.quaryPropertyByMalltypeName(malltypeName);
		List<Property> pp = new ArrayList<Property>();
		for (int i = 0; i < properties.size(); i++) {
			int a = 0;
			if (i == 0) {
				pp.add(properties.get(i));
			} else {
				for (int k = 0; k < pp.size(); k++) {
					if (!pp.get(k).getPropertyName().equals(properties.get(i).getPropertyName())) {
						a++;// 每比较一次，没出现同名，加1
					}
				}
				int m = pp.size();
				if (a == m) {// 比较a值的大小，等于集合长度，就证明和集合里面所有名字都不重名
					pp.add(properties.get(i));
				}
			}
		}
		return pp;
	}

	// 删除资产
	public void deleteProperty(String propertyId) {
		propertyMapper.deleteByPrimaryKey(propertyId);

	}

	// 查询所有报修
	public PagedResult<Borrowreturn> getAllBorrowreturnByPage(Integer pageNumber, Integer pageSize,
			Borrowreturn borrowreturn, HttpServletRequest request) {
		// 判断查询条件是否有选择
		if (borrowreturn.getPropertyName() == null || borrowreturn.getType() == null) {

		} else {
			if (borrowreturn.getPropertyName().equals("请选择资产名字")) {
				borrowreturn.setPropertyName("");
			}
			if (borrowreturn.getType().equals("请选择型号")) {
				borrowreturn.setType("");
			}
		}

		List<Borrowreturn> g = borrowreturnMapper.quaryAllBorrowreturn(borrowreturn);

		request.setAttribute("borrowreturnsNum", g.size());
		// 1.调用分页插件
		PageHelper.startPage(pageNumber, pageSize);
		// 2.查询数据库，获取数据
		List<Borrowreturn> glist = borrowreturnMapper.quaryAllBorrowreturn(borrowreturn);
		// 3.通过分页工具类加载分页数据
		// request.setAttribute("porchasesNum",
		// glist.size());因为分页插件的原因，只能查出某页的数据
		return PageBeanUtil.toPagedResult(glist);
	}

		//增加资产
	public void addProperty(Property property, String malltypeName2, String propertyName2, String type2) {
		if (malltypeName2 !=null && malltypeName2 !="") {
			property.setMalltypeName(malltypeName2);
		}
		if (propertyName2 !=null && propertyName2 !="") {
			property.setPropertyName(propertyName2);
		}
		if (type2 !=null && type2 !="") {
			property.setType(type2);
		}
		property.setPropertyNum(0);
		property.setBrokenNum(0);
		property.setPropertyId(PrimaryKeyUtil.getPrimaryKey());
		propertyMapper.insertSelective(property);
		
	}

}
