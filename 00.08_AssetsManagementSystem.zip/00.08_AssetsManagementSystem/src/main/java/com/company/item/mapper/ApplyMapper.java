package com.company.item.mapper;

import java.util.List;

import com.company.item.model.Apply;

public interface ApplyMapper {
    int deleteByPrimaryKey(String applyId);

    int insert(Apply record);

    int insertSelective(Apply record);

    Apply selectByPrimaryKey(String applyId);

    int updateByPrimaryKeySelective(Apply record);

    int updateByPrimaryKey(Apply record);
    
    List<Apply> quaryApply(int nn);

	List<Apply> queryAllPorchases(Apply apply);

	List<Apply> getAllApplyByUsername(Apply apply);
}