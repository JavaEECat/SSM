package com.company.item.model;

public class RoleAuthr {
    private String roleAuthrId;

    private String roleId;

    private String authrId;

    public String getRoleAuthrId() {
        return roleAuthrId;
    }

    public void setRoleAuthrId(String roleAuthrId) {
        this.roleAuthrId = roleAuthrId;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getAuthrId() {
        return authrId;
    }

    public void setAuthrId(String authrId) {
        this.authrId = authrId;
    }
}