package com.company.item.mapper;


import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.company.item.searchModel.UserSearch;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:spring.xml","classpath:spring-shiro-web.xml"})

public class UserMapperTest {
	@Resource
	UserMapper UM;
	@Resource
	DepartmentInfoMapper DIM;
	@Test
	public void testQueryByRole() {
		System.err.println("----------------------->");
		System.out.println(UM.queryByRole("","权限管理","人",0));
	}
	@Test
	public void testQueryByMane() {
		System.err.println("----------------------->");
		UserSearch userSearch=new UserSearch();
		userSearch.setBirthRange("");
		userSearch.setEntryStart("");
		userSearch.setEntryStart("");
		userSearch.setUserName("小");
		userSearch.setUserDepart("");
		userSearch.setIndex(0);
		System.out.println(UM.quaryUserByManager(userSearch));
	}
	@Test
	public void testZtree() {
		System.err.println("----------------------->");
	
		System.out.println(DIM.selectDepartByName("后期服务部")>0);
	}

}
